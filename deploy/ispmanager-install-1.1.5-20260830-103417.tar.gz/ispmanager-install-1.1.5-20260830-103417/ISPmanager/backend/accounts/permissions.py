"""
accounts/permissions.py
自定义 DRF 权限类 & 用户权限工具函数
"""
from __future__ import annotations

from typing import Iterable

from rest_framework.permissions import BasePermission

from .models import UserProfile
from .role_permissions import (
    Perm,
    get_permissions_for_user,
    user_has_any_permission,
    user_has_permission,
)


# ── 工具函数 ──────────────────────────────────────────────────

def get_user_profile(user) -> UserProfile | None:
    """获取用户档案，不存在时返回 None。"""
    if not user or not getattr(user, 'is_authenticated', False):
        return None
    try:
        return user.profile
    except UserProfile.DoesNotExist:
        return None


def ensure_user_profile(user) -> UserProfile:
    """确保用户档案存在并返回。"""
    profile, _ = UserProfile.objects.get_or_create(user=user)
    return profile


def get_effective_permissions(user) -> frozenset[str]:
    profile = get_user_profile(user)
    if profile is None:
        if user and user.is_superuser:
            from .role_permissions import ALL_PERMISSIONS
            return ALL_PERMISSIONS
        return frozenset()
    return get_permissions_for_user(profile)


def check_permission(user, permission: str) -> bool:
    if user and user.is_superuser:
        return True
    profile = get_user_profile(user)
    if profile is None:
        return False
    return user_has_permission(profile, permission)


def check_any_permission(user, permissions: Iterable[str]) -> bool:
    if user and user.is_superuser:
        return True
    profile = get_user_profile(user)
    if profile is None:
        return False
    return user_has_any_permission(profile, permissions)


def is_system_account(user) -> bool:
    profile = get_user_profile(user)
    return profile is None or profile.account_type == UserProfile.AccountType.SYSTEM


def is_customer_account(user) -> bool:
    profile = get_user_profile(user)
    return profile is not None and profile.account_type == UserProfile.AccountType.CUSTOMER


def get_user_customer(user):
    """归属客户账号关联的 Customer 实例；系统账号返回 None。"""
    if not is_customer_account(user):
        return None
    return getattr(user, 'customer', None)


def build_user_auth_context(user) -> dict:
    """构建登录 / me 接口使用的权限上下文。"""
    profile = ensure_user_profile(user)
    permissions = sorted(get_permissions_for_user(profile))
    customer = get_user_customer(user)
    from customer_manager.reputation import serialize_reputation
    reputation = serialize_reputation(customer)
    return {
        'role': profile.role,
        'role_label': profile.get_role_display(),
        'account_type': profile.account_type,
        'account_type_label': profile.get_account_type_display(),
        'permissions': permissions,
        'department': profile.department,
        'phone': profile.phone,
        'position': profile.position,
        'avatar': profile.avatar,
        'customer_id': customer.id if customer else None,
        'customer_name': customer.name if customer else None,
        **reputation,
    }


# ── DRF 权限类 ────────────────────────────────────────────────

class IsAdminUser(BasePermission):
    """
    系统管理员：超级用户 / is_staff / 拥有 accounts.manage 权限。
    用于用户管理、Token 总览等管理接口。
    """
    message = '仅系统管理员可执行此操作'

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if user.is_superuser or user.is_staff:
            return True
        return check_permission(user, Perm.ACCOUNTS_MANAGE)


class IsSuperAdmin(BasePermission):
    """仅 Django 超级管理员（is_superuser）可访问。"""
    message = '仅超级管理员可执行此操作'

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_superuser)


class IsSystemAccount(BasePermission):
    """仅系统内部账号（非归属客户 portal 账号）。"""
    message = '归属客户账号无权访问此功能'

    def has_permission(self, request, view):
        user = request.user
        return bool(user and user.is_authenticated and is_system_account(user))


class HasPermission(BasePermission):
    """
    要求拥有指定权限码。
    用法：permission_classes = [IsAuthenticated, HasPermission.with_perm(Perm.CUSTOMER_MANAGE)]
    """
    permission_code: str = ''
    message = '权限不足，无法执行此操作'

    @classmethod
    def with_perm(cls, permission_code: str):
        code = permission_code

        class _HasPermission(cls):
            permission_code = code

        _HasPermission.__name__ = f'HasPermission_{code.replace(".", "_")}'
        return _HasPermission

    def has_permission(self, request, view):
        return check_permission(request.user, self.permission_code)


class HasAnyPermission(BasePermission):
    """拥有给定权限之一即可访问。"""
    permission_codes: tuple[str, ...] = ()
    message = '权限不足，无法执行此操作'

    @classmethod
    def with_perms(cls, *permission_codes: str):
        codes = permission_codes

        class _HasAnyPermission(cls):
            permission_codes = codes

        _HasAnyPermission.__name__ = f'HasAnyPermission_{"_".join(c.replace(".", "-") for c in codes)}'
        return _HasAnyPermission

    def has_permission(self, request, view):
        return check_any_permission(request.user, self.permission_codes)


class RoleRequired(BasePermission):
    """要求用户角色在允许列表中（仅系统账号）。"""
    allowed_roles: tuple[str, ...] = ()
    message = '当前角色无权执行此操作'

    @classmethod
    def with_roles(cls, *roles: str):
        allowed = roles

        class _RoleRequired(cls):
            allowed_roles = allowed

        _RoleRequired.__name__ = f'RoleRequired_{"_".join(allowed)}'
        return _RoleRequired

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if user.is_superuser:
            return True
        profile = get_user_profile(user)
        if profile is None:
            return False
        if profile.account_type != UserProfile.AccountType.SYSTEM:
            return False
        return profile.role in self.allowed_roles
