"""IP 地址块上的网络类型 / ASN 聚合，供产品与门户展示、筛选。"""
from __future__ import annotations

from .models import AsnNature, NetworkType, NetworkTypeOption


def asn_nature_label(code: str) -> str:
    if not code:
        return ''
    return dict(AsnNature.choices).get(code, code)


class NetworkAttrCatalog:
    """一次查出网络类型目录，供列表序列化复用。"""

    def __init__(self):
        self.labels = dict(NetworkType.choices)
        self.order = {}
        for opt in NetworkTypeOption.objects.all():
            self.labels[opt.code] = opt.name
            self.order[opt.code] = opt.sort_order

    def network_type_label(self, code: str) -> str:
        if not code:
            return ''
        return self.labels.get(code, code)

    def collect(self, pop):
        """从 POP 下 IP 块聚合去重后的网络类型 / ASN，不再读取 POP 自身字段。"""
        empty = {
            'network_types': [],
            'asn_natures': [],
            'network_type': '',
            'network_type_label': '',
            'asn_nature': '',
            'asn_nature_label': '',
        }
        if pop is None:
            return empty

        network_types = []
        asn_natures = []
        seen_nt = set()
        seen_asn = set()
        for block in pop.ip_blocks.all():
            nt = (getattr(block, 'network_type', None) or '').strip()
            if nt and nt not in seen_nt:
                seen_nt.add(nt)
                network_types.append({
                    'value': nt,
                    'label': self.network_type_label(nt),
                })
            asn = (getattr(block, 'asn_nature', None) or '').strip()
            if asn and asn not in seen_asn:
                seen_asn.add(asn)
                asn_natures.append({
                    'value': asn,
                    'label': asn_nature_label(asn),
                })

        network_types.sort(key=lambda item: (self.order.get(item['value'], 999), item['value']))
        asn_natures.sort(key=lambda item: item['value'])
        primary_nt = network_types[0] if network_types else None
        primary_asn = asn_natures[0] if asn_natures else None
        return {
            'network_types': network_types,
            'asn_natures': asn_natures,
            'network_type': primary_nt['value'] if primary_nt else '',
            'network_type_label': primary_nt['label'] if primary_nt else '',
            'asn_nature': primary_asn['value'] if primary_asn else '',
            'asn_nature_label': primary_asn['label'] if primary_asn else '',
        }


def catalog_from_context(context: dict | None) -> NetworkAttrCatalog:
    ctx = context if context is not None else {}
    cat = ctx.get('_network_attr_catalog')
    if cat is None:
        cat = NetworkAttrCatalog()
        ctx['_network_attr_catalog'] = cat
    return cat


def collect_product_network_attrs(product, context: dict | None = None) -> dict:
    cat = catalog_from_context(context)
    cache = getattr(product, '_ip_block_network_attrs', None)
    if cache is None:
        pop = product.pop_point if getattr(product, 'pop_point_id', None) else None
        cache = cat.collect(pop)
        product._ip_block_network_attrs = cache
    return cache
