from types import SimpleNamespace
from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import RequestFactory, SimpleTestCase, TestCase

from customer_manager.models import Customer
from portal.serializers import PortalOrderCreateSerializer
from product_manager.models import Product
from resource_manager import pve_ops
from resource_manager.models import City, Country, PopPoint, Region, VPS
from service_manager.models import ServiceOrder
from service_manager.provisioning import _provision_vps
from system_manager.models import SystemOsTemplate


class EnsureOsTemplateOnPopTests(SimpleTestCase):
    def test_downloads_when_missing_then_returns_registered_template(self):
        catalog = SimpleNamespace(
            name='Ubuntu',
            version='22.04',
            display_label='Ubuntu 22.04',
            backup_filename='ubuntu-22.04.vma.zst',
            download_url='http://mirror.example.com/ubuntu-22.04.vma.zst',
            source_type='backup',
            code='ubuntu-2204',
        )
        downloaded = {
            'id': 9,
            'name': 'Ubuntu 22.04',
            'filename': 'ubuntu-22.04.vma.zst',
            'download_url': catalog.download_url,
            'host': 3,
            'node': 'pve',
            'source_type': 'backup',
        }
        calls = []

        def list_templates():
            return [downloaded] if calls else []

        client = SimpleNamespace(
            list_templates=list_templates,
            list_pve_hosts=lambda: [{
                'id': 3,
                'default_node': 'pve',
                'nodes': [{'node': 'pve'}],
                'storages': [{'storage': 'local', 'content': 'backup,iso', 'node': 'pve'}],
            }],
            host_storages=lambda *args, **kwargs: [],
            download_template=lambda payload, timeout=2100: calls.append(payload) or {'upid': 'UPID:1'},
        )
        with patch.object(pve_ops, '_connect', return_value=(client, 'node-admin')):
            found = pve_ops.ensure_os_template_on_pop(SimpleNamespace(), catalog)
        self.assertEqual(found['id'], 9)
        self.assertEqual(calls[0]['url'], catalog.download_url)
        self.assertEqual(calls[0]['filename'], 'ubuntu-22.04.vma.zst')
        self.assertTrue(calls[0]['wait'])

    def test_reuses_existing_template_without_download(self):
        catalog = SimpleNamespace(
            display_label='Debian 12',
            backup_filename='debian-12.vma.zst',
            download_url='http://mirror.example.com/debian-12.vma.zst',
            source_type='backup',
            code='debian-12',
        )
        existing = {
            'id': 4,
            'name': 'Debian 12',
            'filename': 'debian-12.vma.zst',
            'host': 1,
            'node': 'pve',
            'storage': 'local',
            'source_type': 'backup',
            'volume': 'local:backup/debian-12.vma.zst',
        }
        client = SimpleNamespace(
            list_templates=lambda: [existing],
            download_template=lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError('should not download')),
            host_storage_content=lambda *args, **kwargs: [{'volid': 'local:backup/debian-12.vma.zst'}],
            host_backups=lambda *args, **kwargs: [],
        )
        with patch.object(pve_ops, '_connect', return_value=(client, 'node-admin')):
            found = pve_ops.ensure_os_template_on_pop(SimpleNamespace(), catalog)
        self.assertEqual(found['id'], 4)


class ProvisionVpsOsTemplateTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_superuser('prov-os', 'prov-os@example.test', 'password')
        self.customer = Customer.objects.create(
            name='开通系统模版客户',
            contact_name='联系人',
            status='active',
        )
        region = Region.objects.create(code='prov-os', name='开通模版区')
        country = Country.objects.create(region=region, name='开通模版国')
        city = City.objects.create(country=country, name='开通模版市')
        self.pop = PopPoint.objects.create(
            name='开通模版 POP',
            city=city,
            config_mode=PopPoint.ConfigMode.AUTO,
        )
        self.product = Product.objects.create(
            name='开通模版 VPS',
            status=Product.Status.ONLINE,
            pop_point=self.pop,
        )
        self.template = SystemOsTemplate.objects.create(
            name='Ubuntu',
            version='22.04',
            backup_filename='ubuntu-22.04.vma.zst',
            download_url='http://mirror.example.com/ubuntu-22.04.vma.zst',
        )
        self.order = ServiceOrder.objects.create(
            customer=self.customer,
            product=self.product,
            preferred_pop=self.pop,
            business_type=ServiceOrder.BusinessType.VPS,
            status=ServiceOrder.OrderStatus.APPROVED,
            requested_vcpu=2,
            requested_ram_mb=2048,
            requested_disk_gb=40,
            requested_os='Ubuntu 22.04',
            requested_os_template=self.template,
        )

    def test_provision_downloads_missing_template_then_creates_vm(self):
        node_template = {
            'id': 11,
            'name': 'Ubuntu 22.04',
            'filename': 'ubuntu-22.04.vma.zst',
        }
        created = []

        def fake_create(pop, payload, dry_run=False):
            created.append(payload)
            VPS.objects.create(
                name=payload['name'],
                pop_point=pop,
                source_ref=str(payload['vmid']),
            )
            return {'ok': True, 'status': 'succeeded'}

        with patch('resource_manager.pve_ops.list_pve_resources', return_value={
            'hosts': [{'id': 3, 'nodes': [{'node': 'pve'}], 'storages': [{'storage': 'local-lvm'}]}],
            'next_vmid': 201,
            'templates': [],
        }), patch('resource_manager.pve_ops.ensure_os_template_on_pop', return_value=node_template) as ensure, \
             patch('resource_manager.pve_ops.create_from_template', side_effect=fake_create), \
             patch('resource_manager.pve_ops.create_vm') as create_empty:
            instance, message = _provision_vps(self.order, self.pop, self.user)

        ensure.assert_called_once()
        create_empty.assert_not_called()
        self.assertEqual(created[0]['template_id'], 11)
        self.assertEqual(created[0]['download_url'], self.template.download_url)
        instance.vps.refresh_from_db()
        self.assertEqual(instance.vps.os_type, 'ubuntu')
        self.assertEqual(instance.vps.os_version, '22.04')
        self.assertIn('已在节点创建虚机', message)


class PortalOrderOsTemplateTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('portal-os', password='SafePass_2026!')
        self.customer = Customer.objects.create(
            name='门户系统模版客户',
            contact_name='联系人',
            account=self.user,
            status='active',
        )
        region = Region.objects.create(code='portal-os', name='门户模版区')
        country = Country.objects.create(region=region, name='门户模版国')
        city = City.objects.create(country=country, name='门户模版市')
        self.pop = PopPoint.objects.create(name='门户模版 POP', city=city)
        self.product = Product.objects.create(
            name='门户模版 VPS',
            status=Product.Status.ONLINE,
            pop_point=self.pop,
        )
        self.template = SystemOsTemplate.objects.create(
            name='Debian',
            version='12',
            backup_filename='debian-12.vma.zst',
            download_url='http://mirror.example.com/debian-12.vma.zst',
        )

    def test_checkout_binds_os_template(self):
        request = RequestFactory().post('/api/portal/orders/')
        request.user = self.user
        serializer = PortalOrderCreateSerializer(
            data={
                'product_id': self.product.pk,
                'os_template_id': self.template.pk,
                'quantity': 1,
            },
            context={'request': request, 'customer': self.customer},
        )
        self.assertTrue(serializer.is_valid(), serializer.errors)
        order = serializer.save()
        self.assertEqual(order.requested_os_template_id, self.template.pk)
        self.assertEqual(order.requested_os, 'Debian 12')
        self.assertEqual(order.request_snapshot['os_template_id'], self.template.pk)
