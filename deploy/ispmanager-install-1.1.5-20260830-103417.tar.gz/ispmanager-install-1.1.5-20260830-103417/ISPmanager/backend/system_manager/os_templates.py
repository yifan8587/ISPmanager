"""系统模版目录：产品、门户与开通共用同一数据源。"""
from __future__ import annotations

import re
from urllib.parse import unquote, urlparse

from django.utils.text import slugify


def filename_from_url(url: str) -> str:
    path = unquote(urlparse(url or '').path or '')
    name = path.rstrip('/').rsplit('/', 1)[-1] if path else ''
    return name.strip()


def infer_os_type(name: str) -> str:
    text = (name or '').lower()
    if 'ubuntu' in text:
        return 'ubuntu'
    if 'debian' in text:
        return 'debian'
    if 'centos' in text:
        return 'centos'
    if 'windows' in text:
        return 'windows'
    if any(token in text for token in ('rhel', 'redhat', 'rocky', 'alma')):
        return 'rhel'
    return 'other'


def make_unique_code(name: str, version: str, *, exclude_pk=None) -> str:
    from .models import SystemOsTemplate

    raw = slugify(f'{name}-{version}') or slugify(name) or 'os'
    raw = re.sub(r'[^a-z0-9-]+', '', raw).strip('-')[:28] or 'os'
    code = raw
    seq = 2
    while True:
        qs = SystemOsTemplate.objects.filter(code=code)
        if exclude_pk:
            qs = qs.exclude(pk=exclude_pk)
        if not qs.exists():
            return code
        suffix = f'-{seq}'
        code = f'{raw[: 32 - len(suffix)]}{suffix}'
        seq += 1


def match_os_template(value, *, queryset=None):
    """按 id / code / 显示名 / 文件名解析系统模版。"""
    from .models import SystemOsTemplate

    qs = queryset if queryset is not None else SystemOsTemplate.objects.all()
    if value in (None, ''):
        return None
    if isinstance(value, SystemOsTemplate):
        return value
    if isinstance(value, int) or (isinstance(value, str) and value.isdigit()):
        found = qs.filter(pk=int(value)).first()
        if found:
            return found
    text = str(value).strip()
    if not text:
        return None
    found = qs.filter(code__iexact=text).first()
    if found:
        return found
    compact = re.sub(r'\s+', ' ', text)
    for item in qs.order_by('sort_order', 'id'):
        if item.display_label.lower() == compact.lower():
            return item
        if item.backup_filename and item.backup_filename.lower() == compact.lower():
            return item
    lowered = compact.lower()
    for item in qs.order_by('sort_order', 'id'):
        if item.name.lower() == lowered or f'{item.name} {item.version}'.lower() == lowered:
            return item
        if item.version and item.version.lower() in lowered and item.name.lower() in lowered:
            return item
    return None


def assigned_os_templates(product):
    if not getattr(product, 'pk', None):
        return []
    manager = getattr(product, 'os_templates', None)
    if manager is None:
        return []
    return list(manager.all())


def product_os_templates(product, *, enabled_only=True):
    """产品可选系统版本：已绑定则用绑定集，否则返回全部启用模版。"""
    from .models import SystemOsTemplate

    assigned = assigned_os_templates(product)
    if assigned:
        items = [item for item in assigned if (not enabled_only or item.enabled)]
        items.sort(key=lambda item: (item.sort_order, item.id))
        return items
    qs = SystemOsTemplate.objects.all()
    if enabled_only:
        qs = qs.filter(enabled=True)
    return list(qs.order_by('sort_order', 'id'))


def product_allows_os_template(product, template) -> bool:
    if template is None:
        return True
    if not template.enabled:
        return False
    assigned = [item for item in assigned_os_templates(product) if item.enabled]
    if not assigned:
        return True
    return any(item.pk == template.pk for item in assigned)


def sync_os_image(template):
    """把中心模版同步到门户重装用的 OsImage，保持同一套系统版本。"""
    from service_manager.models import OsImage

    fields = {
        'code': template.code,
        'name': template.display_label,
        'os_type': template.os_type or infer_os_type(template.name),
        'version': template.version,
        'enabled': template.enabled,
        'sort_order': template.sort_order,
        'node_template_ref': (template.backup_filename or '')[:255],
        'description': (template.download_url or '')[:255],
        'os_template': template,
    }
    existing = OsImage.objects.filter(os_template=template).first()
    if existing is None:
        existing = OsImage.objects.filter(code=template.code).first()
    if existing is None:
        return OsImage.objects.create(**fields)
    for key, value in fields.items():
        setattr(existing, key, value)
    existing.save(update_fields=[*fields.keys(), 'updated_at'])
    return existing


def sync_all_os_images() -> int:
    from .models import SystemOsTemplate

    count = 0
    for template in SystemOsTemplate.objects.all():
        sync_os_image(template)
        count += 1
    return count
