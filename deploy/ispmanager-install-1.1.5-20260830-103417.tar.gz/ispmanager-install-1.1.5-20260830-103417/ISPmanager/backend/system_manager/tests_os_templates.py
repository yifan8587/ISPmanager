from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import UserProfile
from product_manager.models import Product
from resource_manager.models import City, Country, PopPoint, Region
from service_manager.models import OsImage
from system_manager.models import SystemOsTemplate
from system_manager.os_templates import match_os_template, product_os_templates


class SystemOsTemplateCatalogTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser('os-admin', 'os@example.test', 'password')
        self.client = APIClient()
        self.client.force_authenticate(self.admin)
        region = Region.objects.create(code='os-apac', name='系统模版区')
        country = Country.objects.create(region=region, name='系统模版国')
        city = City.objects.create(country=country, name='系统模版市')
        self.pop = PopPoint.objects.create(name='系统模版 POP', city=city)

    def test_create_syncs_os_image_and_lists_for_product_portal(self):
        response = self.client.post('/api/system/os-templates/', {
            'name': 'Ubuntu',
            'version': '22.04',
            'backup_filename': 'ubuntu-22.04.vma.zst',
            'download_url': 'http://mirror.example.com/ubuntu-22.04.vma.zst',
        }, format='json')
        self.assertEqual(response.status_code, 201, response.data)
        template = SystemOsTemplate.objects.get(pk=response.data['id'])
        self.assertEqual(template.os_type, 'ubuntu')
        self.assertEqual(template.code, 'ubuntu-2204')
        image = OsImage.objects.get(os_template=template)
        self.assertEqual(image.name, 'Ubuntu 22.04')
        self.assertEqual(image.node_template_ref, 'ubuntu-22.04.vma.zst')
        self.assertTrue(image.enabled)

        product = Product.objects.create(
            name='目录 VPS',
            status=Product.Status.ONLINE,
            pop_point=self.pop,
        )
        catalog = self.client.get('/api/product/products/os-templates/')
        self.assertEqual(catalog.status_code, 200)
        self.assertEqual(catalog.data[0]['label'], 'Ubuntu 22.04')

        portal = self.client.get('/api/portal/os-templates/')
        self.assertEqual(portal.status_code, 200)
        self.assertEqual(portal.data['data'][0]['id'], template.pk)

        product_portal = self.client.get(f'/api/portal/os-templates/?product_id={product.pk}')
        self.assertEqual(product_portal.status_code, 200)
        self.assertEqual(len(product_portal.data['data']), 1)

    def test_product_binding_filters_portal_catalog(self):
        ubuntu = SystemOsTemplate.objects.create(
            name='Ubuntu',
            version='22.04',
            backup_filename='ubuntu-22.04.vma.zst',
            download_url='http://mirror.example.com/ubuntu-22.04.vma.zst',
        )
        debian = SystemOsTemplate.objects.create(
            name='Debian',
            version='12',
            backup_filename='debian-12.vma.zst',
            download_url='http://mirror.example.com/debian-12.vma.zst',
        )
        product = Product.objects.create(
            name='仅 Debian VPS',
            status=Product.Status.ONLINE,
            pop_point=self.pop,
        )
        product.os_templates.set([debian])
        labels = [item.display_label for item in product_os_templates(product)]
        self.assertEqual(labels, ['Debian 12'])
        self.assertEqual(match_os_template('Ubuntu 22.04').pk, ubuntu.pk)
        self.assertEqual(match_os_template(debian.pk).pk, debian.pk)

        detail = self.client.get(f'/api/portal/products/{product.pk}/')
        self.assertEqual(detail.status_code, 200)
        self.assertEqual([item['id'] for item in detail.data['os_templates']], [debian.pk])
        self.assertEqual(detail.data['os_template_ids'], [debian.pk])

    def test_non_system_account_cannot_manage(self):
        user = User.objects.create_user('os-staff', password='SafePass_2026!')
        profile, _ = UserProfile.objects.get_or_create(user=user)
        profile.account_type = UserProfile.AccountType.CUSTOMER
        profile.save(update_fields=['account_type'])
        client = APIClient()
        client.force_authenticate(user)
        response = client.post('/api/system/os-templates/', {
            'name': 'Debian',
            'version': '11',
            'download_url': 'http://mirror.example.com/debian-11.vma.zst',
        }, format='json')
        self.assertIn(response.status_code, (403, 401))
