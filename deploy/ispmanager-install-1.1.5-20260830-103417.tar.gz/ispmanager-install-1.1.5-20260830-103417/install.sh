#!/usr/bin/env bash
# 安装包入口：转到部署脚本执行一键安装
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$ROOT/ISPmanager/deploy/scripts/install.sh" "$@"
