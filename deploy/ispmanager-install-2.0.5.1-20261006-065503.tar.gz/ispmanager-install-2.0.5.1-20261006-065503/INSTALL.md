# ISPmanager / ISPweb 安装部署包

目标系统：**Ubuntu 22.04 LTS**（亦支持 24.04），nginx 终止 HTTPS。  
版本：**2.0.0**。本包已含后端源码、管理端/门户 `dist`、部署脚本。**目标机无需安装 Node。**  
安装完成后会对齐网页在线升级权限（程序目录属主 + sudoers），后续版本可在管理端「系统维护」上传更新包自动覆盖。

配置只写在 `ISPmanager/deploy/.env` 与 `/etc/ispmanager.env`。

> 本包用于**全新安装**。已有生产环境请使用 `ispmanager-update-*.tar.gz` 与 `update.sh`，避免走完整安装流程。

## 一键安装

```bash
sudo mkdir -p /opt/app
sudo tar -xzf ispmanager-install-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app

sudo SITE_DOMAIN=www.example.net \
     CERTBOT_EMAIL=ops@example.net \
     bash install.sh
```

| `SSL_MODE` | 行为 |
|------------|------|
| `auto`（默认） | 域名 A 记录已指向本机则 Let's Encrypt，否则自签 |
| `letsencrypt` | 强制公网证书（80 必须对公网开放） |
| `selfsigned` | 自签，立即 HTTPS（浏览器会告警） |
| `skip` | 仅 HTTP |

- 站点域名的 **A 记录已指向服务器** 时，自动申请 Let's Encrypt，全站 HTTPS（门户 `/`、管理端 `/manager`、`/api/`、`/ws/`、`/admin/`）。
- DNS 未就绪时自动使用自签证书。之后执行：

```bash
sudo SSL_MODE=letsencrypt bash /opt/app/ISPmanager/deploy/scripts/setup-ssl.sh
```

首次超级管理员与数据库密码写入：`/root/ispmanager-credentials.txt`（权限 600）。

## 访问

- 客户门户：`https://站点域名/`
- 管理端：`https://站点域名/manager`
- Django Admin：`https://站点域名/admin/`
- API：`https://站点域名/api/`

前端请求同源 `/api` 与 `/ws`，由 nginx 反代到本机 gunicorn，无跨域。

## 分步安装

```bash
cd /opt/app/ISPmanager/deploy
cp .env.example .env
cd scripts
sudo bash 01-init-ubuntu.sh
sudo bash 02-setup-database.sh
bash build.sh
sudo bash deploy.sh
sudo bash setup-ssl.sh
sudo bash verify-install.sh
```

详见 `ISPmanager/deploy/README.md`。

## 已有环境请改用更新包

不要对本机已在跑的系统再跑本安装包的「覆盖解压 + install.sh」，除非你明确知道自己在做升级探测。  
推荐使用独立的全量更新包：

```bash
sudo mkdir -p /tmp/isp-update
sudo tar -xzf ispmanager-update-*.tar.gz -C /tmp/isp-update --strip-components=1
sudo bash /tmp/isp-update/update.sh --root /opt/app
```

更新包只覆盖程序，不改写客户、订单、账单、上传文件与密钥。
