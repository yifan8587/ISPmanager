"""产品网络类型 / ASN 从 IP 地址块读取，不再取 POP 字段。"""
from decimal import Decimal

from django.test import TestCase

from product_manager.models import Product
from product_manager.serializers import ProductListSerializer
from product_manager.views import ProductFilter
from resource_manager.models import (
    AsnNature, City, Country, IPAddress, IPAttribute, IPBlock, NetworkTypeOption, PopPoint, Region,
)


class ProductIpBlockAttrTests(TestCase):
    def setUp(self):
        NetworkTypeOption.objects.get_or_create(
            code='idc', defaults={'name': 'IDC', 'sort_order': 0},
        )
        NetworkTypeOption.objects.get_or_create(
            code='home_broadband', defaults={'name': '家宽', 'sort_order': 1},
        )
        region = Region.objects.create(code='ip-attr', name='属性区')
        country = Country.objects.create(region=region, name='属性国')
        city = City.objects.create(country=country, name='属性市')
        self.pop = PopPoint.objects.create(
            name='属性 POP', city=city,
            network_type='idc',
            asn_nature=AsnNature.ISP,
        )
        self.product = Product.objects.create(
            name='属性产品',
            status=Product.Status.ONLINE,
            pop_point=self.pop,
            monthly_price=Decimal('10.00'),
        )

    def test_ip_block_defaults_to_single_isp_and_idc(self):
        block = IPBlock.objects.create(pop_point=self.pop, cidr='203.0.113.0/24')
        self.assertEqual(block.network_type, 'idc')
        self.assertEqual(block.asn_nature, AsnNature.ISP)
        self.assertEqual(block.get_asn_nature_display(), '单ISP')

    def _add_address(self, block, host='198.51.100.10'):
        return IPAddress.objects.create(ip_block=block, address=host)

    def test_product_list_reads_ip_list_not_pop(self):
        self.pop.network_type = 'idc'
        self.pop.asn_nature = AsnNature.ISP
        self.pop.save(update_fields=['network_type', 'asn_nature'])
        block = IPBlock.objects.create(
            pop_point=self.pop, cidr='198.51.100.0/24',
            network_type='home_broadband', asn_nature=AsnNature.DUAL_ISP,
            ip_attribute=IPAttribute.BROADCAST,
        )
        self._add_address(block)
        data = ProductListSerializer(self.product).data
        self.assertEqual(data['network_type'], 'home_broadband')
        self.assertEqual(data['network_type_label'], '家宽')
        self.assertEqual(data['asn_nature'], AsnNature.DUAL_ISP)
        self.assertEqual(data['asn_nature_label'], '双ISP')
        self.assertEqual([x['value'] for x in data['network_types']], ['home_broadband'])
        self.assertEqual([x['value'] for x in data['asn_natures']], [AsnNature.DUAL_ISP])
        self.assertEqual(data['ip_attributes'], [IPAttribute.BROADCAST])

    def test_product_ignores_blocks_without_ip_list_and_tunnel_blocks(self):
        IPBlock.objects.create(
            pop_point=self.pop, cidr='203.0.113.0/24',
            network_type='idc', asn_nature=AsnNature.ISP,
        )
        tunnel = IPBlock.objects.create(
            pop_point=self.pop, cidr='198.51.100.0/24',
            network_type='home_broadband', asn_nature=AsnNature.DUAL_ISP,
            description='[边缘隧道段] 测试',
        )
        self._add_address(tunnel, '198.51.100.10')
        data = ProductListSerializer(self.product).data
        self.assertEqual(data['network_types'], [])
        self.assertEqual(data['asn_natures'], [])
        self.assertEqual(data['ip_attributes'], [])

    def test_product_filter_uses_ip_list(self):
        block = IPBlock.objects.create(
            pop_point=self.pop, cidr='198.51.100.0/24',
            network_type='home_broadband', asn_nature=AsnNature.NON_ISP,
            ip_attribute=IPAttribute.NATIVE,
        )
        self._add_address(block)
        qs = Product.objects.all()
        self.assertEqual(ProductFilter({'network_type': 'home_broadband'}, queryset=qs).qs.count(), 1)
        self.assertEqual(ProductFilter({'network_type': 'idc'}, queryset=qs).qs.count(), 0)
        self.assertEqual(ProductFilter({'asn_nature': 'non_isp'}, queryset=qs).qs.count(), 1)
        self.assertEqual(ProductFilter({'asn_nature': 'isp'}, queryset=qs).qs.count(), 0)

    def test_product_without_ip_blocks_has_empty_network_attrs(self):
        data = ProductListSerializer(self.product).data
        self.assertEqual(data['network_type'], '')
        self.assertEqual(data['asn_nature'], '')
        self.assertEqual(data['network_types'], [])
        self.assertEqual(data['asn_natures'], [])
