"""IP 地址块上的网络类型 / ASN 聚合，供产品与门户展示、筛选。"""
from __future__ import annotations

from .models import AsnNature, IPAttribute, NetworkType, NetworkTypeOption

ASN_DISPLAY_ORDER = (AsnNature.NON_ISP, AsnNature.ISP, AsnNature.DUAL_ISP)
IP_ATTR_DISPLAY_ORDER = (IPAttribute.BROADCAST, IPAttribute.NATIVE)


def sort_by_display_order(items, order, key='value'):
    rank = {code: index for index, code in enumerate(order)}
    return sorted(items, key=lambda item: rank.get(item.get(key) if isinstance(item, dict) else item, 50))


def asn_nature_label(code: str) -> str:
    if not code:
        return ''
    return dict(AsnNature.choices).get(code, code)


class NetworkAttrCatalog:
    """一次查出网络类型目录，供列表序列化复用。"""

    def __init__(self):
        self.labels = dict(NetworkType.choices)
        self.order = {}
        self._pop_cache = {}
        for opt in NetworkTypeOption.objects.all():
            self.labels[opt.code] = opt.name
            self.order[opt.code] = opt.sort_order

    def network_type_label(self, code: str) -> str:
        if not code:
            return ''
        return self.labels.get(code, code)

    def collect(self, pop):
        """从该 POP 的 IP 列表聚合网络类型、ASN 和 IP 属性。

        只统计 IP 管理里能看到的业务地址：排除隧道段和停用地址块，
        并且地址块下至少有一条 IP。不再读取 POP 自身的网络类型 / ASN。
        """
        empty = {
            'network_types': [],
            'asn_natures': [],
            'ip_attributes': [],
            'network_type': '',
            'network_type_label': '',
            'asn_nature': '',
            'asn_nature_label': '',
        }
        if pop is None:
            return empty
        cached = self._pop_cache.get(pop.pk)
        if cached is not None:
            return cached

        from .ip_scope import exclude_tunnel_blocks
        from .models import IPBlock

        rows = exclude_tunnel_blocks(
            IPBlock.objects.filter(pop_point=pop, ip_addresses__isnull=False)
        ).exclude(is_active=False).values(
            'network_type', 'asn_nature', 'ip_attribute',
        ).distinct()

        network_types = []
        asn_natures = []
        ip_attributes = []
        seen_nt = set()
        seen_asn = set()
        seen_attr = set()
        for row in rows:
            nt = (row.get('network_type') or '').strip()
            if nt and nt not in seen_nt:
                seen_nt.add(nt)
                network_types.append({
                    'value': nt,
                    'label': self.network_type_label(nt),
                })
            asn = (row.get('asn_nature') or '').strip()
            if asn and asn not in seen_asn:
                seen_asn.add(asn)
                asn_natures.append({
                    'value': asn,
                    'label': asn_nature_label(asn),
                })
            attr = (row.get('ip_attribute') or '').strip()
            if attr and attr not in seen_attr:
                seen_attr.add(attr)
                ip_attributes.append(attr)

        network_types.sort(key=lambda item: (self.order.get(item['value'], 999), item['value']))
        asn_natures[:] = sort_by_display_order(asn_natures, ASN_DISPLAY_ORDER)
        ip_attributes[:] = sort_by_display_order(ip_attributes, IP_ATTR_DISPLAY_ORDER)
        primary_nt = network_types[0] if network_types else None
        primary_asn = asn_natures[0] if asn_natures else None
        result = {
            'network_types': network_types,
            'asn_natures': asn_natures,
            'ip_attributes': ip_attributes,
            'network_type': primary_nt['value'] if primary_nt else '',
            'network_type_label': primary_nt['label'] if primary_nt else '',
            'asn_nature': primary_asn['value'] if primary_asn else '',
            'asn_nature_label': primary_asn['label'] if primary_asn else '',
        }
        self._pop_cache[pop.pk] = result
        return result


def catalog_from_context(context: dict | None) -> NetworkAttrCatalog:
    ctx = context if context is not None else {}
    cat = ctx.get('_network_attr_catalog')
    if cat is None:
        cat = NetworkAttrCatalog()
        ctx['_network_attr_catalog'] = cat
    return cat


def collect_product_network_attrs(product, context: dict | None = None, *, refresh: bool = False) -> dict:
    cat = catalog_from_context(context)
    if refresh:
        cat._pop_cache.pop(getattr(product, 'pop_point_id', None), None)
        if hasattr(product, '_ip_block_network_attrs'):
            del product._ip_block_network_attrs
    cache = getattr(product, '_ip_block_network_attrs', None)
    if cache is None:
        pop = product.pop_point if getattr(product, 'pop_point_id', None) else None
        cache = cat.collect(pop)
        product._ip_block_network_attrs = cache
    return cache
