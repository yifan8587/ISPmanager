#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# 01-init-ubuntu.sh — 初始化 Ubuntu 24.04 生产环境
#   安装 nginx / MySQL 8 / Python 3.12 / Node.js 20 / certbot 及编译依赖
# 用法：sudo bash 01-init-ubuntu.sh
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env
require_root

step "1/7 检查系统版本"
if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    log "检测到系统：$PRETTY_NAME"
    [[ "$VERSION_ID" == "24.04" ]] || warn "本脚本针对 Ubuntu 24.04 编写，当前为 $VERSION_ID，继续执行但请留意兼容性"
fi

export DEBIAN_FRONTEND=noninteractive

step "2/7 更新 APT 源并安装基础工具"
apt-get update -y
apt-get install -y \
    ca-certificates curl wget gnupg lsb-release \
    build-essential pkg-config git rsync ufw

step "3/7 安装 Python 3.12 与构建 mysqlclient 所需依赖"
apt-get install -y \
    python3 python3-venv python3-dev \
    default-libmysqlclient-dev libssl-dev
log "Python 版本：$(python3 --version)"

step "4/7 安装 Node.js 20 (NodeSource)"
if ! command -v node >/dev/null 2>&1 || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
log "Node 版本：$(node -v)  npm 版本：$(npm -v)"

step "5/7 安装 MySQL Server"
if ! command -v mysqld >/dev/null 2>&1 && ! dpkg -l | grep -q mysql-server; then
    apt-get install -y mysql-server
fi
systemctl enable --now mysql 2>/dev/null || systemctl enable --now mysql.service || true
ok "MySQL 已安装并启动"

step "6/7 安装 nginx 与 certbot"
apt-get install -y nginx certbot python3-certbot-nginx
systemctl enable --now nginx
ok "nginx 已安装并启动"

step "7/7 创建运行用户与防火墙规则"
if ! id "$APP_USER" >/dev/null 2>&1; then
    useradd --system --create-home --shell /usr/sbin/nologin "$APP_USER"
    ok "已创建系统用户：$APP_USER"
else
    log "系统用户已存在：$APP_USER"
fi

# 防火墙（若启用 ufw）：放行 SSH / HTTP / HTTPS
if command -v ufw >/dev/null 2>&1; then
    ufw allow OpenSSH >/dev/null 2>&1 || true
    ufw allow 'Nginx Full' >/dev/null 2>&1 || true
    log "已放行 ufw：OpenSSH / Nginx Full（如未启用 ufw 可忽略）"
fi

echo
ok "════════════════════════════════════════════════════"
ok " Ubuntu 24.04 初始化完成"
ok "════════════════════════════════════════════════════"
echo -e "  下一步："
echo -e "   1) 安全加固 MySQL（可选）：sudo mysql_secure_installation"
echo -e "   2) 初始化数据库：       sudo bash 02-setup-database.sh"
echo -e "   3) 打包构建：           bash build.sh"
echo -e "   4) 部署应用：           sudo bash deploy.sh"
