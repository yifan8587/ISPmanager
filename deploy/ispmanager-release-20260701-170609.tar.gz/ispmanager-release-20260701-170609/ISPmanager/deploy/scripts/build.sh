#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# build.sh — 自动化打包：后端依赖 + 两个前端构建 + collectstatic
#   可无 root 运行（仅构建产物，不写系统目录）
# 用法：bash build.sh
#   可选：BUILD_ARCHIVE=1 bash build.sh   额外生成发布 tar.gz
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env

# SKIP_FRONTEND_BUILD=1 时复用已存在的 dist（用于携带预构建产物的发布包快速部署，免装 Node）
SKIP_FRONTEND_BUILD="${SKIP_FRONTEND_BUILD:-0}"

step "0/5 环境检查"
[[ -d "$BACKEND_DIR" ]] || die "后端目录不存在：$BACKEND_DIR"
if [[ "$SKIP_FRONTEND_BUILD" != "1" ]]; then
    command -v node >/dev/null 2>&1 || die "未找到 node，请先执行 01-init-ubuntu.sh（或设置 SKIP_FRONTEND_BUILD=1 复用已构建 dist）"
    command -v npm  >/dev/null 2>&1 || die "未找到 npm"
else
    log "SKIP_FRONTEND_BUILD=1：跳过前端构建，复用已有 dist"
fi
log "PROJECT_ROOT = $PROJECT_ROOT"

# ── 后端 venv 与依赖 ────────────────────────────────────────────
step "1/5 后端 Python 虚拟环境与依赖"
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    log "创建虚拟环境：$VENV_DIR"
    python3 -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/pip" install --upgrade pip wheel >/dev/null
log "安装后端依赖 requirements.txt ..."
"$VENV_DIR/bin/pip" install -r "$BACKEND_DIR/requirements.txt"
ok "后端依赖安装完成"

# ── 管理端前端构建 ──────────────────────────────────────────────
step "2/5 构建管理端前端（ISPmanager/frontend）"
if [[ "$SKIP_FRONTEND_BUILD" == "1" ]]; then
    [[ -d "$ADMIN_FRONTEND_DIR/dist" ]] && ok "复用已有管理端 dist" || warn "未找到管理端 dist：$ADMIN_FRONTEND_DIR/dist"
elif [[ -d "$ADMIN_FRONTEND_DIR" ]]; then
    pushd "$ADMIN_FRONTEND_DIR" >/dev/null
    if [[ -f package-lock.json ]]; then npm ci || npm install; else npm install; fi
    npm run build
    popd >/dev/null
    ok "管理端构建产物：$ADMIN_FRONTEND_DIR/dist"
else
    warn "未找到管理端目录 $ADMIN_FRONTEND_DIR，跳过"
fi

# ── 客户门户前端构建 ────────────────────────────────────────────
step "3/5 构建客户门户前端（ISPweb）"
if [[ "$SKIP_FRONTEND_BUILD" == "1" ]]; then
    [[ -d "$PORTAL_FRONTEND_DIR/dist" ]] && ok "复用已有门户 dist" || warn "未找到门户 dist：$PORTAL_FRONTEND_DIR/dist"
elif [[ -d "$PORTAL_FRONTEND_DIR" ]]; then
    pushd "$PORTAL_FRONTEND_DIR" >/dev/null
    if [[ -f package-lock.json ]]; then npm ci || npm install; else npm install; fi
    npm run build
    popd >/dev/null
    ok "客户门户构建产物：$PORTAL_FRONTEND_DIR/dist"
else
    warn "未找到客户门户目录 $PORTAL_FRONTEND_DIR，跳过"
fi

# ── 后端 collectstatic（Django admin / DRF 静态资源）────────────
step "4/5 收集 Django 静态资源 collectstatic"
mkdir -p "$DJANGO_STATIC_ROOT" "$DJANGO_MEDIA_ROOT"
pushd "$BACKEND_DIR" >/dev/null
DJANGO_STATIC_ROOT="$DJANGO_STATIC_ROOT" \
DJANGO_MEDIA_ROOT="$DJANGO_MEDIA_ROOT" \
    "$VENV_DIR/bin/python" manage.py collectstatic --noinput --clear
popd >/dev/null
ok "静态资源已收集到：$DJANGO_STATIC_ROOT"

# ── 可选：生成发布归档 ──────────────────────────────────────────
step "5/5 打包"
if [[ "${BUILD_ARCHIVE:-0}" == "1" ]]; then
    ARCHIVE="$DEPLOY_DIR/dist-ispmanager-$(date +%Y%m%d%H%M%S).tar.gz"
    log "生成发布归档：$ARCHIVE"
    tar -czf "$ARCHIVE" \
        -C "$PROJECT_ROOT" \
        --exclude='ISPmanager/venv' \
        --exclude='**/node_modules' \
        --exclude='**/.git' \
        ISPmanager/backend ISPmanager/frontend/dist ISPweb/dist 2>/dev/null || \
    tar -czf "$ARCHIVE" -C "$PROJECT_ROOT" \
        --exclude='ISPmanager/venv' \
        --exclude='node_modules' \
        ISPmanager ISPweb/dist
    ok "发布归档：$ARCHIVE"
else
    log "如需生成发布归档：BUILD_ARCHIVE=1 bash build.sh"
fi

echo
ok "════════════════════════════════════════════════════"
ok " 打包构建完成"
ok "════════════════════════════════════════════════════"
echo -e "  后端依赖：$VENV_DIR"
echo -e "  管理端：  $ADMIN_FRONTEND_DIR/dist"
echo -e "  门户端：  $PORTAL_FRONTEND_DIR/dist"
echo -e "  静态资源：$DJANGO_STATIC_ROOT"
echo -e "  下一步：  sudo bash deploy.sh"
