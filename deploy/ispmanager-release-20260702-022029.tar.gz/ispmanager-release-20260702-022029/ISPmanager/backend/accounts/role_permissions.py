"""
accounts/role_permissions.py
权限组定义 & 角色 → 权限映射

权限码层级（由粗到细，上级可覆盖下级）：
  1. 模块级：resource.view / resource.manage
  2. 页面级：resource.pop.view / resource.pop.manage
  3. 配置分类：system.settings.general.view
  4. 配置项：system.setting.site_name.manage
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from system_manager.default_settings import DEFAULT_SYSTEM_SETTINGS


# ── 模块级权限常量（兼容旧版）──────────────────────────────────

class Perm:
    ACCOUNTS_VIEW = 'accounts.view'
    ACCOUNTS_MANAGE = 'accounts.manage'
    CUSTOMER_VIEW = 'customer.view'
    CUSTOMER_MANAGE = 'customer.manage'
    BILLING_VIEW = 'billing.view'
    BILLING_MANAGE = 'billing.manage'
    RESOURCE_VIEW = 'resource.view'
    RESOURCE_MANAGE = 'resource.manage'
    SERVICE_VIEW = 'service.view'
    SERVICE_MANAGE = 'service.manage'
    PRODUCT_VIEW = 'product.view'
    PRODUCT_MANAGE = 'product.manage'
    SUPPLIER_VIEW = 'supplier.view'
    SUPPLIER_MANAGE = 'supplier.manage'
    OPERATION_VIEW = 'operation.view'
    OPERATION_MANAGE = 'operation.manage'
    SYSTEM_VIEW = 'system.view'
    SYSTEM_MANAGE = 'system.manage'


MODULE_PERMISSIONS: frozenset[str] = frozenset({
    Perm.ACCOUNTS_VIEW, Perm.ACCOUNTS_MANAGE,
    Perm.CUSTOMER_VIEW, Perm.CUSTOMER_MANAGE,
    Perm.BILLING_VIEW, Perm.BILLING_MANAGE,
    Perm.RESOURCE_VIEW, Perm.RESOURCE_MANAGE,
    Perm.SERVICE_VIEW, Perm.SERVICE_MANAGE,
    Perm.PRODUCT_VIEW, Perm.PRODUCT_MANAGE,
    Perm.SUPPLIER_VIEW, Perm.SUPPLIER_MANAGE,
    Perm.OPERATION_VIEW, Perm.OPERATION_MANAGE,
    Perm.SYSTEM_VIEW, Perm.SYSTEM_MANAGE,
})

VIEW_PERMISSIONS: frozenset[str] = frozenset(
    p for p in MODULE_PERMISSIONS if p.endswith('.view')
)
MANAGE_PERMISSIONS: frozenset[str] = frozenset(
    p for p in MODULE_PERMISSIONS if p.endswith('.manage')
)


# ── 页面注册表（原子页面权限）──────────────────────────────────

PAGE_REGISTRY: dict[str, dict] = {
    'accounts': {
        'label': '账号管理',
        'description': '系统用户、角色与 API Token',
        'pages': {
            'user': {'label': '用户管理', 'route': '/system/users'},
            'role': {'label': '权限管理', 'route': '/system/roles'},
        },
    },
    'customer': {
        'label': '客户管理',
        'description': '客户档案、合同与联系记录',
        'pages': {
            'list': {'label': '客户列表', 'route': '/customer/list'},
            'contract': {'label': '合同管理', 'route': '/customer/contracts'},
            'detail': {'label': '客户详情', 'route': '/customer/:id'},
        },
    },
    'billing': {
        'label': '账单管理',
        'description': '客户账单与收款登记',
        'pages': {
            'list': {'label': '账单管理', 'route': '/customer/billings'},
        },
    },
    'resource': {
        'label': '资源管理',
        'description': 'POP 节点、VPS、IP、带宽等资源',
        'pages': {
            'pop': {'label': 'POP 节点', 'route': '/resource/pop'},
            'pop_deploy': {'label': 'POP 部署', 'route': '/resource/pop/:id/deploy'},
            'ip': {'label': 'IP 管理', 'route': '/resource/ip'},
            'vps': {'label': 'VPS 管理', 'route': '/resource/vps'},
            'vps_console': {'label': 'VPS 控制台', 'route': '/resource/vps/:id/console'},
            'edge': {'label': '边缘加速', 'route': '/resource/edge'},
            'bandwidth': {'label': '带宽管理', 'route': '/resource/bandwidth'},
        },
    },
    'operation': {
        'label': '运维管理',
        'description': '监控、流量计费与运维工具',
        'pages': {
            'monitor_hosts': {'label': '监控主机', 'route': '/operation/monitoring/hosts'},
            'monitor_graphs': {'label': '监控图形', 'route': '/operation/monitoring/hosts/:id/graphs'},
            'traffic': {'label': '流量计费', 'route': '/operation/monitoring/traffic'},
            'traffic_profile': {'label': '计费规则', 'route': '/operation/monitoring/profiles'},
            'zabbix': {'label': 'Zabbix 服务器', 'route': '/operation/monitoring/zabbix'},
            'webssh': {'label': 'WebSSH', 'route': '/operation/tools/webssh'},
            'template': {'label': '命令模版', 'route': '/operation/tools/templates'},
        },
    },
    'service': {
        'label': '服务管理',
        'description': '服务套餐、工单与实例',
        'pages': {
            'order': {'label': '服务工单', 'route': '/service/orders'},
            'instance': {'label': '服务实例', 'route': '/service/instances'},
            'plan': {'label': '套餐管理', 'route': '/service/plans'},
            'change': {'label': '变更记录', 'route': '/service/changes'},
        },
    },
    'product': {
        'label': '产品管理',
        'description': '产品规格、模版、定价与发布',
        'pages': {
            'spec': {'label': '产品规格', 'route': '/product/specs'},
            'template': {'label': '产品模版', 'route': '/product/templates'},
            'product': {'label': '产品列表', 'route': '/product/products'},
            'publish': {'label': '产品发布', 'route': '/product/publish'},
        },
    },
    'supplier': {
        'label': '供应商管理',
        'description': '供应商档案、API 对接与资源同步',
        'pages': {
            'list': {'label': '供应商列表', 'route': '/supplier/list'},
            'api': {'label': '供应商API', 'route': '/supplier/apis'},
            'resource': {'label': '供应商资源', 'route': '/supplier/resources'},
        },
    },
    'system': {
        'label': '系统设置',
        'description': '全局参数、安全策略与集成配置',
        'pages': {
            'settings': {'label': '参数配置', 'route': '/system/settings'},
        },
    },
}

SETTING_CATEGORY_LABELS: dict[str, str] = {
    'general': '基本设置',
    'billing': '账单设置',
    'security': '安全设置',
    'notification': '通知设置',
    'integration': '集成设置',
}

SETTING_KEY_META: dict[str, dict] = {
    item['key']: {
        'label': item['label'],
        'category': item['category'],
        'description': item.get('description', ''),
    }
    for item in DEFAULT_SYSTEM_SETTINGS
}


def page_permission(module: str, page: str, action: str) -> str:
    return f'{module}.{page}.{action}'


def setting_category_permission(category: str, action: str) -> str:
    return f'system.settings.{category}.{action}'


def setting_key_permission(key: str, action: str) -> str:
    return f'system.setting.{key}.{action}'


def _build_page_permissions() -> dict[str, str]:
    perms: dict[str, str] = {}
    for module, mod in PAGE_REGISTRY.items():
        for page_key, page in mod['pages'].items():
            perms[page_permission(module, page_key, 'view')] = f"查看{page['label']}"
            perms[page_permission(module, page_key, 'manage')] = f"管理{page['label']}"
    return perms


def _build_setting_permissions() -> dict[str, str]:
    perms: dict[str, str] = {}
    perms['system.settings.view'] = '查看参数配置页'
    perms['system.settings.manage'] = '管理参数配置页'
    for cat, label in SETTING_CATEGORY_LABELS.items():
        perms[setting_category_permission(cat, 'view')] = f'查看{label}'
        perms[setting_category_permission(cat, 'manage')] = f'修改{label}'
    for key, meta in SETTING_KEY_META.items():
        perms[setting_key_permission(key, 'view')] = f"查看「{meta['label']}」"
        perms[setting_key_permission(key, 'manage')] = f"修改「{meta['label']}」"
    return perms


PAGE_PERMISSIONS: dict[str, str] = _build_page_permissions()
SETTING_PERMISSIONS: dict[str, str] = _build_setting_permissions()
ATOMIC_PERMISSIONS: frozenset[str] = frozenset(PAGE_PERMISSIONS) | frozenset(SETTING_PERMISSIONS)
ALL_PERMISSIONS: frozenset[str] = MODULE_PERMISSIONS | ATOMIC_PERMISSIONS


# ── 权限层级解析 ──────────────────────────────────────────────

def _module_pages(module: str) -> Iterable[str]:
    from .permission_service import db_is_initialized, get_module_page_keys
    if db_is_initialized():
        return get_module_page_keys(module)
    return PAGE_REGISTRY.get(module, {}).get('pages', {}).keys()


def expand_permissions(perms: Iterable[str]) -> frozenset[str]:
    """将模块级权限展开为页面/配置原子权限，并补全 manage→view。"""
    expanded: set[str] = set()
    for perm in perms:
        expanded.add(perm)
        parts = perm.split('.')
        if len(parts) == 2:
            module, action = parts
            for page in _module_pages(module):
                expanded.add(page_permission(module, page, action))
            if module == 'system':
                expanded.add(f'system.settings.{action}')
                for cat in SETTING_CATEGORY_LABELS:
                    expanded.add(setting_category_permission(cat, action))
                for key in SETTING_KEY_META:
                    expanded.add(setting_key_permission(key, action))
        elif len(parts) == 3 and perm.endswith('.manage'):
            expanded.add(perm[:-7] + '.view')
        elif len(parts) == 4 and parts[1] == 'settings' and perm.endswith('.manage'):
            expanded.add(perm[:-7] + '.view')
        elif len(parts) == 4 and parts[1] == 'setting' and perm.endswith('.manage'):
            expanded.add(perm[:-7] + '.view')
    return frozenset(expanded)


def permission_satisfies(held: str, required: str) -> bool:
    """判断 held 权限是否满足 required 权限要求。"""
    if held == required:
        return True
    if required.endswith('.view') and held == f'{required[:-5]}.manage':
        return True

    h = held.split('.')
    r = required.split('.')

    # 模块级 → 页面/配置
    if len(h) == 2 and len(r) >= 3:
        if h[0] == r[0] and h[1] == r[-1]:
            return True

    # 页面级 → 模块级（反向，用于 API 仍校验 module.manage）
    if len(h) == 3 and len(r) == 2:
        return h[0] == r[0] and h[2] == r[1]

    # system.settings.manage → system.settings.general.manage / system.setting.key.manage
    if len(h) == 3 and h[0] == 'system' and h[1] == 'settings' and len(r) == 4:
        if r[1] == 'settings' and h[2] == r[3]:
            return True
        if r[1] == 'setting' and h[2] == r[3]:
            return True

    # system.settings.{cat}.manage → system.setting.{key}.manage
    if len(h) == 4 and h[1] == 'settings' and len(r) == 4 and r[1] == 'setting':
        key = r[2]
        from .permission_service import get_setting_key_category
        cat = get_setting_key_category(key)
        return bool(cat and cat == h[2] and h[3] == r[3])

    return False


def user_effective_permissions(profile) -> frozenset[str]:
    from .permission_service import db_is_initialized, get_all_active_permission_codes, get_role_permissions as db_get_role_permissions

    user = profile.user
    if user.is_superuser:
        if db_is_initialized():
            return get_all_active_permission_codes()
        return ALL_PERMISSIONS
    if profile.account_type == 'customer':
        return expand_permissions(CUSTOMER_ACCOUNT_PERMISSIONS)
    perms = set(db_get_role_permissions(profile.role))
    if user.is_staff:
        perms |= {Perm.ACCOUNTS_VIEW, Perm.ACCOUNTS_MANAGE}
    return expand_permissions(perms)


# ── 权限组（供前端展示）────────────────────────────────────────

def _serialize_module_group(module_key: str, mod: dict) -> dict:
    pages = []
    for page_key, page in mod['pages'].items():
        pages.append({
            'key': page_key,
            'label': page['label'],
            'route': page.get('route', ''),
            'permissions': [
                {'code': page_permission(module_key, page_key, 'view'), 'label': f"查看{page['label']}", 'action': 'view'},
                {'code': page_permission(module_key, page_key, 'manage'), 'label': f"管理{page['label']}", 'action': 'manage'},
            ],
        })
    group = {
        'key': module_key,
        'label': mod['label'],
        'description': mod['description'],
        'pages': pages,
        'permissions': [
            {'code': f'{module_key}.view', 'label': f"查看{mod['label']}", 'action': 'view', 'scope': 'module'},
            {'code': f'{module_key}.manage', 'label': f"管理{mod['label']}", 'action': 'manage', 'scope': 'module'},
        ],
    }
    if module_key == 'system':
        settings_pages = [{
            'key': 'settings',
            'label': '参数配置',
            'route': '/system/settings',
            'permissions': [
                {'code': 'system.settings.view', 'label': '查看参数配置页', 'action': 'view'},
                {'code': 'system.settings.manage', 'label': '管理参数配置页', 'action': 'manage'},
            ],
            'categories': [
                {
                    'key': cat,
                    'label': label,
                    'permissions': [
                        {'code': setting_category_permission(cat, 'view'), 'label': f'查看{label}', 'action': 'view'},
                        {'code': setting_category_permission(cat, 'manage'), 'label': f'修改{label}', 'action': 'manage'},
                    ],
                    'settings': [
                        {
                            'key': key,
                            'label': meta['label'],
                            'permissions': [
                                {'code': setting_key_permission(key, 'view'), 'label': f"查看「{meta['label']}」", 'action': 'view'},
                                {'code': setting_key_permission(key, 'manage'), 'label': f"修改「{meta['label']}」", 'action': 'manage'},
                            ],
                        }
                        for key, meta in SETTING_KEY_META.items()
                        if meta['category'] == cat
                    ],
                }
                for cat, label in SETTING_CATEGORY_LABELS.items()
            ],
        }]
        group['pages'] = settings_pages
    return group


PERMISSION_GROUPS: dict[str, dict] = {
    key: _serialize_module_group(key, mod)
    for key, mod in PAGE_REGISTRY.items()
}


# ── 角色 → 权限组映射 ────────────────────────────────────────

ROLE_PERMISSIONS: dict[str, frozenset[str]] = {
    'superadmin': ALL_PERMISSIONS,
    'admin': ALL_PERMISSIONS,
    'customer_manager': frozenset({
        Perm.CUSTOMER_VIEW, Perm.CUSTOMER_MANAGE,
        Perm.BILLING_VIEW, Perm.BILLING_MANAGE,
        Perm.SERVICE_VIEW,
        page_permission('service', 'order', 'view'),
        page_permission('service', 'instance', 'view'),
        Perm.RESOURCE_VIEW,
        page_permission('resource', 'pop', 'view'),
        page_permission('resource', 'vps', 'view'),
    }),
    'operator': frozenset({
        Perm.RESOURCE_VIEW, Perm.RESOURCE_MANAGE,
        Perm.OPERATION_VIEW, Perm.OPERATION_MANAGE,
        Perm.SERVICE_VIEW, Perm.SERVICE_MANAGE,
        Perm.PRODUCT_VIEW, Perm.PRODUCT_MANAGE,
        Perm.SUPPLIER_VIEW, Perm.SUPPLIER_MANAGE,
    }),
    'sales': frozenset({
        Perm.CUSTOMER_VIEW, Perm.CUSTOMER_MANAGE,
        Perm.BILLING_VIEW,
        Perm.SERVICE_VIEW,
        page_permission('service', 'order', 'view'),
        page_permission('service', 'instance', 'view'),
        Perm.PRODUCT_VIEW,
        Perm.SUPPLIER_VIEW,
    }),
    'readonly': VIEW_PERMISSIONS,
}

CUSTOMER_ACCOUNT_PERMISSIONS: frozenset[str] = frozenset({
    Perm.CUSTOMER_VIEW,
    page_permission('customer', 'detail', 'view'),
    Perm.BILLING_VIEW,
    Perm.SERVICE_VIEW,
    page_permission('service', 'order', 'view'),
    page_permission('service', 'instance', 'view'),
    Perm.RESOURCE_VIEW,
    page_permission('resource', 'vps', 'view'),
    page_permission('resource', 'edge', 'view'),
})

CUSTOMER_ACCOUNT_ALLOWED_ROLES: frozenset[str] = frozenset({'readonly'})

ROLE_LABELS: dict[str, str] = {
    'superadmin': '超级管理员',
    'admin': '管理员',
    'customer_manager': '客户管理员',
    'operator': '运营人员',
    'sales': '销售人员',
    'readonly': '只读用户',
}


@dataclass(frozen=True)
class RoleDefinition:
    value: str
    label: str
    description: str
    permission_groups: tuple[str, ...]
    permissions: frozenset[str]


ROLE_DEFINITIONS: tuple[RoleDefinition, ...] = (
    RoleDefinition(
        'superadmin', '超级管理员',
        '拥有系统全部权限，可管理账号与所有业务模块',
        tuple(PAGE_REGISTRY.keys()),
        ROLE_PERMISSIONS['superadmin'],
    ),
    RoleDefinition(
        'admin', '管理员',
        '拥有全部业务权限，可管理系统用户',
        tuple(PAGE_REGISTRY.keys()),
        ROLE_PERMISSIONS['admin'],
    ),
    RoleDefinition(
        'customer_manager', '客户管理员',
        '负责客户档案、合同、账单及售前售后支撑',
        ('customer', 'billing', 'service', 'resource'),
        ROLE_PERMISSIONS['customer_manager'],
    ),
    RoleDefinition(
        'operator', '运营人员',
        '负责 POP/VPS/IP/带宽等资源及运维监控',
        ('resource', 'operation', 'service', 'product', 'supplier'),
        ROLE_PERMISSIONS['operator'],
    ),
    RoleDefinition(
        'sales', '销售人员',
        '负责客户拓展与跟进，可查看账单与服务概况',
        ('customer', 'billing', 'service', 'product'),
        ROLE_PERMISSIONS['sales'],
    ),
    RoleDefinition(
        'readonly', '只读用户',
        '所有模块只读，不可变更数据',
        tuple(PAGE_REGISTRY.keys()),
        ROLE_PERMISSIONS['readonly'],
    ),
)


def get_role_permissions(role: str) -> frozenset[str]:
    from .permission_service import db_is_initialized, get_role_permissions as db_get_role_permissions
    if db_is_initialized():
        return db_get_role_permissions(role)
    return ROLE_PERMISSIONS.get(role, frozenset())


def get_permissions_for_user(profile) -> frozenset[str]:
    return user_effective_permissions(profile)


def user_has_permission(profile, permission: str) -> bool:
    if profile.user.is_superuser:
        return True
    effective = user_effective_permissions(profile)
    return any(permission_satisfies(held, permission) for held in effective)


def user_has_any_permission(profile, permissions: Iterable[str]) -> bool:
    return any(user_has_permission(profile, p) for p in permissions)


def check_setting_manage_permission(profile, setting_key: str) -> bool:
    return user_has_permission(profile, setting_key_permission(setting_key, 'manage'))


def _role_has_permission(role_perms: frozenset[str], code: str) -> bool:
    expanded = expand_permissions(role_perms)
    return any(permission_satisfies(held, code) for held in expanded)


def _collect_group_permissions_for_role(role_perms: frozenset[str], group_key: str) -> list[dict]:
    group = PERMISSION_GROUPS[group_key]
    collected: list[dict] = []
    for perm in group['permissions']:
        if _role_has_permission(role_perms, perm['code']):
            collected.append(perm)
    for page in group.get('pages', []):
        for perm in page.get('permissions', []):
            if _role_has_permission(role_perms, perm['code']):
                collected.append({**perm, 'page': page['label']})
        for cat in page.get('categories', []):
            for perm in cat.get('permissions', []):
                if _role_has_permission(role_perms, perm['code']):
                    collected.append({**perm, 'page': page['label'], 'category': cat['label']})
            for setting in cat.get('settings', []):
                for perm in setting.get('permissions', []):
                    if _role_has_permission(role_perms, perm['code']):
                        collected.append({
                            **perm,
                            'page': page['label'],
                            'category': cat['label'],
                            'setting': setting['label'],
                        })
    return collected


def serialize_role_catalog() -> list[dict]:
    from .permission_service import db_is_initialized, ensure_permission_defaults, serialize_role_catalog_from_db
    if db_is_initialized():
        return serialize_role_catalog_from_db()
    ensure_permission_defaults()
    if db_is_initialized():
        return serialize_role_catalog_from_db()
    catalog = []
    for role in ROLE_DEFINITIONS:
        groups = []
        for group_key in role.permission_groups:
            group = PERMISSION_GROUPS[group_key]
            perms = _collect_group_permissions_for_role(role.permissions, group_key)
            if not perms:
                continue
            pages = []
            for page in group.get('pages', []):
                page_perms = [
                    p for p in perms
                    if p.get('page') == page['label'] or (
                        not p.get('page') and p['code'].startswith(f'{group_key}.')
                    )
                ]
                page_entry = {
                    'key': page['key'],
                    'label': page['label'],
                    'route': page.get('route', ''),
                    'permissions': [
                        {'code': p['code'], 'label': p['label'], 'action': p['action']}
                        for p in page_perms if p['code'].count('.') >= 2
                    ],
                }
                if page.get('categories'):
                    page_entry['categories'] = page['categories']
                if page_entry['permissions'] or page.get('categories'):
                    pages.append(page_entry)
            groups.append({
                'key': group_key,
                'label': group['label'],
                'description': group['description'],
                'permissions': [
                    {'code': p['code'], 'label': p['label'], 'action': p['action']}
                    for p in perms if p.get('scope') == 'module'
                ],
                'pages': pages,
            })
        catalog.append({
            'value': role.value,
            'label': role.label,
            'description': role.description,
            'permissions': sorted(expand_permissions(role.permissions)),
            'permission_groups': groups,
        })
    return catalog


def serialize_permission_groups() -> list[dict]:
    from .permission_service import db_is_initialized, ensure_permission_defaults, serialize_permission_groups_from_db
    if db_is_initialized():
        return serialize_permission_groups_from_db()
    ensure_permission_defaults()
    if db_is_initialized():
        return serialize_permission_groups_from_db()
    return list(PERMISSION_GROUPS.values())
