import datetime
from django.db import models
from django.contrib.auth.models import User


# ─────────────────────────────────────────────────────────────
# 枚举选项
# ─────────────────────────────────────────────────────────────

class CustomerType(models.TextChoices):
    PERSONAL = 'personal', '个人客户'
    ENTERPRISE = 'enterprise', '企业客户'
    CHANNEL = 'channel', '渠道客户'
    PROVIDER = 'provider', '供应商客户'
    OTHER = 'other', '其他'


class CustomerStatus(models.TextChoices):
    ACTIVE = 'active', '正常'
    SUSPENDED = 'suspended', '暂停'
    CANCELLED = 'cancelled', '注销'
    PENDING = 'pending', '待审核'


class IMType(models.TextChoices):
    NONE = '', '未设置'
    TELEGRAM = 'telegram', 'Telegram'
    WECOM = 'wecom', '企业微信'
    DINGTALK = 'dingtalk', '钉钉'
    WECHAT = 'wechat', '微信'
    WHATSAPP = 'whatsapp', 'WhatsApp'
    QQ = 'qq', 'QQ'
    OTHER = 'other', '其他'


# ─────────────────────────────────────────────────────────────
# 客户
# ─────────────────────────────────────────────────────────────

class Customer(models.Model):
    """客户基本信息"""
    customer_no = models.CharField('客户编号', max_length=32, unique=True, editable=False)
    name = models.CharField('客户名称', max_length=128)
    customer_type = models.CharField(
        '客户类型', max_length=16,
        choices=CustomerType.choices,
        default=CustomerType.PERSONAL,
    )
    status = models.CharField(
        '状态', max_length=16,
        choices=CustomerStatus.choices,
        default=CustomerStatus.PENDING,
    )
    # 联系信息
    contact_name = models.CharField('联系人', max_length=64)
    contact_phone = models.CharField('联系电话', max_length=20, blank=True, null=True)
    contact_email = models.EmailField('联系邮箱', blank=True, null=True)
    # IM 账号见 CustomerIMAccount（一个客户可有多个 IM 账号）
    # 企业信息
    company_name = models.CharField('公司名称', max_length=256, blank=True, null=True)
    company_name_short = models.CharField('公司简称', max_length=64, blank=True, null=True)
    unified_credit_code = models.CharField('统一社会信用代码', max_length=32, blank=True, null=True)
    legal_representative = models.CharField('法定代表人', max_length=64, blank=True, null=True)
    # 地址信息
    province = models.CharField('省份', max_length=32, blank=True, null=True)
    city = models.CharField('城市', max_length=32, blank=True, null=True)
    address = models.CharField('详细地址', max_length=256, blank=True, null=True)
    # 账务信息
    balance = models.DecimalField('账户余额', max_digits=12, decimal_places=2, default=0.00)
    credit_limit = models.DecimalField('信用额度', max_digits=12, decimal_places=2, default=0.00)
    # 关联账号
    account = models.OneToOneField(
        User, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='关联账号', related_name='customer',
    )
    # 销售负责人
    sales_manager = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='销售负责人', related_name='managed_customers',
    )
    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '客户'
        verbose_name_plural = '客户列表'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['customer_no']),
            models.Index(fields=['contact_phone']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f'[{self.customer_no}] {self.name}'

    def save(self, *args, **kwargs):
        if not self.customer_no:
            prefix = 'C'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = Customer.objects.filter(
                customer_no__startswith=f'{prefix}{date_str}'
            ).order_by('-customer_no').first()
            seq = int(last.customer_no[-4:]) + 1 if last else 1
            self.customer_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


# ─────────────────────────────────────────────────────────────
# 客户 IM 账号（一个客户可有多个）
# ─────────────────────────────────────────────────────────────

class CustomerIMAccount(models.Model):
    """客户 IM 账号，便于后续 IM 对接通知（一个客户可绑定多个）。"""

    customer = models.ForeignKey(
        Customer, on_delete=models.CASCADE,
        verbose_name='客户', related_name='im_accounts',
    )
    im_type = models.CharField(
        'IM 类型', max_length=16,
        choices=IMType.choices, default=IMType.TELEGRAM,
    )
    account = models.CharField('IM 账号/ID', max_length=128, blank=True,
                               help_text='个人账号、Telegram chat_id、企业微信成员账号等')
    group = models.CharField('IM 群组', max_length=128, blank=True,
                             help_text='对接的群组名称或群 ID')
    label = models.CharField('用途/备注名', max_length=64, blank=True,
                             help_text='如：财务、技术、负责人')
    is_primary = models.BooleanField('主账号', default=False)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '客户 IM 账号'
        verbose_name_plural = '客户 IM 账号'
        ordering = ['-is_primary', 'id']
        indexes = [
            models.Index(fields=['customer', 'is_primary']),
            models.Index(fields=['im_type']),
        ]

    def __str__(self):
        return f'{self.customer.name} - {self.get_im_type_display()} {self.account or self.group}'


# ─────────────────────────────────────────────────────────────
# 联系记录
# ─────────────────────────────────────────────────────────────

class ContactRecord(models.Model):
    """客户联系/跟进记录"""

    class ContactType(models.TextChoices):
        PHONE = 'phone', '电话沟通'
        EMAIL = 'email', '邮件往来'
        VISIT = 'visit', '上门拜访'
        ONLINE = 'online', '在线沟通'
        OTHER = 'other', '其他'

    customer = models.ForeignKey(
        Customer, on_delete=models.CASCADE,
        verbose_name='客户', related_name='contact_records',
    )
    contact_type = models.CharField('联系方式', max_length=16, choices=ContactType.choices)
    contact_time = models.DateTimeField('联系时间')
    summary = models.TextField('沟通摘要')
    handler = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, verbose_name='处理人',
    )
    next_follow_time = models.DateTimeField('下次跟进时间', null=True, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '联系记录'
        verbose_name_plural = '联系记录'
        ordering = ['-contact_time']

    def __str__(self):
        return (
            f'{self.customer.name} - '
            f'{self.get_contact_type_display()} '
            f'({self.contact_time.strftime("%Y-%m-%d")})'
        )


# ─────────────────────────────────────────────────────────────
# 合同
# ─────────────────────────────────────────────────────────────

class Contract(models.Model):
    """客户合同"""

    class ContractStatus(models.TextChoices):
        DRAFT = 'draft', '草稿'
        REVIEWING = 'reviewing', '审核中'
        ACTIVE = 'active', '生效中'
        EXPIRED = 'expired', '已到期'
        TERMINATED = 'terminated', '已终止'

    customer = models.ForeignKey(
        Customer, on_delete=models.CASCADE,
        verbose_name='客户', related_name='contracts',
    )
    contract_no = models.CharField('合同编号', max_length=64, unique=True, editable=False)
    contract_name = models.CharField('合同名称', max_length=256, null=True, blank=True)
    status = models.CharField(
        '合同状态', max_length=16,
        choices=ContractStatus.choices,
        default=ContractStatus.DRAFT,
    )
    amount = models.DecimalField('合同金额', max_digits=14, decimal_places=2)
    start_date = models.DateField('合同开始日期')
    end_date = models.DateField('合同结束日期')
    sign_date = models.DateField('签订日期', null=True, blank=True)
    file_url = models.CharField('合同文件地址', max_length=512, blank=True)
    remark = models.TextField('备注', blank=True)
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, verbose_name='创建人',
    )
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '合同'
        verbose_name_plural = '合同列表'
        ordering = ['-created_at']

    def __str__(self):
        return f'[{self.contract_no}] {self.contract_name}'

    def save(self, *args, **kwargs):
        if not self.contract_no:
            prefix = 'CT'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = Contract.objects.filter(
                contract_no__startswith=f'{prefix}{date_str}'
            ).order_by('-contract_no').first()
            seq = int(last.contract_no[-4:]) + 1 if last else 1
            self.contract_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


# ─────────────────────────────────────────────────────────────
# 账单
# ─────────────────────────────────────────────────────────────

class CustomerBilling(models.Model):
    """客户账单"""

    class BillingStatus(models.TextChoices):
        UNPAID = 'unpaid', '待支付'
        PAID = 'paid', '已支付'
        OVERDUE = 'overdue', '逾期'
        CANCELLED = 'cancelled', '已取消'

    class PaymentMethod(models.TextChoices):
        BANK_TRANSFER = 'bank_transfer', '银行转账'
        ALIPAY = 'alipay', '支付宝'
        WECHAT = 'wechat', '微信支付'
        PAYPAL = 'paypal', 'PayPal'
        CASH = 'cash', '现金'
        CREDIT_PAYMENT = 'credit_payment', '信用支付'
        OTHER = 'other', '其他'

    customer = models.ForeignKey(
        Customer, on_delete=models.CASCADE,
        verbose_name='客户', related_name='billings',
    )
    bill_no = models.CharField('账单编号', max_length=64, unique=True, editable=False)
    bill_month = models.CharField('账单月份', max_length=7, help_text='格式: YYYY-MM')
    amount = models.DecimalField('账单金额', max_digits=12, decimal_places=2)
    currency = models.CharField('结算币种', max_length=8, default='CNY')
    auto_generated = models.BooleanField('系统生成', default=False,
                                         help_text='按月由计费引擎汇总生成')
    paid_amount = models.DecimalField('已付金额', max_digits=12, decimal_places=2, default=0.00)
    status = models.CharField(
        '状态', max_length=16,
        choices=BillingStatus.choices,
        default=BillingStatus.UNPAID,
    )
    payment_method = models.CharField(
        '支付方式', max_length=16,
        choices=PaymentMethod.choices,
        blank=True,
    )
    due_date = models.DateField('到期日期')
    paid_at = models.DateTimeField('支付时间', null=True, blank=True)
    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '账单'
        verbose_name_plural = '账单列表'
        ordering = ['-bill_month', '-created_at']

    def __str__(self):
        return f'[{self.bill_no}] {self.customer.name} {self.bill_month} ¥{self.amount}'

    def save(self, *args, **kwargs):
        if not self.bill_no:
            prefix = 'B'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = CustomerBilling.objects.filter(
                bill_no__startswith=f'{prefix}{date_str}'
            ).order_by('-bill_no').first()
            seq = int(last.bill_no[-4:]) + 1 if last else 1
            self.bill_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)

    @property
    def outstanding_amount(self):
        return self.amount - self.paid_amount


# ─────────────────────────────────────────────────────────────
# 账单明细（按服务实例逐条计费）
# ─────────────────────────────────────────────────────────────

class BillingItem(models.Model):
    """账单明细行：对应某个服务实例在账单月内的计费记录。"""

    billing = models.ForeignKey(
        CustomerBilling, on_delete=models.CASCADE,
        verbose_name='所属账单', related_name='items',
    )
    service_instance = models.ForeignKey(
        'service_manager.ServiceInstance', on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='服务实例', related_name='billing_items',
    )
    instance_no = models.CharField('实例编号', max_length=32, blank=True)
    description = models.CharField('计费说明', max_length=256, blank=True)
    service_type = models.CharField('服务类型', max_length=16, blank=True)

    # 关联产品（按产品基础规格 + 超出部分计费时记录来源产品）
    product = models.ForeignKey(
        'product_manager.Product', on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='关联产品', related_name='billing_items',
    )
    product_name = models.CharField('产品名称', max_length=128, blank=True)

    # 计费周期
    period_start = models.DateField('计费起始', null=True, blank=True)
    period_end = models.DateField('计费结束', null=True, blank=True)
    days_used = models.PositiveSmallIntegerField('计费天数', default=0)
    days_in_month = models.PositiveSmallIntegerField('整月天数', default=30)
    is_prorated = models.BooleanField('按天比例', default=False)
    is_trial = models.BooleanField('测试服务', default=False)

    # 金额（原始币种 + 折算后结算币种）
    unit_monthly_fee = models.DecimalField('整月单价', max_digits=12, decimal_places=2, default=0)
    base_monthly_fee = models.DecimalField('基础月租', max_digits=12, decimal_places=2, default=0,
                                           help_text='产品基础规格月租（原始币种）')
    overage_monthly_fee = models.DecimalField('超出部分月租', max_digits=12, decimal_places=2, default=0,
                                              help_text='超出产品模版规格的阶梯升级月租（原始币种）')
    source_currency = models.CharField('原始币种', max_length=8, default='CNY')
    exchange_rate = models.DecimalField('折算汇率', max_digits=12, decimal_places=6, default=1,
                                        help_text='原始币种 → 结算币种 的汇率')
    amount_original = models.DecimalField('原始金额', max_digits=12, decimal_places=2, default=0)
    currency = models.CharField('结算币种', max_length=8, default='CNY')
    amount = models.DecimalField('结算金额', max_digits=12, decimal_places=2, default=0)

    # 计费明细快照：实际规格 / 模版基准规格 / 超出阶梯逐项 / 比例换算，供「详情」查看
    detail = models.JSONField('计费明细快照', default=dict, blank=True)

    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '账单明细'
        verbose_name_plural = '账单明细'
        ordering = ['billing', 'id']

    def __str__(self):
        return f'{self.description} {self.currency}{self.amount}'


# ─────────────────────────────────────────────────────────────
# 操作日志
# ─────────────────────────────────────────────────────────────

class CustomerOperationLog(models.Model):
    """客户管理模块操作日志"""

    class ActionType(models.TextChoices):
        CREATE = 'create', '新建'
        UPDATE = 'update', '更新'
        DELETE = 'delete', '删除'
        STATUS_CHANGE = 'status_change', '状态变更'
        PAYMENT = 'payment', '收款'
        CONTRACT_SIGN = 'contract_sign', '合同签订'
        CONTACT = 'contact', '联系跟进'
        IMPORT = 'import', '批量导入'
        EXPORT = 'export', '数据导出'
        OTHER = 'other', '其他'

    class TargetModel(models.TextChoices):
        CUSTOMER = 'Customer', '客户'
        CONTRACT = 'Contract', '合同'
        BILLING = 'CustomerBilling', '账单'
        CONTACT_RECORD = 'ContactRecord', '联系记录'

    customer = models.ForeignKey(
        Customer, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='关联客户', related_name='operation_logs',
    )
    operator = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, verbose_name='操作人',
    )
    action_type = models.CharField(
        '操作类型', max_length=20,
        choices=ActionType.choices,
        default=ActionType.OTHER,
    )
    target_model = models.CharField(
        '操作对象', max_length=32,
        choices=TargetModel.choices,
        blank=True,
    )
    target_id = models.PositiveIntegerField('对象ID', null=True, blank=True)
    description = models.CharField('操作描述', max_length=512)
    old_value = models.JSONField('变更前', null=True, blank=True)
    new_value = models.JSONField('变更后', null=True, blank=True)
    ip_address = models.GenericIPAddressField('操作IP', null=True, blank=True)
    created_at = models.DateTimeField('操作时间', auto_now_add=True)

    class Meta:
        verbose_name = '操作日志'
        verbose_name_plural = '操作日志'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['customer', 'created_at']),
            models.Index(fields=['operator', 'created_at']),
            models.Index(fields=['action_type']),
            models.Index(fields=['target_model', 'target_id']),
        ]

    def __str__(self):
        operator_name = self.operator.get_full_name() or self.operator.username if self.operator else '系统'
        return f'[{self.get_action_type_display()}] {operator_name} - {self.description}'


# ─────────────────────────────────────────────────────────────
# 日志记录工具函数
# ─────────────────────────────────────────────────────────────

def record_operation_log(
    *,
    operator,
    action_type,
    description,
    customer=None,
    target_model='',
    target_id=None,
    old_value=None,
    new_value=None,
    ip_address=None,
    request=None,
):
    """
    记录一条操作日志。

    在 admin.py / views.py 中直接调用：
        record_operation_log(
            operator=request.user,
            action_type=CustomerOperationLog.ActionType.UPDATE,
            description='修改客户状态为暂停',
            customer=customer_obj,
            target_model=CustomerOperationLog.TargetModel.CUSTOMER,
            target_id=customer_obj.pk,
            old_value={'status': 'active'},
            new_value={'status': 'suspended'},
            request=request,
        )
    """
    if request is not None and ip_address is None:
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        ip_address = (
            x_forwarded_for.split(',')[0].strip()
            if x_forwarded_for
            else request.META.get('REMOTE_ADDR')
        )
    CustomerOperationLog.objects.create(
        customer=customer,
        operator=operator,
        action_type=action_type,
        target_model=target_model,
        target_id=target_id,
        description=description,
        old_value=old_value,
        new_value=new_value,
        ip_address=ip_address,
    )


def model_to_dict_simple(instance, fields=None):
    """将模型实例转为简单字典（仅包含基础字段，用于日志 old/new value）"""
    from django.forms.models import model_to_dict as _model_to_dict
    data = {}
    for field in instance._meta.fields:
        if fields and field.name not in fields:
            continue
        val = getattr(instance, field.name)
        if hasattr(val, 'pk'):
            data[field.name] = val.pk
        elif hasattr(val, 'isoformat'):
            data[field.name] = val.isoformat()
        else:
            data[field.name] = str(val) if val is not None else None
    return data
