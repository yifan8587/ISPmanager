from django.contrib.auth.models import User
from rest_framework import serializers

from .models import (
    Customer, CustomerIMAccount, ContactRecord, Contract,
    CustomerBilling, BillingItem, CustomerOperationLog,
)


# ─────────────────────────────────────────────────────────────
# 嵌套用简化 Serializer
# ─────────────────────────────────────────────────────────────

class UserBriefSerializer(serializers.ModelSerializer):
    full_name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ('id', 'username', 'full_name')

    def get_full_name(self, obj):
        return obj.get_full_name() or obj.username


# ─────────────────────────────────────────────────────────────
# CustomerIMAccount
# ─────────────────────────────────────────────────────────────

class CustomerIMAccountSerializer(serializers.ModelSerializer):
    im_type_label = serializers.CharField(source='get_im_type_display', read_only=True)

    class Meta:
        model = CustomerIMAccount
        fields = (
            'id', 'im_type', 'im_type_label',
            'account', 'group', 'label', 'is_primary',
        )

    def validate(self, attrs):
        account = attrs.get('account', getattr(self.instance, 'account', ''))
        group = attrs.get('group', getattr(self.instance, 'group', ''))
        if not account and not group:
            raise serializers.ValidationError('IM 账号或群组至少填写一项')
        return attrs


# ─────────────────────────────────────────────────────────────
# ContactRecord
# ─────────────────────────────────────────────────────────────

class ContactRecordSerializer(serializers.ModelSerializer):
    handler_info = UserBriefSerializer(source='handler', read_only=True)
    contact_type_label = serializers.CharField(source='get_contact_type_display', read_only=True)

    class Meta:
        model = ContactRecord
        fields = (
            'id', 'customer', 'contact_type', 'contact_type_label',
            'contact_time', 'summary', 'handler', 'handler_info',
            'next_follow_time', 'created_at',
        )
        read_only_fields = ('id', 'created_at')


# ─────────────────────────────────────────────────────────────
# Contract
# ─────────────────────────────────────────────────────────────

class ContractSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    created_by_info = UserBriefSerializer(source='created_by', read_only=True)

    class Meta:
        model = Contract
        fields = (
            'id', 'customer', 'contract_no', 'contract_name',
            'status', 'status_label', 'amount',
            'start_date', 'end_date', 'sign_date',
            'file_url', 'remark',
            'created_by', 'created_by_info',
            'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'contract_no', 'created_at', 'updated_at')

    def validate(self, attrs):
        start = attrs.get('start_date')
        end = attrs.get('end_date')
        if start and end and start >= end:
            raise serializers.ValidationError('合同开始日期必须早于结束日期')
        return attrs


# ─────────────────────────────────────────────────────────────
# CustomerBilling
# ─────────────────────────────────────────────────────────────

class BillingItemSerializer(serializers.ModelSerializer):
    service_type_label = serializers.SerializerMethodField()

    class Meta:
        model = BillingItem
        fields = (
            'id', 'service_instance', 'instance_no', 'description',
            'service_type', 'service_type_label',
            'product', 'product_name',
            'period_start', 'period_end', 'days_used', 'days_in_month',
            'is_prorated', 'is_trial',
            'unit_monthly_fee', 'base_monthly_fee', 'overage_monthly_fee',
            'source_currency', 'exchange_rate',
            'amount_original', 'currency', 'amount', 'detail', 'created_at',
        )
        read_only_fields = fields

    def get_service_type_label(self, obj):
        mapping = {'vps': 'VPS', 'edge': '边缘加速', 'ip': 'IP 地址', 'bandwidth': '带宽'}
        return mapping.get(obj.service_type, obj.service_type)


class CustomerBillingSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    payment_method_label = serializers.CharField(source='get_payment_method_display', read_only=True)
    outstanding_amount = serializers.DecimalField(
        max_digits=12, decimal_places=2, read_only=True,
    )
    items = BillingItemSerializer(many=True, read_only=True)
    trial_count = serializers.SerializerMethodField()
    customer_name = serializers.CharField(source='customer.name', read_only=True)

    class Meta:
        model = CustomerBilling
        fields = (
            'id', 'customer', 'customer_name', 'bill_no', 'bill_month',
            'amount', 'currency', 'auto_generated',
            'paid_amount', 'outstanding_amount',
            'status', 'status_label',
            'payment_method', 'payment_method_label',
            'due_date', 'paid_at', 'remark',
            'items', 'trial_count',
            'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'bill_no', 'outstanding_amount', 'auto_generated',
                            'items', 'trial_count', 'created_at', 'updated_at')

    def get_trial_count(self, obj):
        return obj.items.filter(is_trial=True).count()

    def validate_paid_amount(self, value):
        if value < 0:
            raise serializers.ValidationError('已付金额不能为负数')
        return value

    def validate(self, attrs):
        amount = attrs.get('amount', getattr(self.instance, 'amount', None))
        paid = attrs.get('paid_amount', getattr(self.instance, 'paid_amount', 0))
        if amount is not None and paid > amount:
            raise serializers.ValidationError('已付金额不能超过账单金额')
        return attrs


# ─────────────────────────────────────────────────────────────
# CustomerOperationLog
# ─────────────────────────────────────────────────────────────

class CustomerOperationLogSerializer(serializers.ModelSerializer):
    operator_info = UserBriefSerializer(source='operator', read_only=True)
    action_type_label = serializers.CharField(source='get_action_type_display', read_only=True)
    target_model_label = serializers.CharField(source='get_target_model_display', read_only=True)

    class Meta:
        model = CustomerOperationLog
        fields = (
            'id', 'customer', 'operator', 'operator_info',
            'action_type', 'action_type_label',
            'target_model', 'target_model_label', 'target_id',
            'description', 'old_value', 'new_value',
            'ip_address', 'created_at',
        )
        read_only_fields = fields


# ─────────────────────────────────────────────────────────────
# Customer（列表 / 详情）
# ─────────────────────────────────────────────────────────────

class CustomerListSerializer(serializers.ModelSerializer):
    """列表轻量版，不展开嵌套数据"""
    customer_type_label = serializers.CharField(source='get_customer_type_display', read_only=True)
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    im_accounts = CustomerIMAccountSerializer(many=True, read_only=True)
    sales_manager_info = UserBriefSerializer(source='sales_manager', read_only=True)
    outstanding_total = serializers.SerializerMethodField()

    class Meta:
        model = Customer
        fields = (
            'id', 'customer_no', 'name',
            'customer_type', 'customer_type_label',
            'status', 'status_label',
            'contact_name', 'contact_phone', 'contact_email',
            'im_accounts',
            'company_name', 'company_name_short',
            'province', 'city',
            'balance', 'credit_limit', 'outstanding_total',
            'sales_manager', 'sales_manager_info',
            'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'customer_no', 'created_at', 'updated_at')

    def get_outstanding_total(self, obj):
        from django.db.models import Sum, F, ExpressionWrapper, DecimalField
        result = obj.billings.filter(
            status__in=['unpaid', 'overdue']
        ).aggregate(
            total=Sum(
                ExpressionWrapper(F('amount') - F('paid_amount'), output_field=DecimalField())
            )
        )
        return result['total'] or 0


class CustomerDetailSerializer(CustomerListSerializer):
    """详情版，包含联系记录、合同、账单、操作日志"""
    contact_records = ContactRecordSerializer(many=True, read_only=True)
    contracts = ContractSerializer(many=True, read_only=True)
    billings = CustomerBillingSerializer(many=True, read_only=True)
    operation_logs = CustomerOperationLogSerializer(many=True, read_only=True)

    class Meta(CustomerListSerializer.Meta):
        fields = CustomerListSerializer.Meta.fields + (
            'unified_credit_code', 'legal_representative',
            'address', 'remark',
            'account',
            'contact_records', 'contracts', 'billings', 'operation_logs',
        )


class CustomerWriteSerializer(serializers.ModelSerializer):
    """创建/更新专用，支持嵌套写入多个 IM 账号"""

    im_accounts = CustomerIMAccountSerializer(many=True, required=False)

    class Meta:
        model = Customer
        fields = (
            'name', 'customer_type', 'status',
            'contact_name', 'contact_phone', 'contact_email',
            'im_accounts',
            'company_name', 'company_name_short',
            'unified_credit_code', 'legal_representative',
            'province', 'city', 'address',
            'balance', 'credit_limit',
            'account', 'sales_manager', 'remark',
        )

    def validate_contact_phone(self, value):
        if value and not value.replace('+', '').replace('-', '').replace(' ', '').isdigit():
            raise serializers.ValidationError('请输入有效的联系电话')
        return value

    def _sync_im_accounts(self, customer, im_accounts):
        """全量替换该客户的 IM 账号列表，并保证至多一个主账号。"""
        customer.im_accounts.all().delete()
        has_primary = False
        for item in im_accounts:
            is_primary = item.get('is_primary', False)
            if is_primary and has_primary:
                is_primary = False
            if is_primary:
                has_primary = True
            CustomerIMAccount.objects.create(
                customer=customer,
                im_type=item.get('im_type', ''),
                account=item.get('account', ''),
                group=item.get('group', ''),
                label=item.get('label', ''),
                is_primary=is_primary,
            )
        # 没有显式主账号时，将第一个设为主账号
        if im_accounts and not has_primary:
            first = customer.im_accounts.first()
            if first:
                first.is_primary = True
                first.save(update_fields=['is_primary'])

    def create(self, validated_data):
        im_accounts = validated_data.pop('im_accounts', None)
        customer = super().create(validated_data)
        if im_accounts is not None:
            self._sync_im_accounts(customer, im_accounts)
        return customer

    def update(self, instance, validated_data):
        im_accounts = validated_data.pop('im_accounts', None)
        customer = super().update(instance, validated_data)
        if im_accounts is not None:
            self._sync_im_accounts(customer, im_accounts)
        return customer

    def to_representation(self, instance):
        return CustomerDetailSerializer(instance, context=self.context).data
