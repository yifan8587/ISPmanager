from rest_framework.routers import DefaultRouter
from .views import (
    CustomerViewSet,
    ContactRecordViewSet,
    ContractViewSet,
    CustomerBillingViewSet,
    CustomerOperationLogViewSet,
)

router = DefaultRouter()
router.register(r'customers', CustomerViewSet, basename='customer')
router.register(r'contact-records', ContactRecordViewSet, basename='contact-record')
router.register(r'contracts', ContractViewSet, basename='contract')
router.register(r'billings', CustomerBillingViewSet, basename='billing')
router.register(r'operation-logs', CustomerOperationLogViewSet, basename='operation-log')

urlpatterns = router.urls
