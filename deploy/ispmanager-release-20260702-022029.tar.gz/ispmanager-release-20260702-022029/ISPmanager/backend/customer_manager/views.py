from decimal import Decimal, InvalidOperation

from django.db.models import Sum, ExpressionWrapper, F, DecimalField, Count
from django.utils import timezone
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from accounts.drf_mixins import (
    CustomerModulePermissionMixin,
    BillingModulePermissionMixin,
    CustomerScopedQuerysetMixin,
    ViewOnlyPermissionMixin,
)
from accounts.role_permissions import Perm

from .models import (
    Customer, ContactRecord, Contract,
    CustomerBilling, CustomerOperationLog,
    record_operation_log, model_to_dict_simple,
)
from .serializers import (
    CustomerListSerializer, CustomerDetailSerializer, CustomerWriteSerializer,
    ContactRecordSerializer, ContractSerializer,
    CustomerBillingSerializer, CustomerOperationLogSerializer,
)
from . import billing_engine


# ─────────────────────────────────────────────────────────────
# 工具 Mixin
# ─────────────────────────────────────────────────────────────

class LogActionMixin:
    """为 ViewSet 提供自动日志记录"""

    log_target_model = ''

    def _log(self, request, action_type, description, customer=None,
             target_id=None, old_value=None, new_value=None):
        record_operation_log(
            operator=request.user,
            action_type=action_type,
            description=description,
            customer=customer,
            target_model=self.log_target_model,
            target_id=target_id,
            old_value=old_value,
            new_value=new_value,
            request=request,
        )

    def perform_create(self, serializer):
        instance = serializer.save()
        self._log(
            self.request,
            action_type=CustomerOperationLog.ActionType.CREATE,
            description=f'新建 {self.log_target_model}: {instance}',
            customer=getattr(instance, 'customer', None),
            target_id=instance.pk,
            new_value=model_to_dict_simple(instance),
        )

    def perform_update(self, serializer):
        old = model_to_dict_simple(serializer.instance)
        instance = serializer.save()
        self._log(
            self.request,
            action_type=CustomerOperationLog.ActionType.UPDATE,
            description=f'更新 {self.log_target_model}: {instance}',
            customer=getattr(instance, 'customer', None),
            target_id=instance.pk,
            old_value=old,
            new_value=model_to_dict_simple(instance),
        )

    def perform_destroy(self, instance):
        old = model_to_dict_simple(instance)
        self._log(
            self.request,
            action_type=CustomerOperationLog.ActionType.DELETE,
            description=f'删除 {self.log_target_model}: {instance}',
            customer=getattr(instance, 'customer', None),
            target_id=instance.pk,
            old_value=old,
        )
        instance.delete()


# ─────────────────────────────────────────────────────────────
# Customer ViewSet
# ─────────────────────────────────────────────────────────────

class CustomerViewSet(
    CustomerScopedQuerysetMixin,
    CustomerModulePermissionMixin,
    LogActionMixin,
    viewsets.ModelViewSet,
):
    """
    客户 CRUD + 自定义操作

    list:   GET  /api/customers/
    create: POST /api/customers/
    retrieve: GET /api/customers/{id}/
    update: PUT/PATCH /api/customers/{id}/
    destroy: DELETE /api/customers/{id}/

    自定义动作：
      POST /api/customers/{id}/change_status/   变更状态
      GET  /api/customers/{id}/logs/            操作日志
      GET  /api/customers/statistics/           统计数据
    """
    customer_scope_field = 'self'
    extra_read_actions = frozenset({'logs', 'statistics'})

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['customer_type', 'status', 'province', 'city', 'sales_manager']
    search_fields = ['customer_no', 'name', 'contact_name', 'contact_phone',
                     'contact_email', 'company_name']
    ordering_fields = ['created_at', 'updated_at', 'name', 'balance']
    ordering = ['-created_at']
    log_target_model = CustomerOperationLog.TargetModel.CUSTOMER

    def get_queryset(self):
        qs = Customer.objects.select_related('account', 'sales_manager').all()
        return self.apply_customer_scope(qs)

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return CustomerDetailSerializer
        if self.action in ('create', 'update', 'partial_update'):
            return CustomerWriteSerializer
        return CustomerListSerializer

    def perform_create(self, serializer):
        instance = serializer.save()
        record_operation_log(
            operator=self.request.user,
            action_type=CustomerOperationLog.ActionType.CREATE,
            description=f'新建客户 [{instance.customer_no}] {instance.name}',
            customer=instance,
            target_model=CustomerOperationLog.TargetModel.CUSTOMER,
            target_id=instance.pk,
            new_value=model_to_dict_simple(instance),
            request=self.request,
        )

    def perform_update(self, serializer):
        old = model_to_dict_simple(serializer.instance)
        instance = serializer.save()
        new = model_to_dict_simple(instance)
        changed_keys = [k for k in old if old[k] != new.get(k)]
        action_type = (
            CustomerOperationLog.ActionType.STATUS_CHANGE
            if 'status' in changed_keys
            else CustomerOperationLog.ActionType.UPDATE
        )
        record_operation_log(
            operator=self.request.user,
            action_type=action_type,
            description=f'更新客户 [{instance.customer_no}] {instance.name}，变更：{", ".join(changed_keys)}',
            customer=instance,
            target_model=CustomerOperationLog.TargetModel.CUSTOMER,
            target_id=instance.pk,
            old_value=old,
            new_value=new,
            request=self.request,
        )

    def perform_destroy(self, instance):
        old = model_to_dict_simple(instance)
        record_operation_log(
            operator=self.request.user,
            action_type=CustomerOperationLog.ActionType.DELETE,
            description=f'删除客户 [{instance.customer_no}] {instance.name}',
            customer=None,
            target_model=CustomerOperationLog.TargetModel.CUSTOMER,
            target_id=instance.pk,
            old_value=old,
            request=self.request,
        )
        instance.delete()

    @action(detail=True, methods=['post'], url_path='change_status')
    def change_status(self, request, pk=None):
        """变更客户状态"""
        customer = self.get_object()
        new_status = request.data.get('status')
        reason = request.data.get('reason', '')

        valid_statuses = [c[0] for c in Customer._meta.get_field('status').choices]
        if new_status not in valid_statuses:
            return Response(
                {'detail': f'无效的状态值，可选：{valid_statuses}'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        old_status = customer.status
        customer.status = new_status
        customer.save(update_fields=['status', 'updated_at'])

        record_operation_log(
            operator=request.user,
            action_type=CustomerOperationLog.ActionType.STATUS_CHANGE,
            description=f'客户状态变更：{old_status} → {new_status}，原因：{reason}',
            customer=customer,
            target_model=CustomerOperationLog.TargetModel.CUSTOMER,
            target_id=customer.pk,
            old_value={'status': old_status},
            new_value={'status': new_status, 'reason': reason},
            request=request,
        )
        return Response(
            CustomerListSerializer(customer).data,
            status=status.HTTP_200_OK,
        )

    @action(detail=True, methods=['get'], url_path='logs')
    def logs(self, request, pk=None):
        """获取该客户的操作日志"""
        customer = self.get_object()
        logs = CustomerOperationLog.objects.filter(
            customer=customer
        ).select_related('operator').order_by('-created_at')
        page = self.paginate_queryset(logs)
        if page is not None:
            return self.get_paginated_response(
                CustomerOperationLogSerializer(page, many=True).data
            )
        return Response(CustomerOperationLogSerializer(logs, many=True).data)

    @action(detail=False, methods=['get'], url_path='statistics')
    def statistics(self, request):
        """客户统计数据"""
        qs = self.apply_customer_scope(Customer.objects.all())
        billing_qs = CustomerBilling.objects.filter(customer__in=qs)
        type_dist = list(qs.values('customer_type').annotate(count=Count('id')))
        status_dist = list(qs.values('status').annotate(count=Count('id')))
        billing_summary = billing_qs.filter(
            status__in=['unpaid', 'overdue']
        ).aggregate(
            total_outstanding=Sum(
                ExpressionWrapper(F('amount') - F('paid_amount'), output_field=DecimalField())
            )
        )
        return Response({
            'total_customers': qs.count(),
            'active_customers': qs.filter(status='active').count(),
            'type_distribution': type_dist,
            'status_distribution': status_dist,
            'total_outstanding': billing_summary['total_outstanding'] or 0,
        })


# ─────────────────────────────────────────────────────────────
# ContactRecord ViewSet
# ─────────────────────────────────────────────────────────────

class ContactRecordViewSet(
    CustomerScopedQuerysetMixin,
    CustomerModulePermissionMixin,
    LogActionMixin,
    viewsets.ModelViewSet,
):
    """联系记录 CRUD，支持按 customer / contact_type 过滤"""
    serializer_class = ContactRecordSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['customer', 'contact_type', 'handler']
    search_fields = ['summary', 'customer__name']
    ordering = ['-contact_time']
    log_target_model = CustomerOperationLog.TargetModel.CONTACT_RECORD

    def get_queryset(self):
        qs = ContactRecord.objects.select_related('customer', 'handler').all()
        return self.apply_customer_scope(qs)

    def perform_create(self, serializer):
        from accounts.permissions import get_user_customer
        customer = get_user_customer(self.request.user)
        if customer:
            instance = serializer.save(customer=customer)
        else:
            instance = serializer.save()
        record_operation_log(
            operator=self.request.user,
            action_type=CustomerOperationLog.ActionType.CONTACT,
            description=f'新增联系记录：{instance.customer.name} - {instance.get_contact_type_display()}',
            customer=instance.customer,
            target_model=CustomerOperationLog.TargetModel.CONTACT_RECORD,
            target_id=instance.pk,
            request=self.request,
        )


# ─────────────────────────────────────────────────────────────
# Contract ViewSet
# ─────────────────────────────────────────────────────────────

class ContractViewSet(
    CustomerScopedQuerysetMixin,
    CustomerModulePermissionMixin,
    LogActionMixin,
    viewsets.ModelViewSet,
):
    """
    合同 CRUD

    自定义动作：
      POST /api/contracts/{id}/sign/   签订合同（状态改为 active）
    """
    serializer_class = ContractSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['customer', 'status', 'created_by']
    search_fields = ['contract_no', 'contract_name', 'customer__name']
    ordering = ['-created_at']
    log_target_model = CustomerOperationLog.TargetModel.CONTRACT

    def get_queryset(self):
        qs = Contract.objects.select_related('customer', 'created_by').all()
        return self.apply_customer_scope(qs)

    def perform_create(self, serializer):
        instance = serializer.save(created_by=self.request.user)
        record_operation_log(
            operator=self.request.user,
            action_type=CustomerOperationLog.ActionType.CREATE,
            description=f'新建合同 [{instance.contract_no}] {instance.contract_name}',
            customer=instance.customer,
            target_model=CustomerOperationLog.TargetModel.CONTRACT,
            target_id=instance.pk,
            request=self.request,
        )

    @action(detail=True, methods=['post'], url_path='sign')
    def sign(self, request, pk=None):
        """签订合同"""
        contract = self.get_object()
        if contract.status not in (
            Contract.ContractStatus.DRAFT,
            Contract.ContractStatus.REVIEWING,
        ):
            return Response(
                {'detail': '只有草稿或审核中的合同才能签订'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        import datetime
        old_status = contract.status
        contract.status = Contract.ContractStatus.ACTIVE
        contract.sign_date = contract.sign_date or datetime.date.today()
        contract.save(update_fields=['status', 'sign_date', 'updated_at'])

        record_operation_log(
            operator=request.user,
            action_type=CustomerOperationLog.ActionType.CONTRACT_SIGN,
            description=f'合同签订 [{contract.contract_no}] {contract.contract_name}',
            customer=contract.customer,
            target_model=CustomerOperationLog.TargetModel.CONTRACT,
            target_id=contract.pk,
            old_value={'status': old_status},
            new_value={'status': contract.status, 'sign_date': str(contract.sign_date)},
            request=request,
        )
        return Response(ContractSerializer(contract).data)


# ─────────────────────────────────────────────────────────────
# CustomerBilling ViewSet
# ─────────────────────────────────────────────────────────────

class CustomerBillingViewSet(
    CustomerScopedQuerysetMixin,
    BillingModulePermissionMixin,
    LogActionMixin,
    viewsets.ModelViewSet,
):
    """
    账单 CRUD

    自定义动作：
      POST /api/billings/{id}/pay/   登记收款
    """
    serializer_class = CustomerBillingSerializer
    extra_read_actions = frozenset({'preview'})
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['customer', 'status', 'bill_month', 'payment_method', 'auto_generated']
    search_fields = ['bill_no', 'customer__name']
    ordering = ['-bill_month', '-created_at']
    log_target_model = CustomerOperationLog.TargetModel.BILLING

    def get_queryset(self):
        qs = CustomerBilling.objects.select_related('customer').prefetch_related('items').all()
        return self.apply_customer_scope(qs)

    def _resolve_due_days(self):
        from system_manager.services import get_setting
        try:
            return int(get_setting('billing_due_days', 30) or 30)
        except (TypeError, ValueError):
            return 30

    @action(detail=False, methods=['post'], url_path='preview')
    def preview(self, request):
        """按月计费预览（不落库）。body: {customer, bill_month, currency?}"""
        customer_id = request.data.get('customer')
        bill_month = request.data.get('bill_month')
        currency = request.data.get('currency') or None
        if not customer_id or not bill_month:
            return Response({'detail': '请提供 customer 与 bill_month(YYYY-MM)'},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            customer = self.apply_customer_scope(Customer.objects.all()).get(pk=customer_id)
        except Customer.DoesNotExist:
            return Response({'detail': '客户不存在或无权访问'}, status=status.HTTP_404_NOT_FOUND)
        try:
            result = billing_engine.compute_customer_month(customer, bill_month, currency)
        except (ValueError, IndexError):
            return Response({'detail': '账单月份格式应为 YYYY-MM'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(result)

    @action(detail=False, methods=['post'], url_path='generate')
    def generate(self, request):
        """按月生成/更新账单。body: {customer, bill_month, currency?}"""
        customer_id = request.data.get('customer')
        bill_month = request.data.get('bill_month')
        currency = request.data.get('currency') or None
        if not customer_id or not bill_month:
            return Response({'detail': '请提供 customer 与 bill_month(YYYY-MM)'},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            customer = self.apply_customer_scope(Customer.objects.all()).get(pk=customer_id)
        except Customer.DoesNotExist:
            return Response({'detail': '客户不存在或无权访问'}, status=status.HTTP_404_NOT_FOUND)
        try:
            billing, result, updated = billing_engine.generate_bill(
                customer, bill_month, user=request.user,
                due_days=self._resolve_due_days(), target_currency=currency,
            )
        except (ValueError, IndexError):
            return Response({'detail': '账单月份格式应为 YYYY-MM'}, status=status.HTTP_400_BAD_REQUEST)
        record_operation_log(
            operator=request.user,
            action_type=CustomerOperationLog.ActionType.OTHER,
            description=f'{"生成" if updated else "跳过(已支付)"}账单 [{billing.bill_no}] '
                        f'{bill_month} {billing.currency}{billing.amount}',
            customer=customer,
            target_model=CustomerOperationLog.TargetModel.BILLING,
            target_id=billing.pk,
            request=request,
        )
        return Response({
            'billing': CustomerBillingSerializer(billing).data,
            'summary': result,
            'updated': updated,
        })

    @action(detail=True, methods=['post'], url_path='pay')
    def pay(self, request, pk=None):
        """登记收款"""
        billing = self.get_object()
        amount_str = request.data.get('amount')
        payment_method = request.data.get('payment_method', '')

        try:
            pay_amount = Decimal(str(amount_str))
            if pay_amount <= 0:
                raise ValueError
        except (InvalidOperation, TypeError, ValueError):
            return Response(
                {'detail': '请输入有效的收款金额'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        outstanding = billing.amount - billing.paid_amount
        if pay_amount > outstanding:
            return Response(
                {'detail': f'收款金额不能超过未付金额 ¥{outstanding:.2f}'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        old_paid = billing.paid_amount
        old_status = billing.status

        billing.paid_amount = billing.paid_amount + pay_amount
        if payment_method:
            billing.payment_method = payment_method
        billing.paid_at = timezone.now()
        if billing.paid_amount >= billing.amount:
            billing.status = CustomerBilling.BillingStatus.PAID
        billing.save(update_fields=['paid_amount', 'payment_method', 'paid_at', 'status', 'updated_at'])

        record_operation_log(
            operator=request.user,
            action_type=CustomerOperationLog.ActionType.PAYMENT,
            description=f'收款 ¥{pay_amount:,.2f}，账单 [{billing.bill_no}]',
            customer=billing.customer,
            target_model=CustomerOperationLog.TargetModel.BILLING,
            target_id=billing.pk,
            old_value={'paid_amount': str(old_paid), 'status': old_status},
            new_value={'paid_amount': str(billing.paid_amount), 'status': billing.status},
            request=request,
        )
        return Response(CustomerBillingSerializer(billing).data)


# ─────────────────────────────────────────────────────────────
# CustomerOperationLog ViewSet（只读）
# ─────────────────────────────────────────────────────────────

class CustomerOperationLogViewSet(
    CustomerScopedQuerysetMixin,
    ViewOnlyPermissionMixin,
    viewsets.ReadOnlyModelViewSet,
):
    """操作日志（只读）"""
    view_permission = Perm.CUSTOMER_VIEW
    serializer_class = CustomerOperationLogSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['customer', 'operator', 'action_type', 'target_model']
    search_fields = ['description', 'customer__name', 'operator__username']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = CustomerOperationLog.objects.select_related('customer', 'operator').all()
        return self.apply_customer_scope(qs)
