"""
operation_manager/views.py — 运维监控 API
"""

from datetime import timedelta

from django.utils import timezone
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from accounts.drf_mixins import OperationSystemPermissionMixin

from .models import (
    ZabbixServer,
    MonitoringHostTemplate,
    MonitoringHost,
    MonitoringItem,
    MonitoringGraph,
    MonitoringGraphProfile,
    MonitoringGraphSeries,
    MonitoringGraphBinding,
    MonitoringTrafficReport,
    MonitoringSyncLog,
    WebSSHCommandTemplate,
    record_monitoring_log,
)
from resource_manager.models import VPS, EdgeAcceleration
from .serializers import (
    ZabbixServerListSerializer,
    ZabbixServerWriteSerializer,
    MonitoringHostTemplateSerializer,
    MonitoringHostListSerializer,
    MonitoringHostDetailSerializer,
    MonitoringHostWriteSerializer,
    MonitoringItemSerializer,
    MonitoringGraphSerializer,
    MonitoringGraphWriteSerializer,
    MonitoringGraphProfileSerializer,
    MonitoringGraphSeriesSerializer,
    MonitoringGraphBindingSerializer,
    MonitoringTrafficReportSerializer,
    MonitoringTrafficReportListSerializer,
    MonitoringSyncLogSerializer,
    WebSSHCommandTemplateSerializer,
    TrafficQuerySerializer,
    GraphDataQuerySerializer,
    ResourceMonitoringPanelSerializer,
)
from .traffic_analytics import (
    query_traffic, get_graph_chart_data, get_item_chart_data, unit_convert_bps,
)
from .zabbix_client import ZabbixClient, ZabbixError, get_default_zabbix_server
from .zabbix_provision import (
    fetch_host_groups, fetch_templates, sync_host_full, sync_server_inventory_light,
)
from .zabbix_sync_worker import enqueue_host_sync, enqueue_server_inventory_sync, is_server_sync_running
from .resource_monitoring import (
    get_traffic_resource_context,
    resolve_traffic_from_binding,
    validate_binding_for_resource,
    validate_monitoring_host_for_resource,
)


def _resolve_period(period: str, time_from=None, time_till=None):
    now = timezone.now()
    if time_from and time_till:
        return time_from, time_till
    mapping = {
        '1h': timedelta(hours=1),
        '6h': timedelta(hours=6),
        '24h': timedelta(hours=24),
        '7d': timedelta(days=7),
        '30d': timedelta(days=30),
    }
    delta = mapping.get(period or '24h', timedelta(hours=24))
    return now - delta, now


def _resolve_resource_host(pop_point=None, vps=None, edge=None):
    """根据资源解析所属监控主机：POP 直接关联，VPS/Edge 通过图形绑定推断。"""
    if pop_point:
        host = MonitoringHost.objects.filter(pop_point=pop_point).first()
        if host:
            return host
    fk = {'pop_point': pop_point, 'vps': vps, 'edge': edge}
    binding = MonitoringGraphBinding.objects.filter(
        **{k: v for k, v in fk.items() if v},
    ).select_related('monitoring_host', 'graph__monitoring_host',
                     'monitoring_item__monitoring_host').first()
    if binding:
        return binding.effective_host
    return None


class ZabbixServerViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = ZabbixServer.objects.all()
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['is_active', 'is_default', 'auth_type']
    search_fields = ['name', 'api_url']
    ordering = ['-is_default', 'name']

    def get_serializer_class(self):
        if self.action in ('create', 'update', 'partial_update'):
            return ZabbixServerWriteSerializer
        return ZabbixServerListSerializer

    @action(detail=True, methods=['post'], url_path='test-connection')
    def test_connection(self, request, pk=None):
        server = self.get_object()
        try:
            result = ZabbixClient(server).test_connection()
            record_monitoring_log(
                action_type=MonitoringSyncLog.ActionType.TEST_CONNECTION,
                status=MonitoringSyncLog.Status.SUCCESS,
                message=f'连接成功 Zabbix {result.get("version")}',
                zabbix_server=server,
                operator=request.user,
                detail=result,
            )
            return Response(result)
        except ZabbixError as exc:
            record_monitoring_log(
                action_type=MonitoringSyncLog.ActionType.TEST_CONNECTION,
                status=MonitoringSyncLog.Status.FAILED,
                message=str(exc),
                zabbix_server=server,
                operator=request.user,
            )
            return Response({'detail': str(exc)}, status=400)

    @action(detail=True, methods=['get'], url_path='host-groups')
    def host_groups(self, request, pk=None):
        server = self.get_object()
        try:
            return Response(fetch_host_groups(server, request.query_params.get('search')))
        except ZabbixError as exc:
            return Response({'detail': str(exc)}, status=400)

    @action(detail=True, methods=['get'], url_path='templates')
    def templates(self, request, pk=None):
        server = self.get_object()
        try:
            return Response(fetch_templates(server, request.query_params.get('search')))
        except ZabbixError as exc:
            return Response({'detail': str(exc)}, status=400)

    @action(detail=True, methods=['post'], url_path='sync')
    def sync(self, request, pk=None):
        """后台同步：主机清单 + 已登记监控主机的项/图（明细在后台缓慢拉取）。"""
        server = self.get_object()
        if is_server_sync_running(server.pk):
            return Response(
                {'detail': '该服务器正在后台同步中，请稍后再试', 'status': 'running'},
                status=409,
            )
        server.last_sync_status = 'running'
        server.last_sync_message = '后台同步任务已启动…'
        server.save(update_fields=['last_sync_status', 'last_sync_message'])
        enqueue_server_inventory_sync(server.pk, operator_id=getattr(request.user, 'pk', None))
        return Response({
            'status': 'queued',
            'message': '已在后台开始同步：先更新主机清单与统计，监控项/图形将缓慢拉取',
        }, status=202)

    @action(detail=True, methods=['get'], url_path='sync-status')
    def sync_status(self, request, pk=None):
        server = self.get_object()
        return Response({
            'running': is_server_sync_running(server.pk),
            'last_sync_at': server.last_sync_at,
            'last_sync_status': server.last_sync_status,
            'last_sync_message': server.last_sync_message,
        })


class MonitoringGraphProfileViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringGraphProfile.objects.all()
    serializer_class = MonitoringGraphProfileSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['profile_type', 'is_active', 'is_system']
    search_fields = ['code', 'name']
    ordering = ['profile_type', 'name']


class MonitoringHostTemplateViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringHostTemplate.objects.select_related('zabbix_server')
    serializer_class = MonitoringHostTemplateSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter]
    filterset_fields = ['target_kind', 'is_active', 'zabbix_server']
    search_fields = ['name']


class MonitoringHostViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringHost.objects.select_related(
        'zabbix_server', 'pop_point', 'service_pop_point', 'template',
    )
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['host_kind', 'sync_status', 'zabbix_server', 'is_enabled']
    search_fields = ['hostname', 'visible_name', 'zabbix_hostid', 'monitored_ip']

    def get_queryset(self):
        qs = super().get_queryset()
        pop_point = self.request.query_params.get('pop_point')
        if pop_point:
            from django.db.models import Q
            qs = qs.filter(
                Q(pop_point_id=pop_point) | Q(service_pop_point_id=pop_point),
            )
        return qs

    def perform_create(self, serializer):
        host = serializer.save()
        if host.is_enabled:
            enqueue_host_sync(host.pk, push=host.host_kind == MonitoringHost.HostKind.POP)

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return MonitoringHostDetailSerializer
        if self.action in ('create', 'update', 'partial_update'):
            return MonitoringHostWriteSerializer
        return MonitoringHostListSerializer

    @action(detail=True, methods=['post'], url_path='sync')
    def sync(self, request, pk=None):
        """将监控主机下发到 Zabbix，并同步 items / graphs（默认后台执行）。"""
        host = self.get_object()
        push = request.data.get('push', True)
        async_mode = request.data.get('async', True)
        if async_mode:
            if not enqueue_host_sync(host.pk, push=bool(push), operator_id=getattr(request.user, 'pk', None)):
                return Response({'detail': '该监控主机正在同步中', 'status': 'running'}, status=409)
            host.mark_syncing()
            return Response({
                'status': 'queued',
                'message': '已在后台排队同步监控项与图形',
                'sync_status': host.sync_status,
                'zabbix_hostid': host.zabbix_hostid,
            }, status=202)
        try:
            result = sync_host_full(host, push=bool(push))
            record_monitoring_log(
                action_type=MonitoringSyncLog.ActionType.FULL_SYNC,
                status=MonitoringSyncLog.Status.SUCCESS,
                message=(
                    f'同步完成：hostid={result.get("host", {}).get("hostid", host.zabbix_hostid)} '
                    f'items={result.get("items", {}).get("total", 0)} '
                    f'graphs={result.get("graphs", {}).get("total", 0)}'
                ),
                zabbix_server=host.zabbix_server,
                monitoring_host=host,
                operator=request.user,
                detail=result,
            )
            host.refresh_from_db()
            return Response({
                **result,
                'sync_status': host.sync_status,
                'zabbix_hostid': host.zabbix_hostid,
            })
        except (ValueError, ZabbixError) as exc:
            host.mark_error(str(exc))
            record_monitoring_log(
                action_type=MonitoringSyncLog.ActionType.FULL_SYNC,
                status=MonitoringSyncLog.Status.FAILED,
                message=str(exc),
                zabbix_server=host.zabbix_server,
                monitoring_host=host,
                operator=request.user,
            )
            return Response({'detail': str(exc)}, status=400)

    @action(detail=True, methods=['get'], url_path='monitoring-panel')
    def monitoring_panel(self, request, pk=None):
        host = self.get_object()
        bindings = MonitoringGraphBinding.objects.filter(
            is_visible=True,
            graph__monitoring_host=host,
            graph__is_enabled=True,
        ).select_related('graph', 'graph__profile').order_by('display_order')

        panels: dict[str, list] = {}
        for b in bindings:
            g = b.graph
            slot = b.panel_slot
            panels.setdefault(slot, []).append({
                'binding_id': b.pk,
                'graph_id': g.pk,
                'source_type': g.source_type,
                'zabbix_graphid': g.zabbix_graphid or '',
                'title': b.panel_title or g.effective_title,
                'graph_kind': g.graph_kind,
                'graph_kind_label': g.get_graph_kind_display(),
                'width': g.width,
                'height': g.height,
                'billing_enabled': g.billing_enabled,
                'interface_name': g.interface_name,
                'profile_code': g.profile.code if g.profile_id else None,
                'chart_url': request.build_absolute_uri(
                    f'/api/operation/monitoring-graphs/{g.pk}/chart-data/'
                ),
            })

        data = {
            'enabled': host.is_enabled,
            'target_type': host.host_kind,
            'resource_id': host.pop_point_id or 0,
            'monitoring_host_id': host.pk,
            'sync_status': host.sync_status,
            'last_sync_at': host.last_sync_at,
            'monitored_ip': host.monitored_ip,
            'panels': panels,
            'primary_items': MonitoringItemSerializer(
                host.items.filter(is_primary_traffic=True), many=True,
            ).data,
        }
        return Response(ResourceMonitoringPanelSerializer(data).data)


class MonitoringItemViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringItem.objects.select_related('monitoring_host')
    serializer_class = MonitoringItemSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter]
    filterset_fields = ['monitoring_host', 'traffic_direction', 'interface_name', 'is_primary_traffic']
    search_fields = ['name', 'item_key', 'interface_name']

    @action(detail=True, methods=['get', 'post'], url_path='chart-data')
    def chart_data(self, request, pk=None):
        item = self.get_object()
        src = request.data if request.method == 'POST' else request.query_params
        ser = GraphDataQuerySerializer(data=src)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        time_from, time_till = _resolve_period(
            d.get('period'), d.get('time_from'), d.get('time_till'),
        )
        try:
            return Response(get_item_chart_data(item, time_from=time_from, time_till=time_till))
        except (ValueError, ZabbixError) as exc:
            return Response({'detail': str(exc)}, status=400)


class MonitoringGraphViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringGraph.objects.select_related(
        'monitoring_host', 'profile',
    ).prefetch_related('items', 'series_list')
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['monitoring_host', 'graph_kind', 'source_type', 'billing_enabled', 'is_enabled']
    search_fields = ['name', 'display_title', 'interface_name']

    def get_serializer_class(self):
        if self.action in ('create', 'update', 'partial_update'):
            return MonitoringGraphWriteSerializer
        return MonitoringGraphSerializer

    @action(detail=True, methods=['get', 'post'], url_path='chart-data')
    def chart_data(self, request, pk=None):
        graph = self.get_object()
        if request.method == 'POST':
            ser = GraphDataQuerySerializer(data=request.data)
        else:
            ser = GraphDataQuerySerializer(data=request.query_params)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        time_from, time_till = _resolve_period(
            d.get('period'), d.get('time_from'), d.get('time_till'),
        )
        try:
            result = get_graph_chart_data(graph, time_from=time_from, time_till=time_till)
            profile = graph.profile
            unit = profile.unit_display if profile else 'Mbps'
            if result.get('billing'):
                b = result['billing']
                b['percentile_display'] = unit_convert_bps(
                    b.get('percentile_bps') or 0, unit,
                )
                b['unit'] = unit
            return Response(result)
        except (ValueError, ZabbixError) as exc:
            return Response({'detail': str(exc)}, status=400)


class MonitoringGraphSeriesViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringGraphSeries.objects.select_related('graph', 'monitoring_item')
    serializer_class = MonitoringGraphSeriesSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['graph', 'series_role']


class MonitoringGraphBindingViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringGraphBinding.objects.select_related(
        'graph', 'graph__monitoring_host', 'graph__profile',
        'monitoring_item', 'monitoring_item__monitoring_host', 'monitoring_host',
    )
    serializer_class = MonitoringGraphBindingSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['target_type', 'panel_slot', 'pop_point', 'vps', 'edge', 'monitoring_host']

    @action(detail=False, methods=['get'], url_path='resource-panel')
    def resource_panel(self, request):
        """
        资源详情页监控面板：按 (target_type, resource_id) 返回绑定的图形/监控项卡片。
        VPS / 边缘加速 / POP 均通过本接口读取所关联的监控主机图形或监控项。
        """
        target_type = request.query_params.get('target_type')
        resource_id = request.query_params.get('resource_id')
        if target_type not in ('pop', 'vps', 'edge') or not resource_id:
            return Response({'detail': '请提供 target_type 与 resource_id'}, status=400)

        fk = {'pop': 'pop_point', 'vps': 'vps', 'edge': 'edge'}[target_type]
        qs = self.get_queryset().filter(
            target_type=target_type, is_visible=True, **{fk: resource_id},
        ).order_by('panel_slot', 'display_order')

        slot_labels = dict(MonitoringGraphBinding.PanelSlot.choices)
        panels: dict[str, list] = {}
        host_ids = set()
        for b in qs:
            host = b.effective_host
            if host:
                host_ids.add(host.pk)
            card = {
                'binding_id': b.pk,
                'bind_kind': b.bind_kind,
                'panel_slot': b.panel_slot,
                'panel_slot_label': slot_labels.get(b.panel_slot, b.panel_slot),
                'title': b.panel_title,
                'monitoring_host_id': host.pk if host else None,
                'monitoring_host_name': (host.visible_name or host.hostname) if host else '',
            }
            if b.graph_id:
                g = b.graph
                card.update({
                    'graph_id': g.pk,
                    'item_id': None,
                    'title': b.panel_title or g.effective_title,
                    'graph_kind': g.graph_kind,
                    'billing_enabled': g.billing_enabled,
                    'chart_url': request.build_absolute_uri(
                        f'/api/operation/monitoring-graphs/{g.pk}/chart-data/'
                    ),
                })
            else:
                it = b.monitoring_item
                card.update({
                    'graph_id': None,
                    'item_id': it.pk,
                    'title': b.panel_title or it.name,
                    'graph_kind': 'traffic' if it.traffic_direction in ('in', 'out') else 'custom',
                    'billing_enabled': False,
                    'interface_name': it.interface_name,
                    'chart_url': request.build_absolute_uri(
                        f'/api/operation/monitoring-items/{it.pk}/chart-data/'
                    ),
                })
            panels.setdefault(b.panel_slot, []).append(card)

        return Response({
            'target_type': target_type,
            'resource_id': int(resource_id),
            'monitoring_host_ids': sorted(host_ids),
            'panels': panels,
        })


class MonitoringTrafficReportViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    queryset = MonitoringTrafficReport.objects.select_related(
        'monitoring_host', 'profile', 'in_item', 'out_item', 'graph',
        'pop_point', 'vps', 'edge',
    )
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['target_type', 'status', 'monitoring_host', 'interface_name']
    search_fields = ['report_no', 'title', 'interface_name']
    ordering = ['-created_at']
    http_method_names = ['get', 'post', 'patch', 'delete', 'head', 'options']

    def get_queryset(self):
        qs = super().get_queryset()
        if self.action == 'list':
            show = self.request.query_params.get('show_archived', '').lower()
            if show not in ('1', 'true', 'yes'):
                qs = qs.exclude(status=MonitoringTrafficReport.ReportStatus.ARCHIVED)
        return qs

    def get_serializer_class(self):
        if self.action == 'list':
            return MonitoringTrafficReportListSerializer
        return MonitoringTrafficReportSerializer

    @action(detail=False, methods=['get'], url_path='host-graphs')
    def host_graphs(self, request):
        """按监控主机返回可用于流量截取的图形列表（含 interface / item 解析）。"""
        host_id = request.query_params.get('monitoring_host')
        if not host_id:
            return Response({'detail': '请提供 monitoring_host'}, status=400)
        host = MonitoringHost.objects.filter(pk=host_id).first()
        if not host:
            return Response({'detail': '监控主机不存在'}, status=404)
        from .resource_monitoring import build_host_traffic_graph_options
        graphs = build_host_traffic_graph_options(host)
        return Response({
            'monitoring_host_id': host.pk,
            'monitoring_host_name': host.visible_name or host.hostname,
            'graphs': graphs,
        })

    @action(detail=True, methods=['post'], url_path='archive')
    def archive(self, request, pk=None):
        report = self.get_object()
        report.status = MonitoringTrafficReport.ReportStatus.ARCHIVED
        report.save(update_fields=['status'])
        return Response(MonitoringTrafficReportListSerializer(report).data)

    @action(detail=False, methods=['get'], url_path='resource-context')
    def resource_context(self, request):
        """VPS/边缘加速流量截取页：接口列表 + POP 过滤后的监控主机。"""
        target_type = request.query_params.get('target_type')
        resource_id = request.query_params.get('resource_id')
        if target_type not in ('vps', 'edge') or not resource_id:
            return Response({'detail': '请提供 target_type=vps|edge 与 resource_id'}, status=400)
        try:
            data = get_traffic_resource_context(
                target_type=target_type, resource_id=int(resource_id),
            )
        except (VPS.DoesNotExist, EdgeAcceleration.DoesNotExist):
            return Response({'detail': '资源不存在'}, status=404)
        except ValueError as exc:
            return Response({'detail': str(exc)}, status=400)
        return Response(data)

    @action(detail=False, methods=['post'], url_path='query')
    def query_traffic(self, request):
        """按时间窗口截取接口流量并计算 95 峰值"""
        ser = TrafficQuerySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data

        binding = d.get('binding')
        resolved = None
        if binding:
            target_type = None
            resource_id = None
            if d.get('vps'):
                target_type, resource_id = 'vps', d['vps'].pk
            elif d.get('edge'):
                target_type, resource_id = 'edge', d['edge'].pk
            elif d.get('pop_point'):
                target_type, resource_id = 'pop', d['pop_point'].pk
            else:
                target_type = binding.target_type
                resource_id = binding.vps_id or binding.edge_id or binding.pop_point_id
            if target_type and resource_id:
                try:
                    validate_binding_for_resource(
                        binding, target_type=target_type, resource_id=resource_id,
                    )
                except ValueError as exc:
                    return Response({'detail': str(exc)}, status=400)
            try:
                resolved = resolve_traffic_from_binding(binding)
            except ValueError as exc:
                return Response({'detail': str(exc)}, status=400)

        if d.get('graph') and not resolved:
            try:
                from .resource_monitoring import resolve_traffic_from_graph
                resolved = resolve_traffic_from_graph(d['graph'])
            except ValueError as exc:
                return Response({'detail': str(exc)}, status=400)

        host = (resolved or {}).get('monitoring_host') or d.get('monitoring_host') or _resolve_resource_host(
            d.get('pop_point'), d.get('vps'), d.get('edge'),
        )
        if not host:
            return Response(
                {'detail': '未找到监控数据，请先在监控 Tab 关联监控图形/监控项'},
                status=400,
            )

        pop_id = None
        if d.get('vps'):
            pop_id = d['vps'].pop_point_id
        elif d.get('edge'):
            pop_id = d['edge'].pop_point_id
        if pop_id and not binding:
            try:
                validate_monitoring_host_for_resource(monitoring_host=host, pop_point_id=pop_id)
            except ValueError as exc:
                return Response({'detail': str(exc)}, status=400)

        time_from, time_till = d['time_from'], d['time_till']
        try:
            result = query_traffic(
                monitoring_host=host,
                time_from=time_from,
                time_till=time_till,
                profile=d.get('profile'),
                graph=(resolved or {}).get('graph') or d.get('graph'),
                interface_name=(
                    (resolved or {}).get('interface_name')
                    or d.get('interface_name')
                    or ''
                ),
                in_item=(resolved or {}).get('in_item') or d.get('in_item'),
                out_item=(resolved or {}).get('out_item') or d.get('out_item'),
                persist=d.get('persist', False),
                title=d.get('title') or (resolved or {}).get('title') or '',
                operator=request.user,
            )
            record_monitoring_log(
                action_type=MonitoringSyncLog.ActionType.TRAFFIC_QUERY,
                status=MonitoringSyncLog.Status.SUCCESS,
                message=f'流量查询 {time_from.date()} ~ {time_till.date()}',
                zabbix_server=host.zabbix_server,
                monitoring_host=host,
                operator=request.user,
                detail={'sample_count': result.get('billing', {}).get('sample_count')},
            )
            if d.get('persist'):
                record_monitoring_log(
                    action_type=MonitoringSyncLog.ActionType.BILLING_COMPUTE,
                    status=MonitoringSyncLog.Status.SUCCESS,
                    message=f'95计费 {result.get("billing", {}).get("percentile_mbps")} Mbps',
                    monitoring_host=host,
                    operator=request.user,
                )
            return Response(result)
        except (ValueError, ZabbixError) as exc:
            return Response({'detail': str(exc)}, status=400)

    @action(detail=False, methods=['post'], url_path='percentile')
    def percentile(self, request):
        """快捷 95 计费接口"""
        data = dict(request.data)
        data.setdefault('persist', True)
        if 'profile' not in data:
            profile = MonitoringGraphProfile.objects.filter(code='traffic_p95_default').first()
            if profile:
                data['profile'] = profile.pk
        ser = TrafficQuerySerializer(data=data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data

        host = d.get('monitoring_host') or _resolve_resource_host(
            d.get('pop_point'), d.get('vps'), d.get('edge'),
        )
        if not host:
            return Response({'detail': '未找到监控主机'}, status=400)

        try:
            result = query_traffic(
                monitoring_host=host,
                time_from=d['time_from'],
                time_till=d['time_till'],
                profile=d.get('profile'),
                graph=d.get('graph'),
                interface_name=d.get('interface_name') or '',
                in_item=d.get('in_item'),
                out_item=d.get('out_item'),
                persist=True,
                title=d.get('title') or '',
                operator=request.user,
            )
            return Response(result)
        except (ValueError, ZabbixError) as exc:
            return Response({'detail': str(exc)}, status=400)


class MonitoringSyncLogViewSet(OperationSystemPermissionMixin, viewsets.ReadOnlyModelViewSet):
    queryset = MonitoringSyncLog.objects.select_related(
        'zabbix_server', 'monitoring_host', 'operator',
    )
    serializer_class = MonitoringSyncLogSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ['action_type', 'status', 'zabbix_server', 'monitoring_host']
    ordering = ['-created_at']


class WebSSHCommandTemplateViewSet(OperationSystemPermissionMixin, viewsets.ModelViewSet):
    """WebSSH 命令模板 CRUD。"""

    queryset = WebSSHCommandTemplate.objects.all()
    serializer_class = WebSSHCommandTemplateSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['category', 'is_active', 'is_system']
    search_fields = ['code', 'name', 'description', 'command']
    ordering_fields = ['sort_order', 'id', 'updated_at']
    ordering = ['sort_order', 'id']

    def get_queryset(self):
        qs = super().get_queryset()
        if self.action in ('list', 'retrieve') and self.request.query_params.get('active_only') == '1':
            qs = qs.filter(is_active=True)
        return qs

    def perform_destroy(self, instance):
        if instance.is_system:
            raise ValidationError('系统内置模板不可删除')
        instance.delete()
