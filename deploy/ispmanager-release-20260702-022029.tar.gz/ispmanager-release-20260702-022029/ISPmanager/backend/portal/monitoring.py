"""portal/monitoring.py — 流量 / 品质监控（预留网关对接，当前返回结构化时序数据）"""
from __future__ import annotations

import hashlib
import random
from datetime import datetime, timedelta

from django.utils import timezone


def _seed(key: str) -> random.Random:
    h = hashlib.md5(key.encode(), usedforsecurity=False).hexdigest()
    return random.Random(int(h[:8], 16))


def traffic_series(resource_kind: str, resource_id: int, limit_mbps: int, hours: int = 24) -> dict:
    """生成流量监控时序（接入 Prometheus/节点 API 后替换本实现）。"""
    rng = _seed(f'{resource_kind}:{resource_id}:traffic')
    now = timezone.now()
    cap = max(int(limit_mbps or 100), 1)
    series = []
    in_total = 0.0
    out_total = 0.0
    peak = 0.0
    for i in range(hours, 0, -1):
        t = now - timedelta(hours=i)
        base = cap * (0.08 + rng.random() * 0.35)
        in_mbps = round(base * (0.6 + rng.random() * 0.8), 2)
        out_mbps = round(base * (0.4 + rng.random() * 0.7), 2)
        in_total += in_mbps * 3600 / 8 / 1024
        out_total += out_mbps * 3600 / 8 / 1024
        peak = max(peak, in_mbps, out_mbps)
        series.append({
            'time': t.strftime('%Y-%m-%d %H:00'),
            'in_mbps': in_mbps,
            'out_mbps': out_mbps,
        })
    return {
        'resource_kind': resource_kind,
        'period': f'{hours}h',
        'bandwidth_limit_mbps': cap,
        'gateway_reserved': True,
        'series': series,
        'summary': {
            'in_total_gb': round(in_total, 2),
            'out_total_gb': round(out_total, 2),
            'peak_mbps': round(peak, 2),
        },
    }


def quality_series(resource_id: int, protocol: str, hours: int = 24) -> dict:
    """边缘加速品质监控（延迟 / 丢包 / 抖动 / 可用性）。"""
    rng = _seed(f'edge:{resource_id}:quality:{protocol}')
    now = timezone.now()
    series = []
    latencies = []
    for i in range(hours, 0, -1):
        t = now - timedelta(hours=i)
        latency = round(18 + rng.random() * 40, 1)
        loss = round(max(0, rng.gauss(0.15, 0.12)), 2)
        jitter = round(1 + rng.random() * 4, 1)
        latencies.append(latency)
        series.append({
            'time': t.strftime('%Y-%m-%d %H:00'),
            'latency_ms': latency,
            'packet_loss_pct': loss,
            'jitter_ms': jitter,
        })
    avg_lat = round(sum(latencies) / len(latencies), 1) if latencies else 0
    return {
        'protocol': protocol,
        'period': f'{hours}h',
        'gateway_reserved': True,
        'current': {
            'latency_ms': series[-1]['latency_ms'] if series else 0,
            'packet_loss_pct': series[-1]['packet_loss_pct'] if series else 0,
            'jitter_ms': series[-1]['jitter_ms'] if series else 0,
            'availability_pct': round(99.5 + rng.random() * 0.49, 2),
        },
        'summary': {
            'avg_latency_ms': avg_lat,
            'max_latency_ms': round(max(latencies), 1) if latencies else 0,
            'avg_packet_loss_pct': round(
                sum(p['packet_loss_pct'] for p in series) / len(series), 2,
            ) if series else 0,
        },
        'series': series,
    }
