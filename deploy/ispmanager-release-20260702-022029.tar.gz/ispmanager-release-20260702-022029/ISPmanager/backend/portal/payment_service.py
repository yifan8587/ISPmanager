"""portal/payment_service.py — 客户门户账单支付（含在线支付预留接口）"""
from __future__ import annotations

import uuid
from decimal import Decimal, InvalidOperation

from django.core.cache import cache
from django.utils import timezone

from customer_manager.models import CustomerBilling, CustomerOperationLog, record_operation_log

ONLINE_METHODS = frozenset({'wechat', 'alipay', 'paypal'})
OFFLINE_METHODS = frozenset({'cash', 'bank_transfer'})
ALLOWED_METHODS = ONLINE_METHODS | OFFLINE_METHODS

METHOD_LABELS = {
    'cash': '现金',
    'bank_transfer': '银行转账',
    'wechat': '微信支付',
    'alipay': '支付宝',
    'paypal': 'PayPal',
}

SESSION_TTL = 1800
SESSION_PREFIX = 'portal_bill_pay:'


def method_label(method: str) -> str:
    return METHOD_LABELS.get(method, method)


def outstanding_amount(billing: CustomerBilling) -> Decimal:
    return billing.amount - billing.paid_amount


def validate_bill_payable(billing: CustomerBilling) -> Decimal:
    if billing.status == CustomerBilling.BillingStatus.CANCELLED:
        raise ValueError('账单已取消，无法支付')
    if billing.status == CustomerBilling.BillingStatus.PAID:
        raise ValueError('账单已支付')
    owe = outstanding_amount(billing)
    if owe <= 0:
        raise ValueError('暂无待付金额')
    return owe


def apply_bill_payment(
    billing: CustomerBilling,
    pay_amount: Decimal,
    payment_method: str,
    operator,
    *,
    request=None,
    remark: str = '',
) -> CustomerBilling:
    owe = outstanding_amount(billing)
    if pay_amount <= 0:
        raise ValueError('请输入有效的支付金额')
    if pay_amount > owe:
        raise ValueError(f'支付金额不能超过待付金额 {billing.currency}{owe:.2f}')

    old_paid = billing.paid_amount
    old_status = billing.status

    billing.paid_amount = billing.paid_amount + pay_amount
    billing.payment_method = payment_method
    billing.paid_at = timezone.now()
    if billing.paid_amount >= billing.amount:
        billing.status = CustomerBilling.BillingStatus.PAID
    if remark:
        billing.remark = remark
    billing.save(update_fields=[
        'paid_amount', 'payment_method', 'paid_at', 'status', 'remark', 'updated_at',
    ])

    record_operation_log(
        operator=operator,
        action_type=CustomerOperationLog.ActionType.PAYMENT,
        description=(
            f'客户门户支付 {billing.currency}{pay_amount:,.2f}（{method_label(payment_method)}），'
            f'账单 [{billing.bill_no}]'
        ),
        customer=billing.customer,
        target_model=CustomerOperationLog.TargetModel.BILLING,
        target_id=billing.pk,
        old_value={'paid_amount': str(old_paid), 'status': old_status},
        new_value={'paid_amount': str(billing.paid_amount), 'status': billing.status},
        request=request,
    )
    return billing


def create_online_payment_session(billing: CustomerBilling, payment_method: str) -> dict:
    """创建在线支付会话（预留微信/支付宝/PayPal 网关对接）。"""
    owe = validate_bill_payable(billing)
    session_id = uuid.uuid4().hex
    payload = {
        'billing_id': billing.id,
        'bill_no': billing.bill_no,
        'amount': str(owe),
        'currency': billing.currency,
        'payment_method': payment_method,
    }
    cache.set(f'{SESSION_PREFIX}{session_id}', payload, timeout=SESSION_TTL)

    # 预留字段：接入真实网关时替换 qr_code_url / pay_url / prepay_id
    return {
        'session_id': session_id,
        'payment_method': payment_method,
        'payment_method_label': method_label(payment_method),
        'amount': str(owe),
        'currency': billing.currency,
        'bill_no': billing.bill_no,
        'expires_in': SESSION_TTL,
        'gateway_status': 'pending',
        'qr_code_text': f'MOCK-{payment_method.upper()}-{billing.bill_no}-{owe}',
        'pay_url': f'/api/portal/payments/gateway/{payment_method}/?session={session_id}',
    }


def confirm_online_payment_session(
    session_id: str,
    billing: CustomerBilling,
    operator,
    *,
    request=None,
) -> CustomerBilling:
    """确认在线支付（当前为预留实现；生产环境应对接网关回调验签）。"""
    payload = cache.get(f'{SESSION_PREFIX}{session_id}')
    if not payload or payload.get('billing_id') != billing.id:
        raise ValueError('支付会话无效或已过期，请重新发起支付')

    pay_amount = Decimal(payload['amount'])
    payment_method = payload['payment_method']
    cache.delete(f'{SESSION_PREFIX}{session_id}')
    return apply_bill_payment(
        billing, pay_amount, payment_method, operator, request=request,
        remark=f'在线支付确认 session={session_id}',
    )


def parse_pay_amount(raw, billing: CustomerBilling) -> Decimal:
    if raw in (None, ''):
        return outstanding_amount(billing)
    try:
        amount = Decimal(str(raw))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError('请输入有效的支付金额') from None
    return amount
