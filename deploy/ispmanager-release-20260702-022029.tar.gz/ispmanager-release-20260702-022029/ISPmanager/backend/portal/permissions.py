"""portal/permissions.py — 客户门户访问控制"""
from rest_framework.permissions import BasePermission

from accounts.permissions import is_customer_account, get_user_customer


class IsCustomer(BasePermission):
    """仅「归属客户账号」或超级管理员可访问。"""
    message = '该接口仅对客户账号开放'

    def has_permission(self, request, view):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        return bool(user.is_superuser or is_customer_account(user))


def request_customer(request):
    """获取当前请求用户关联的 Customer（无则 None）。"""
    return get_user_customer(request.user)
