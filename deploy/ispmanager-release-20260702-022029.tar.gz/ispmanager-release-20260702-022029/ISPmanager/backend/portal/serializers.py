"""portal/serializers.py — 客户门户序列化器（仅暴露客户可见的安全字段）"""
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from django.db.models import Count
from rest_framework import serializers

from customer_manager.models import Customer, CustomerBilling, BillingItem
from product_manager import services as product_services
from product_manager.serializers import ProductDetailSerializer
from resource_manager.models import IPAddress, IPAttribute, VPS, EdgeAcceleration
from service_manager.models import ServiceInstance, ServiceOrder

from . import payment_service


# ═══════════════════════════════════════════════════════════════
# § 注册
# ═══════════════════════════════════════════════════════════════

class RegisterSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(write_only=True, min_length=8)
    email = serializers.EmailField()
    contact_name = serializers.CharField(max_length=64)
    contact_phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    company_name = serializers.CharField(max_length=256, required=False, allow_blank=True)
    customer_type = serializers.ChoiceField(
        choices=['personal', 'enterprise'], default='personal', required=False,
    )

    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError('该用户名已被注册')
        return value

    def validate_password(self, value):
        validate_password(value)
        return value

    @transaction.atomic
    def create(self, validated_data):
        from accounts.models import UserProfile

        user = User.objects.create_user(
            username=validated_data['username'],
            password=validated_data['password'],
            email=validated_data.get('email', ''),
            first_name=validated_data.get('contact_name', ''),
        )
        customer = Customer.objects.create(
            name=validated_data.get('company_name') or validated_data['contact_name'],
            customer_type=validated_data.get('customer_type', 'personal'),
            status='pending',
            contact_name=validated_data['contact_name'],
            contact_phone=validated_data.get('contact_phone', ''),
            contact_email=validated_data.get('email', ''),
            company_name=validated_data.get('company_name', ''),
            account=user,
        )
        profile, _ = UserProfile.objects.get_or_create(user=user)
        profile.account_type = UserProfile.AccountType.CUSTOMER
        profile.save(update_fields=['account_type'])
        return {'user': user, 'customer': customer}


# ═══════════════════════════════════════════════════════════════
# § 客户资料
# ═══════════════════════════════════════════════════════════════

class CustomerProfileSerializer(serializers.ModelSerializer):
    customer_type_label = serializers.CharField(source='get_customer_type_display', read_only=True)
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    username = serializers.CharField(source='account.username', read_only=True)

    class Meta:
        model = Customer
        fields = [
            'id', 'customer_no', 'name', 'username',
            'customer_type', 'customer_type_label', 'status', 'status_label',
            'contact_name', 'contact_phone', 'contact_email',
            'company_name', 'company_name_short', 'unified_credit_code',
            'province', 'city', 'address',
            'balance', 'credit_limit', 'created_at',
        ]
        read_only_fields = [
            'id', 'customer_no', 'customer_type', 'status',
            'balance', 'credit_limit', 'created_at',
        ]


# ═══════════════════════════════════════════════════════════════
# § 服务实例
# ═══════════════════════════════════════════════════════════════

class PortalServiceItemSerializer(serializers.Serializer):
    """门户服务列表项（实例 + 直连资源）"""
    id = serializers.CharField()
    entry_type = serializers.CharField()
    instance_id = serializers.IntegerField(allow_null=True)
    instance_no = serializers.CharField()
    service_type = serializers.CharField()
    service_type_label = serializers.CharField()
    status = serializers.CharField()
    status_label = serializers.CharField()
    pop_name = serializers.CharField(allow_blank=True)
    product_name = serializers.CharField(allow_blank=True)
    spec_snapshot = serializers.JSONField()
    monthly_fee_effective = serializers.CharField()
    fee_currency = serializers.CharField()
    is_trial = serializers.BooleanField()
    activated_at = serializers.DateTimeField(allow_null=True)
    expire_time = serializers.DateTimeField(allow_null=True)
    created_at = serializers.DateTimeField(allow_null=True)
    resource = serializers.DictField(allow_null=True)
    can_change_request = serializers.BooleanField()


class PortalServiceSerializer(serializers.ModelSerializer):
    service_type_label = serializers.CharField(source='get_service_type_display', read_only=True)
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    pop_name = serializers.SerializerMethodField()
    monthly_fee_effective = serializers.SerializerMethodField()
    fee_currency = serializers.SerializerMethodField()
    product_name = serializers.SerializerMethodField()
    resource = serializers.SerializerMethodField()

    class Meta:
        model = ServiceInstance
        fields = [
            'id', 'instance_no', 'service_type', 'service_type_label',
            'status', 'status_label', 'pop_name', 'spec_snapshot',
            'monthly_fee_effective', 'fee_currency', 'product_name',
            'is_trial', 'activated_at', 'expire_time', 'created_at', 'resource',
        ]

    def _resource(self, obj):
        return obj.vps or obj.edge or obj.bandwidth_alloc

    def get_pop_name(self, obj):
        r = self._resource(obj)
        return getattr(getattr(r, 'pop_point', None), 'name', '') if r else ''

    def get_monthly_fee_effective(self, obj):
        try:
            return str(obj.effective_monthly_fee())
        except Exception:
            return str(obj.monthly_fee)

    def get_fee_currency(self, obj):
        try:
            return obj.effective_fee_currency()
        except Exception:
            return obj.fee_currency

    def get_product_name(self, obj):
        r = self._resource(obj)
        p = getattr(r, 'product', None) if r else None
        return p.name if p else ''

    def get_resource(self, obj):
        if obj.vps_id and obj.vps:
            return {'kind': 'vps', 'id': obj.vps.id, 'no': obj.vps.vps_no, 'name': obj.vps.name}
        if obj.edge_id and obj.edge:
            return {'kind': 'edge', 'id': obj.edge.id, 'no': obj.edge.edge_no, 'name': obj.edge.name}
        return None


# ═══════════════════════════════════════════════════════════════
# § 资源：VPS / 边缘加速
# ═══════════════════════════════════════════════════════════════

class PortalVPSSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    os_label = serializers.CharField(source='get_os_type_display', read_only=True)
    pop_name = serializers.CharField(source='pop_point.name', read_only=True)
    region_name = serializers.CharField(source='pop_point.city.country.region.name', read_only=True, allow_null=True)
    country_name = serializers.CharField(source='pop_point.city.country.name', read_only=True, allow_null=True)
    city_name = serializers.CharField(source='pop_point.city.name', read_only=True, allow_null=True)
    product_name = serializers.CharField(source='product.name', read_only=True, allow_null=True)
    has_console = serializers.SerializerMethodField()

    class Meta:
        model = VPS
        fields = [
            'id', 'vps_no', 'name', 'status', 'status_label',
            'pop_name', 'region_name', 'country_name', 'city_name',
            'vcpu', 'ram_mb', 'disk_gb', 'nic_count', 'bandwidth_mbps',
            'mgmt_ip', 'mgmt_port', 'mgmt_username',
            'os_type', 'os_label', 'os_version', 'kernel_version',
            'product_name', 'is_synced', 'has_console',
            'start_time', 'expire_time', 'last_synced_at', 'created_at',
        ]

    def get_has_console(self, obj):
        return bool(obj.source_ref)


class PortalVPSDetailSerializer(PortalVPSSerializer):
    ip_list = serializers.SerializerMethodField()
    interfaces = serializers.SerializerMethodField()

    class Meta(PortalVPSSerializer.Meta):
        fields = PortalVPSSerializer.Meta.fields + ['ip_list', 'interfaces', 'remark']

    def get_ip_list(self, obj):
        return list(
            obj.ip_addresses.values('id', 'address', 'prefix_len', 'is_primary', 'status')
        )

    def get_interfaces(self, obj):
        return list(
            obj.vps_interfaces.values('id', 'ifname', 'mac_address', 'mtu', 'is_primary', 'bandwidth_mbps')
        )


class PortalEdgeSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    protocol_label = serializers.CharField(source='get_protocol_display', read_only=True)
    pop_name = serializers.CharField(source='pop_point.name', read_only=True)
    region_name = serializers.CharField(source='pop_point.city.country.region.name', read_only=True, allow_null=True)
    country_name = serializers.CharField(source='pop_point.city.country.name', read_only=True, allow_null=True)
    city_name = serializers.CharField(source='pop_point.city.name', read_only=True, allow_null=True)
    product_name = serializers.CharField(source='product.name', read_only=True, allow_null=True)

    class Meta:
        model = EdgeAcceleration
        fields = [
            'id', 'edge_no', 'name', 'protocol', 'protocol_label',
            'status', 'status_label', 'pop_name',
            'region_name', 'country_name', 'city_name',
            'bandwidth_mbps', 'product_name',
            'is_synced', 'node_ifname', 'node_pushed',
            'expire_time', 'created_at',
        ]


class PortalEdgeDetailSerializer(PortalEdgeSerializer):
    ip_list = serializers.SerializerMethodField()
    gre_config = serializers.SerializerMethodField()
    wg_config = serializers.SerializerMethodField()
    socks5_config = serializers.SerializerMethodField()

    class Meta(PortalEdgeSerializer.Meta):
        fields = PortalEdgeSerializer.Meta.fields + [
            'ip_list', 'gre_config', 'wg_config', 'socks5_config', 'remark', 'start_time',
        ]

    def get_ip_list(self, obj):
        return list(
            obj.ip_addresses.values('id', 'address', 'prefix_len', 'is_primary', 'status')
        )

    def _safe_config(self, obj, rel_name, fields):
        cfg = getattr(obj, rel_name, None)
        if not cfg:
            return None
        return {f: getattr(cfg, f) for f in fields if hasattr(cfg, f)}

    def get_gre_config(self, obj):
        return self._safe_config(obj, 'gre_config', (
            'id', 'local_ip', 'remote_ip', 'tunnel_ip', 'key', 'ttl', 'pmtud', 'checksum',
        ))

    def get_wg_config(self, obj):
        cfg = getattr(obj, 'wg_config', None)
        if not cfg:
            return None
        return {
            'id': cfg.id,
            'listen_port': cfg.listen_port,
            'interface_ip': cfg.interface_ip,
            'public_key': cfg.public_key,
            'peer_public_key': cfg.peer_public_key,
            'peer_endpoint': cfg.peer_endpoint,
            'peer_allowed_ips': cfg.peer_allowed_ips,
            'persistent_keepalive': cfg.persistent_keepalive,
            'mtu': cfg.mtu,
            'dns': cfg.dns,
            'has_private_key': bool(cfg.private_key),
        }

    def get_socks5_config(self, obj):
        cfg = getattr(obj, 'socks5_config', None)
        if not cfg:
            return None
        return {
            'id': cfg.id,
            'listen_ip': cfg.listen_ip,
            'listen_port': cfg.listen_port,
            'auth_required': cfg.auth_required,
            'username': cfg.username,
            'udp_enabled': cfg.udp_enabled,
            'max_connections': cfg.max_connections,
        }


class PortalSetRootPasswordSerializer(serializers.Serializer):
    password = serializers.CharField(min_length=8, max_length=128, write_only=True)


# ═══════════════════════════════════════════════════════════════
# § 账单
# ═══════════════════════════════════════════════════════════════

class PortalBillingItemSerializer(serializers.ModelSerializer):
    service_type_label = serializers.SerializerMethodField()

    class Meta:
        model = BillingItem
        fields = [
            'id', 'instance_no', 'description', 'service_type', 'service_type_label',
            'product_name', 'period_start', 'period_end',
            'days_used', 'days_in_month', 'is_prorated', 'is_trial',
            'unit_monthly_fee', 'base_monthly_fee', 'overage_monthly_fee',
            'source_currency', 'exchange_rate', 'amount_original', 'currency', 'amount',
            'detail',
        ]

    def get_service_type_label(self, obj):
        mapping = {'vps': 'VPS', 'edge': '边缘加速', 'ip': 'IP 地址', 'bandwidth': '带宽'}
        return mapping.get(obj.service_type, obj.service_type or '—')


class PortalBillingSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    payment_method_label = serializers.CharField(source='get_payment_method_display', read_only=True)
    outstanding_amount = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    items = PortalBillingItemSerializer(many=True, read_only=True)

    class Meta:
        model = CustomerBilling
        fields = [
            'id', 'bill_no', 'bill_month', 'amount', 'currency', 'auto_generated',
            'paid_amount', 'outstanding_amount', 'status', 'status_label',
            'payment_method', 'payment_method_label', 'due_date', 'paid_at',
            'remark', 'created_at', 'items',
        ]


class PortalBillPaySerializer(serializers.Serializer):
    """客户门户账单支付"""
    payment_method = serializers.ChoiceField(
        choices=[(m, payment_service.method_label(m)) for m in sorted(payment_service.ALLOWED_METHODS)],
    )
    step = serializers.ChoiceField(choices=['init', 'confirm'], default='confirm', required=False)
    amount = serializers.DecimalField(max_digits=12, decimal_places=2, required=False, allow_null=True)
    session_id = serializers.CharField(required=False, allow_blank=True, max_length=64)


# ═══════════════════════════════════════════════════════════════
# § 服务工单（下单 / 变更）
# ═══════════════════════════════════════════════════════════════

class PortalOrderSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    order_type_label = serializers.CharField(source='get_order_type_display', read_only=True)
    business_type_label = serializers.CharField(source='get_business_type_display', read_only=True)
    pop_name = serializers.CharField(source='preferred_pop.name', read_only=True, allow_null=True)
    product_name = serializers.SerializerMethodField()

    class Meta:
        model = ServiceOrder
        fields = [
            'id', 'order_no', 'order_type', 'order_type_label',
            'business_type', 'business_type_label', 'status', 'status_label',
            'pop_name', 'product_name',
            'requested_vcpu', 'requested_ram_mb', 'requested_disk_gb', 'requested_os',
            'requested_bandwidth_mbps', 'requested_ip_count',
            'quoted_price', 'requirements', 'created_at',
        ]

    def get_product_name(self, obj):
        return getattr(obj, '_product_name', '')


class PortalOrderCreateSerializer(serializers.Serializer):
    """客户下单：根据产品 + 可选定制规格生成新开服务工单（待审批）。"""
    product_id = serializers.IntegerField()
    quantity = serializers.IntegerField(default=1, min_value=1, max_value=20, required=False)
    requested_os = serializers.CharField(required=False, allow_blank=True, max_length=64)
    requirements = serializers.CharField(required=False, allow_blank=True)
    cpu_cores = serializers.IntegerField(required=False, min_value=0)
    ram_mb = serializers.IntegerField(required=False, min_value=0)
    disk_gb = serializers.IntegerField(required=False, min_value=0)
    nic_count = serializers.IntegerField(required=False, min_value=0)
    bandwidth_mbps = serializers.IntegerField(required=False, min_value=0)
    ip_count = serializers.IntegerField(required=False, min_value=0)

    def validate_product_id(self, value):
        from product_manager.models import Product
        try:
            self._product = Product.objects.select_related('pop_point').get(pk=value)
        except Product.DoesNotExist:
            raise serializers.ValidationError('产品不存在')
        if self._product.status != 'online':
            raise serializers.ValidationError('该产品当前不可下单')
        return value

    def create(self, validated_data):
        product = self._product
        customer = self.context['customer']
        user = self.context['request'].user
        business_type = 'edge_gre' if product.category == 'edge' else 'vps'
        spec = {
            'cpu_cores': validated_data.get('cpu_cores', product.cpu_cores),
            'ram_mb': validated_data.get('ram_mb', product.ram_mb),
            'disk_gb': validated_data.get('disk_gb', product.disk_gb),
            'nic_count': validated_data.get('nic_count', product.nic_count),
            'bandwidth_mbps': validated_data.get('bandwidth_mbps', product.bandwidth_mbps),
            'ip_count': validated_data.get('ip_count', product.ip_count),
        }
        price = product_services.compute_price(product, spec)
        order = ServiceOrder.objects.create(
            order_type=ServiceOrder.OrderType.NEW,
            business_type=business_type,
            status=ServiceOrder.OrderStatus.PENDING,
            customer=customer,
            preferred_pop=product.pop_point,
            requested_vcpu=spec['cpu_cores'] or None,
            requested_ram_mb=spec['ram_mb'] or None,
            requested_disk_gb=spec['disk_gb'] or None,
            requested_os=validated_data.get('requested_os', ''),
            requested_bandwidth_mbps=spec['bandwidth_mbps'] or None,
            requested_ip_count=spec['ip_count'] or None,
            quoted_price=price['monthly_price'],
            requirements=validated_data.get('requirements', ''),
            remark=f'门户下单 · 产品[{product.product_no}] {product.name} ×{validated_data.get("quantity", 1)}',
            created_by=user,
        )
        order._product_name = product.name
        return order


class PortalProductDetailSerializer(ProductDetailSerializer):
    """门户产品详情：补充 POP 下 IP 地址去重后的属性列表。"""
    ip_attribute_list = serializers.SerializerMethodField()

    class Meta(ProductDetailSerializer.Meta):
        fields = ProductDetailSerializer.Meta.fields + ['ip_attribute_list']

    def get_ip_attribute_list(self, obj):
        if not obj.pop_point_id:
            return []
        rows = (
            IPAddress.objects.filter(ip_block__pop_point_id=obj.pop_point_id)
            .exclude(ip_block__ip_attribute='')
            .values('ip_block__ip_attribute')
            .annotate(count=Count('id'))
            .order_by('ip_block__ip_attribute')
        )
        labels = dict(IPAttribute.choices)
        return [
            {
                'value': r['ip_block__ip_attribute'],
                'label': labels.get(r['ip_block__ip_attribute'], r['ip_block__ip_attribute']),
                'count': r['count'],
            }
            for r in rows
        ]


class ChangeRequestSerializer(serializers.Serializer):
    """对已有服务实例发起变更/定制申请（生成变更类工单）。"""
    change_type = serializers.ChoiceField(
        choices=['upgrade', 'downgrade', 'renew', 'terminate', 'change'],
    )
    requested_vcpu = serializers.IntegerField(required=False, min_value=1)
    requested_ram_mb = serializers.IntegerField(required=False, min_value=256)
    requested_disk_gb = serializers.IntegerField(required=False, min_value=1)
    requested_bandwidth_mbps = serializers.IntegerField(required=False, min_value=0)
    requirements = serializers.CharField(required=False, allow_blank=True)
