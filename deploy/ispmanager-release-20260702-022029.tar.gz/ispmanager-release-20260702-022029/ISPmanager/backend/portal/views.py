"""portal/views.py — 客户自助门户接口

公共接口（无需登录）：产品列表/详情、地区树、注册。
客户接口（需客户账号）：总览、服务、订单、账单、资源、资料、变更申请。
"""
from rest_framework import filters, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken

from accounts.serializers import serialize_auth_user
from customer_manager.models import CustomerBilling, BillingItem
from django.db.models import Prefetch, Q
from product_manager import services as product_services
from product_manager.models import Product
from product_manager.serializers import CustomSpecSerializer, ProductListSerializer
from product_manager.views import ProductFilter
from resource_manager.models import City, Country, EdgeAcceleration, Region, VPS
from service_manager.models import ServiceInstance, ServiceOrder

from .permissions import IsCustomer, request_customer
from .serializers import (
    ChangeRequestSerializer, CustomerProfileSerializer, PortalBillPaySerializer,
    PortalBillingSerializer, PortalEdgeDetailSerializer, PortalEdgeSerializer,
    PortalOrderCreateSerializer, PortalOrderSerializer, PortalProductDetailSerializer,
    PortalServiceItemSerializer, PortalServiceSerializer, PortalSetRootPasswordSerializer,
    PortalVPSDetailSerializer, PortalVPSSerializer, RegisterSerializer,
)
from . import monitoring, payment_service, service_list


def _issue_tokens(user):
    refresh = RefreshToken.for_user(user)
    return {'access': str(refresh.access_token), 'refresh': str(refresh)}


# ═══════════════════════════════════════════════════════════════
# § 公共接口
# ═══════════════════════════════════════════════════════════════

class RegisterView(APIView):
    """POST /api/portal/register/ — 客户注册（创建账号 + 客户档案，返回 Token）。"""
    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request):
        s = RegisterSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        result = s.save()
        user = result['user']
        tokens = _issue_tokens(user)
        return Response({
            'code': 200, 'message': '注册成功',
            'data': {**tokens, 'user': serialize_auth_user(user)},
        }, status=status.HTTP_201_CREATED)


class PortalProductViewSet(viewsets.ReadOnlyModelViewSet):
    """GET /api/portal/products/ — 已上线产品（公开），支持多维筛选；登录后可报价测算库存。"""
    permission_classes = [AllowAny]
    authentication_classes = [JWTAuthentication]
    queryset = Product.objects.filter(status='online').select_related(
        'pop_point', 'pop_point__city', 'pop_point__city__country',
        'pop_point__city__country__region', 'supplier', 'template',
    ).prefetch_related('upgrade_rules', 'pop_point__ip_blocks')
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = ProductFilter
    search_fields = ['name', 'product_no']
    ordering_fields = ['sort_order', 'monthly_price', 'created_at']
    ordering = ['sort_order', 'monthly_price']

    def get_serializer_class(self):
        return PortalProductDetailSerializer if self.action == 'retrieve' else ProductListSerializer

    def _base_spec(self, product):
        return {
            'cpu_cores': product.cpu_cores, 'ram_mb': product.ram_mb, 'disk_gb': product.disk_gb,
            'bandwidth_mbps': product.bandwidth_mbps, 'ip_count': product.ip_count,
            'nic_count': product.nic_count,
        }

    @action(detail=True, methods=['post'], url_path='quote')
    def quote(self, request, pk=None):
        """定制规格报价：公开返回价格；登录用户额外返回 POP 可开通数量（stock）。"""
        product = self.get_object()
        ser = CustomSpecSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        custom = {**self._base_spec(product), **{k: v for k, v in ser.validated_data.items()}}
        if 'nic_count' in request.data:
            custom['nic_count'] = request.data.get('nic_count', product.nic_count)
        price = product_services.compute_price(product, custom)
        payload = {
            'price': price,
            'custom_spec': custom,
            'base_spec': product_services.product_base_spec(product),
        }
        if request.user and request.user.is_authenticated:
            payload['stock'] = product_services.estimate_stock(product.pop_point, custom)
        return Response(payload)


class LocationsView(APIView):
    """GET /api/portal/locations/ — 区域/国家/城市三级数据（公开，供产品筛选）。"""
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        regions = list(Region.objects.values('id', 'name'))
        countries = list(Country.objects.values('id', 'name', 'region'))
        cities = list(City.objects.values('id', 'name', 'country'))
        return Response({'code': 200, 'message': 'ok', 'data': {
            'regions': regions, 'countries': countries, 'cities': cities,
        }})


# ═══════════════════════════════════════════════════════════════
# § 客户 · 总览 / 资料
# ═══════════════════════════════════════════════════════════════

class DashboardView(APIView):
    permission_classes = [IsCustomer]

    def get(self, request):
        customer = request_customer(request)
        if customer is None:
            return Response({'code': 200, 'message': 'ok', 'data': {}})

        instances = ServiceInstance.objects.filter(service_order__customer=customer)
        active = instances.filter(status='active')
        vps_qs = VPS.objects.filter(customer=customer)
        edge_qs = EdgeAcceleration.objects.filter(customer=customer)
        bills = CustomerBilling.objects.filter(customer=customer)
        unpaid = bills.filter(status__in=['unpaid', 'overdue'])

        monthly_cost = 0.0
        for ins in active.select_related('service_order'):
            try:
                monthly_cost += float(ins.effective_monthly_fee())
            except Exception:
                pass

        outstanding = 0.0
        for b in unpaid:
            outstanding += float(b.amount) - float(b.paid_amount)

        return Response({'code': 200, 'message': 'ok', 'data': {
            'customer_name': customer.name,
            'customer_no': customer.customer_no,
            'status': customer.status,
            'balance': str(customer.balance),
            'credit_limit': str(customer.credit_limit),
            'active_services': active.count(),
            'total_services': instances.exclude(status='terminated').count(),
            'vps_count': vps_qs.count(),
            'edge_count': edge_qs.count(),
            'pending_orders': ServiceOrder.objects.filter(
                customer=customer,
                status__in=['pending', 'approved', 'provisioning'],
            ).count(),
            'unpaid_bills': unpaid.count(),
            'outstanding_amount': round(outstanding, 2),
            'monthly_cost': round(monthly_cost, 2),
        }})


class ProfileView(APIView):
    permission_classes = [IsCustomer]

    def get(self, request):
        customer = request_customer(request)
        if customer is None:
            return Response({'code': 404, 'message': '未关联客户档案'}, status=404)
        return Response({'code': 200, 'message': 'ok', 'data': CustomerProfileSerializer(customer).data})

    def patch(self, request):
        customer = request_customer(request)
        if customer is None:
            return Response({'code': 404, 'message': '未关联客户档案'}, status=404)
        s = CustomerProfileSerializer(customer, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response({'code': 200, 'message': '资料已更新', 'data': s.data})


# ═══════════════════════════════════════════════════════════════
# § 客户 · 服务 / 订单 / 账单 / 资源
# ═══════════════════════════════════════════════════════════════

class CustomerScopedMixin:
    permission_classes = [IsCustomer]

    def _customer(self):
        return request_customer(self.request)


class MyServiceViewSet(CustomerScopedMixin, viewsets.ReadOnlyModelViewSet):
    """客户「我的服务」：聚合 ServiceInstance + 直连 VPS/Edge 资源。"""
    serializer_class = PortalServiceItemSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['status', 'service_type']
    ordering = ['-created_at']

    def get_queryset(self):
        """保留 detail/change_request 用的 ServiceInstance 查询集。"""
        customer = self._customer()
        if customer is None:
            return ServiceInstance.objects.none()
        return ServiceInstance.objects.filter(
            Q(service_order__customer=customer)
            | Q(vps__customer=customer)
            | Q(edge__customer=customer)
        ).select_related(
            'service_order', 'vps__pop_point', 'edge__pop_point',
        ).distinct()

    def list(self, request, *args, **kwargs):
        customer = self._customer()
        if customer is None:
            return Response({'count': 0, 'next': None, 'previous': None, 'results': []})
        status_filter = request.query_params.get('status') or None
        service_type = request.query_params.get('service_type') or None
        items = service_list.build_customer_service_items(customer, status_filter=status_filter)
        if service_type:
            items = [it for it in items if it['service_type'] == service_type]
        page = self.paginate_queryset(items)
        serializer = PortalServiceItemSerializer(page if page is not None else items, many=True)
        if page is not None:
            return self.get_paginated_response(serializer.data)
        return Response(serializer.data)

    @action(detail=True, methods=['post'], url_path='change_request')
    def change_request(self, request, pk=None):
        """对该服务实例发起变更/定制申请（生成变更类工单，待审批）。"""
        instance = self.get_object()
        s = ChangeRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        resource = instance.vps or instance.edge
        order = ServiceOrder.objects.create(
            order_type=d['change_type'],
            business_type='vps' if instance.service_type == 'vps' else 'edge_gre',
            status=ServiceOrder.OrderStatus.PENDING,
            customer=instance.service_order.customer,
            preferred_pop=getattr(resource, 'pop_point', None),
            requested_vcpu=d.get('requested_vcpu'),
            requested_ram_mb=d.get('requested_ram_mb'),
            requested_disk_gb=d.get('requested_disk_gb'),
            requested_bandwidth_mbps=d.get('requested_bandwidth_mbps'),
            requirements=d.get('requirements', ''),
            remark=f'门户变更申请 · 实例[{instance.instance_no}] · {d["change_type"]}',
            created_by=request.user,
        )
        return Response({'code': 200, 'message': '变更申请已提交，等待审批',
                         'data': PortalOrderSerializer(order).data})


class MyOrderViewSet(CustomerScopedMixin, viewsets.ModelViewSet):
    http_method_names = ['get', 'post', 'head', 'options']
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['status', 'order_type', 'business_type']
    ordering = ['-created_at']

    def get_serializer_class(self):
        return PortalOrderCreateSerializer if self.action == 'create' else PortalOrderSerializer

    def get_queryset(self):
        customer = self._customer()
        if customer is None:
            return ServiceOrder.objects.none()
        return ServiceOrder.objects.filter(customer=customer).select_related('preferred_pop')

    def get_serializer_context(self):
        ctx = super().get_serializer_context()
        ctx['customer'] = self._customer()
        return ctx

    def create(self, request, *args, **kwargs):
        customer = self._customer()
        if customer is None:
            return Response({'code': 403, 'message': '未关联客户档案，无法下单'}, status=403)
        s = self.get_serializer(data=request.data)
        s.is_valid(raise_exception=True)
        order = s.save()
        return Response({'code': 200, 'message': '下单成功，工单已提交审批',
                         'data': PortalOrderSerializer(order).data}, status=status.HTTP_201_CREATED)


class MyBillViewSet(CustomerScopedMixin, viewsets.ReadOnlyModelViewSet):
    serializer_class = PortalBillingSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['status', 'bill_month']
    ordering = ['-bill_month']

    def get_queryset(self):
        customer = self._customer()
        if customer is None:
            return CustomerBilling.objects.none()
        items_qs = BillingItem.objects.select_related('product', 'service_instance')
        return CustomerBilling.objects.filter(customer=customer).prefetch_related(
            Prefetch('items', queryset=items_qs),
        )

    @action(detail=True, methods=['post'], url_path='pay')
    def pay(self, request, pk=None):
        """POST /api/portal/bills/{id}/pay/ — 客户支付账单。

        线下：cash / bank_transfer，step=confirm（默认）直接入账。
        在线：wechat / alipay / paypal，step=init 创建会话，step=confirm + session_id 确认入账。
        """
        billing = self.get_object()
        ser = PortalBillPaySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        method = data['payment_method']
        step = data.get('step') or 'confirm'

        try:
            if method in payment_service.ONLINE_METHODS:
                if step == 'init':
                    session = payment_service.create_online_payment_session(billing, method)
                    return Response({
                        'code': 200,
                        'message': '支付订单已创建，请完成扫码/跳转支付',
                        'data': session,
                    })
                session_id = (data.get('session_id') or '').strip()
                if not session_id:
                    return Response({'code': 400, 'message': '缺少支付会话 session_id'}, status=400)
                billing = payment_service.confirm_online_payment_session(
                    session_id, billing, request.user, request=request,
                )
            else:
                pay_amount = payment_service.parse_pay_amount(data.get('amount'), billing)
                billing = payment_service.apply_bill_payment(
                    billing, pay_amount, method, request.user, request=request,
                )
        except ValueError as exc:
            return Response({'code': 400, 'message': str(exc)}, status=400)

        return Response({
            'code': 200,
            'message': '支付成功',
            'data': PortalBillingSerializer(billing).data,
        })

    @action(detail=False, methods=['get'], url_path='payment-methods')
    def payment_methods(self, request):
        """GET /api/portal/bills/payment-methods/ — 可用支付方式列表。"""
        methods = [
            {'value': 'cash', 'label': '现金', 'online': False},
            {'value': 'bank_transfer', 'label': '银行转账', 'online': False},
            {'value': 'wechat', 'label': '微信支付', 'online': True},
            {'value': 'alipay', 'label': '支付宝', 'online': True},
            {'value': 'paypal', 'label': 'PayPal', 'online': True},
        ]
        return Response({'code': 200, 'message': 'ok', 'data': methods})


class MyVPSViewSet(CustomerScopedMixin, viewsets.ReadOnlyModelViewSet):
    serializer_class = PortalVPSSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['status']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return PortalVPSDetailSerializer
        return PortalVPSSerializer

    def get_queryset(self):
        customer = self._customer()
        if customer is None:
            return VPS.objects.none()
        return VPS.objects.filter(customer=customer).select_related(
            'pop_point__city__country__region', 'product',
        ).prefetch_related('ip_addresses', 'vps_interfaces')

    @action(detail=True, methods=['post'], url_path='power')
    def power(self, request, pk=None):
        """VPS 电源：start / stop / restart / shutdown"""
        from resource_manager import pve_ops
        from resource_manager.pemanager_client import PemanagerError

        vps = self.get_object()
        action_name = request.data.get('action', '')
        try:
            result = pve_ops.vm_power(vps, action_name, dry_run=False)
        except PemanagerError as e:
            return Response({'code': 400, 'message': str(e)}, status=400)
        except Exception as e:  # noqa: BLE001
            return Response({'code': 400, 'message': f'电源操作失败：{e}'}, status=400)
        vps.refresh_from_db()
        return Response({
            'code': 200, 'message': '操作成功', 'data': result,
            'vps': PortalVPSSerializer(vps).data,
        })

    @action(detail=True, methods=['get'], url_path='vnc_ticket')
    def vnc_ticket(self, request, pk=None):
        """获取 noVNC 控制台票据"""
        from resource_manager.pemanager_client import PemanagerClient, PemanagerError

        vps = self.get_object()
        if not vps.source_ref:
            return Response({'code': 400, 'message': '该 VPS 暂不支持远程控制台'}, status=400)
        pop = vps.pop_point
        base = pop.api_base_url or (f'http://{pop.mgmt_ip}' if pop.mgmt_ip else '')
        username = pop.api_username or pop.mgmt_username
        password = pop.api_password or pop.mgmt_password
        try:
            client = PemanagerClient(base, username, password)
            client.login()
            data = client.vnc_ticket(vps.source_ref) or {}
        except PemanagerError as e:
            return Response({'code': 400, 'message': str(e)}, status=400)
        except Exception as e:  # noqa: BLE001
            return Response({'code': 400, 'message': f'获取 VNC 票据失败：{e}'}, status=400)
        return Response({
            'code': 200, 'message': 'ok',
            'data': {
                'ticket': data.get('ticket'),
                'password': data.get('password') or data.get('ticket'),
                'port': data.get('port'),
                'ws_path': f'/ws/resource/vnc/{vps.pk}/',
            },
        })

    @action(detail=True, methods=['post'], url_path='set_root_password')
    def set_root_password(self, request, pk=None):
        """设置 VPS root 密码（保存至档案；节点同步接口预留）"""
        vps = self.get_object()
        ser = PortalSetRootPasswordSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        pwd = ser.validated_data['password']
        vps.mgmt_password = pwd
        if not vps.mgmt_username:
            vps.mgmt_username = 'root'
        vps.save(update_fields=['mgmt_password', 'mgmt_username', 'updated_at'])
        return Response({
            'code': 200,
            'message': 'Root 密码已更新',
            'data': {'username': vps.mgmt_username, 'gateway_reserved': True},
        })

    @action(detail=True, methods=['post'], url_path='sync_now')
    def sync_now(self, request, pk=None):
        """从节点同步 VPS 状态"""
        from resource_manager.sync_service import sync_single_vps_from_node
        from resource_manager.pemanager_client import PemanagerError

        vps = self.get_object()
        try:
            result = sync_single_vps_from_node(vps)
        except PemanagerError as e:
            return Response({'code': 400, 'message': str(e)}, status=400)
        except Exception as e:  # noqa: BLE001
            return Response({'code': 400, 'message': f'同步失败：{e}'}, status=400)
        if not result.get('ok'):
            detail = result.get('detail') or '同步未完成'
            return Response({'code': 400, 'message': detail, 'data': result}, status=400)
        vps.refresh_from_db()
        return Response({
            'code': 200, 'message': '同步成功',
            'data': {'result': result, 'vps': PortalVPSDetailSerializer(vps).data},
        })

    @action(detail=True, methods=['get'], url_path='traffic')
    def traffic(self, request, pk=None):
        """VPS 流量监控（预留网关）"""
        vps = self.get_object()
        hours = min(int(request.query_params.get('hours', 24)), 168)
        data = monitoring.traffic_series('vps', vps.pk, vps.bandwidth_mbps, hours=hours)
        return Response({'code': 200, 'message': 'ok', 'data': data})


class MyEdgeViewSet(CustomerScopedMixin, viewsets.ReadOnlyModelViewSet):
    serializer_class = PortalEdgeSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['status', 'protocol']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return PortalEdgeDetailSerializer
        return PortalEdgeSerializer

    def get_queryset(self):
        customer = self._customer()
        if customer is None:
            return EdgeAcceleration.objects.none()
        return EdgeAcceleration.objects.filter(customer=customer).select_related(
            'pop_point__city__country__region', 'product',
        ).prefetch_related(
            'ip_addresses', 'gre_config', 'wg_config', 'socks5_config',
        )

    @action(detail=True, methods=['get', 'put', 'patch'], url_path='protocol_config')
    def protocol_config(self, request, pk=None):
        """读取 / 更新 GRE / WireGuard / Socks5 配置"""
        from resource_manager.models import GREConfig, WireguardConfig, Socks5Config
        from resource_manager.serializers import (
            GREConfigSerializer, WireguardConfigSerializer, Socks5ConfigSerializer,
        )
        from resource_manager.deploy_service import mark_pop_dirty

        edge = self.get_object()
        protocol_map = {
            'gre': (GREConfig, GREConfigSerializer, 'gre_config'),
            'wireguard': (WireguardConfig, WireguardConfigSerializer, 'wg_config'),
            'socks5': (Socks5Config, Socks5ConfigSerializer, 'socks5_config'),
        }
        if edge.protocol not in protocol_map:
            return Response({'code': 400, 'message': '当前协议不支持配置'}, status=400)

        model_cls, ser_cls, rel_name = protocol_map[edge.protocol]
        config = getattr(edge, rel_name, None)

        if request.method == 'GET':
            if not config:
                return Response({'code': 200, 'message': 'ok', 'data': None})
            return Response({'code': 200, 'message': 'ok', 'data': ser_cls(config).data})

        partial = request.method == 'PATCH'
        if config:
            ser = ser_cls(config, data=request.data, partial=partial)
        else:
            ser = ser_cls(data={**request.data, 'edge': edge.pk})
        ser.is_valid(raise_exception=True)
        ser.save()
        mark_pop_dirty(edge.pop_point)
        edge.refresh_from_db()
        return Response({
            'code': 200, 'message': '配置已保存',
            'data': PortalEdgeDetailSerializer(edge).data,
        })

    @action(detail=True, methods=['post'], url_path='push_to_node')
    def push_to_node(self, request, pk=None):
        """下发隧道配置到节点"""
        from resource_manager.deploy_service import push_pop_to_node
        from resource_manager.pemanager_client import PemanagerError

        edge = self.get_object()
        if edge.protocol == EdgeAcceleration.Protocol.SOCKS5:
            return Response({'code': 400, 'message': 'Socks5 暂不支持节点下发'}, status=400)
        dry_run = bool(request.data.get('dry_run', False))
        try:
            result = push_pop_to_node(
                edge.pop_point, sections=['customers', 'edge_tunnels'], dry_run=dry_run,
            )
        except PemanagerError as e:
            return Response({'code': 400, 'message': str(e)}, status=400)
        except Exception as e:  # noqa: BLE001
            return Response({'code': 400, 'message': f'下发失败：{e}'}, status=400)
        edge.refresh_from_db()
        return Response({'code': 200, 'message': '下发成功', 'data': result})

    @action(detail=True, methods=['post'], url_path='wg_genkey')
    def wg_genkey(self, request, pk=None):
        """WireGuard 密钥对生成"""
        from resource_manager.pemanager_client import PemanagerClient, PemanagerError

        edge = self.get_object()
        pop = edge.pop_point
        base = pop.api_base_url or (f'http://{pop.mgmt_ip}' if pop.mgmt_ip else '')
        username = pop.api_username or pop.mgmt_username
        password = pop.api_password or pop.mgmt_password
        try:
            client = PemanagerClient(base, username, password)
            client.login()
            data = client.wg_genkey() or {}
        except PemanagerError as e:
            return Response({'code': 400, 'message': str(e)}, status=400)
        except Exception as e:  # noqa: BLE001
            return Response({'code': 400, 'message': f'生成密钥失败：{e}'}, status=400)
        return Response({
            'code': 200, 'message': 'ok',
            'data': {
                'private': data.get('private') or data.get('private_key'),
                'public': data.get('public') or data.get('public_key'),
            },
        })

    @action(detail=True, methods=['get'], url_path='traffic')
    def traffic(self, request, pk=None):
        """边缘加速流量监控"""
        edge = self.get_object()
        hours = min(int(request.query_params.get('hours', 24)), 168)
        data = monitoring.traffic_series('edge', edge.pk, edge.bandwidth_mbps, hours=hours)
        return Response({'code': 200, 'message': 'ok', 'data': data})

    @action(detail=True, methods=['get'], url_path='quality')
    def quality(self, request, pk=None):
        """边缘加速品质监控（延迟/丢包/抖动）"""
        edge = self.get_object()
        hours = min(int(request.query_params.get('hours', 24)), 168)
        data = monitoring.quality_series(edge.pk, edge.protocol, hours=hours)
        return Response({'code': 200, 'message': 'ok', 'data': data})
