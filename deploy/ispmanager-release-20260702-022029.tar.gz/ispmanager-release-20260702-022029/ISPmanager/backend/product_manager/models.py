"""
product_manager/models.py
产品管理模块数据模型

模型层次：
  ProductSpec        产品规格（VPS：CPU/内存/硬盘/网卡/带宽/IP；边缘加速：类型/带宽/IP）
  ProductTemplate    产品模版（如 VPS 1C1G / 2C4G 等预设规格）
  TemplatePricing    模版定价（对应 POP 点的月租 / 信誉值定价）
  Product            产品（关联 POP + 模版 + 供应商，含基础定价）
  ProductUpgradeRule 阶梯式定制升级定价规则
  ProductPublishLog  产品发布 / 上下线日志

资源容量/库存的动态计算见 services.py。
"""
import datetime

from django.contrib.auth.models import User
from django.db import models


class ProductCategory(models.TextChoices):
    VPS = 'vps', 'VPS 主机'
    EDGE = 'edge', '边缘加速'


class AccelType(models.TextChoices):
    GRE = 'gre', 'GRE'
    WIREGUARD = 'wireguard', 'WireGuard'
    PROXY = 'proxy', '代理 (Socks5)'


# 公共规格字段抽象（VPS + 边缘加速共用）
class SpecFieldsMixin(models.Model):
    cpu_cores = models.PositiveSmallIntegerField('CPU 核心', default=1)
    ram_mb = models.PositiveIntegerField('内存(MB)', default=1024)
    disk_gb = models.PositiveIntegerField('硬盘(GB)', default=20)
    nic_count = models.PositiveSmallIntegerField('网卡数量', default=1)
    bandwidth_mbps = models.PositiveIntegerField('带宽(Mbps)', default=0)
    ip_count = models.PositiveSmallIntegerField('IP 数量', default=1)
    accel_type = models.CharField(
        '加速类型', max_length=16,
        choices=AccelType.choices, blank=True,
        help_text='仅边缘加速产品有效：GRE / WireGuard / 代理',
    )

    class Meta:
        abstract = True

    def spec_dict(self) -> dict:
        return {
            'cpu_cores': self.cpu_cores,
            'ram_mb': self.ram_mb,
            'disk_gb': self.disk_gb,
            'nic_count': self.nic_count,
            'bandwidth_mbps': self.bandwidth_mbps,
            'ip_count': self.ip_count,
            'accel_type': self.accel_type,
        }


# ═══════════════════════════════════════════════════════════════
# § 1  产品规格
# ═══════════════════════════════════════════════════════════════

class ProductSpec(SpecFieldsMixin):
    """可复用的产品规格定义"""

    spec_no = models.CharField('规格编号', max_length=32, unique=True, editable=False, null=True, blank=True)
    name = models.CharField('规格名称', max_length=128)
    category = models.CharField(
        '产品类别', max_length=8,
        choices=ProductCategory.choices, default=ProductCategory.VPS,
    )
    pop_point = models.ForeignKey(
        'resource_manager.PopPoint', on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联 POP 点', related_name='product_specs',
    )
    supplier = models.ForeignKey(
        'supplier_manager.Supplier', on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联供应商', related_name='product_specs',
    )
    is_active = models.BooleanField('启用', default=True)
    remark = models.CharField('备注', max_length=512, blank=True)
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='创建人', related_name='created_product_specs',
    )
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '产品规格'
        verbose_name_plural = '产品规格列表'
        ordering = ['category', 'name']

    def __str__(self):
        return f'[{self.spec_no}] {self.name}'

    def save(self, *args, **kwargs):
        if not self.spec_no:
            prefix = 'SPEC'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = ProductSpec.objects.filter(
                spec_no__startswith=f'{prefix}{date_str}'
            ).order_by('-spec_no').first()
            seq = int(last.spec_no[-4:]) + 1 if last and last.spec_no else 1
            self.spec_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


# ═══════════════════════════════════════════════════════════════
# § 2  产品模版
# ═══════════════════════════════════════════════════════════════

class ProductTemplate(SpecFieldsMixin):
    """产品模版（预设规格，如 VPS 1C1G）"""

    template_no = models.CharField('模版编号', max_length=32, unique=True, editable=False, null=True, blank=True)
    name = models.CharField('模版名称', max_length=128, help_text='如 VPS 1C1G / 2C4G')
    category = models.CharField(
        '产品类别', max_length=8,
        choices=ProductCategory.choices, default=ProductCategory.VPS,
    )
    spec = models.ForeignKey(
        ProductSpec, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='基准规格', related_name='templates',
    )
    is_active = models.BooleanField('启用', default=True)
    description = models.CharField('描述', max_length=512, blank=True)
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='创建人', related_name='created_product_templates',
    )
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '产品模版'
        verbose_name_plural = '产品模版列表'
        ordering = ['category', 'name']

    def __str__(self):
        return f'[{self.template_no}] {self.name}'

    def save(self, *args, **kwargs):
        if not self.template_no:
            prefix = 'TPL'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = ProductTemplate.objects.filter(
                template_no__startswith=f'{prefix}{date_str}'
            ).order_by('-template_no').first()
            seq = int(last.template_no[-4:]) + 1 if last and last.template_no else 1
            self.template_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


class TemplatePricing(models.Model):
    """模版在某个 POP 点的定价（月租 / 信誉值）"""

    template = models.ForeignKey(
        ProductTemplate, on_delete=models.CASCADE,
        verbose_name='模版', related_name='pricings',
    )
    pop_point = models.ForeignKey(
        'resource_manager.PopPoint', on_delete=models.CASCADE,
        verbose_name='POP 点', related_name='template_pricings',
    )
    monthly_price = models.DecimalField('月租价', max_digits=12, decimal_places=2, default=0)
    reputation_price = models.DecimalField('信誉值定价', max_digits=12, decimal_places=2, default=0)
    setup_price = models.DecimalField('一次性安装费', max_digits=12, decimal_places=2, default=0)
    currency = models.CharField('币种', max_length=8, default='CNY')
    is_active = models.BooleanField('启用', default=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '模版定价'
        verbose_name_plural = '模版定价列表'
        ordering = ['template', 'pop_point']
        constraints = [
            models.UniqueConstraint(fields=['template', 'pop_point'], name='uniq_template_pop_pricing'),
        ]

    def __str__(self):
        return f'{self.template.name}@{self.pop_point} ¥{self.monthly_price}/月'


# ═══════════════════════════════════════════════════════════════
# § 3  产品
# ═══════════════════════════════════════════════════════════════

class Product(SpecFieldsMixin):
    """可售产品（绑定 POP + 模版 + 供应商，含定价与发布状态）"""

    class Status(models.TextChoices):
        DRAFT = 'draft', '草稿'
        ONLINE = 'online', '已上线'
        OFFLINE = 'offline', '已下线'
        ARCHIVED = 'archived', '已归档'

    product_no = models.CharField('产品编号', max_length=32, unique=True, editable=False, null=True, blank=True)
    name = models.CharField('产品名称', max_length=128)
    category = models.CharField(
        '产品类别', max_length=8,
        choices=ProductCategory.choices, default=ProductCategory.VPS,
    )
    status = models.CharField('状态', max_length=12, choices=Status.choices, default=Status.DRAFT)

    pop_point = models.ForeignKey(
        'resource_manager.PopPoint', on_delete=models.PROTECT,
        verbose_name='关联 POP 点', related_name='products',
    )
    template = models.ForeignKey(
        ProductTemplate, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联模版', related_name='products',
    )
    supplier = models.ForeignKey(
        'supplier_manager.Supplier', on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联供应商', related_name='products',
    )

    # ── 基础定价 ──────────────────────────────────────────────
    monthly_price = models.DecimalField('月租价', max_digits=12, decimal_places=2, default=0)
    reputation_price = models.DecimalField('信誉值定价', max_digits=12, decimal_places=2, default=0)
    setup_price = models.DecimalField('一次性安装费', max_digits=12, decimal_places=2, default=0)
    currency = models.CharField('币种', max_length=8, default='CNY')

    # ── 展示 / 发布 ───────────────────────────────────────────
    sort_order = models.IntegerField('排序', default=0)
    is_featured = models.BooleanField('推荐', default=False)
    description = models.TextField('产品描述', blank=True)
    remark = models.TextField('内部备注', blank=True)
    published_at = models.DateTimeField('上线时间', null=True, blank=True)
    offline_at = models.DateTimeField('下线时间', null=True, blank=True)

    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='创建人', related_name='created_products',
    )
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '产品'
        verbose_name_plural = '产品列表'
        ordering = ['sort_order', '-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['category']),
            models.Index(fields=['pop_point']),
        ]

    def __str__(self):
        return f'[{self.product_no}] {self.name}'

    def save(self, *args, **kwargs):
        if not self.product_no:
            prefix = 'PRD'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = Product.objects.filter(
                product_no__startswith=f'{prefix}{date_str}'
            ).order_by('-product_no').first()
            seq = int(last.product_no[-4:]) + 1 if last and last.product_no else 1
            self.product_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


class ProductUpgradeRule(models.Model):
    """阶梯式定制升级定价规则（按资源单位逐档计价）"""

    class ResourceKind(models.TextChoices):
        CPU = 'cpu', 'CPU 核'
        RAM = 'ram', '内存(GB)'
        DISK = 'disk', '硬盘(GB)'
        BANDWIDTH = 'bandwidth', '带宽(Mbps)'
        IP = 'ip', 'IP 数量'
        NIC = 'nic', '网卡数量'

    product = models.ForeignKey(
        Product, on_delete=models.CASCADE,
        verbose_name='产品', related_name='upgrade_rules',
    )
    resource_kind = models.CharField('资源类型', max_length=16, choices=ResourceKind.choices)
    # 阶梯区间：在 [min_qty, max_qty] 升级数量内，按 unit_price 计价
    min_qty = models.PositiveIntegerField('阶梯起始数量', default=0,
                                          help_text='超出基础规格的升级数量下界（含）')
    max_qty = models.PositiveIntegerField('阶梯结束数量', null=True, blank=True,
                                          help_text='升级数量上界（含）；留空表示不封顶')
    unit_price = models.DecimalField('每单位月租', max_digits=12, decimal_places=4, default=0)
    unit_reputation = models.DecimalField('每单位信誉值', max_digits=12, decimal_places=4, default=0)
    is_active = models.BooleanField('启用', default=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '阶梯升级定价'
        verbose_name_plural = '阶梯升级定价'
        ordering = ['product', 'resource_kind', 'min_qty']

    def __str__(self):
        upper = self.max_qty if self.max_qty is not None else '∞'
        return f'{self.product.name} {self.get_resource_kind_display()} [{self.min_qty}-{upper}] ¥{self.unit_price}'


class ProductPublishLog(models.Model):
    """产品发布 / 上下线操作日志"""

    class Action(models.TextChoices):
        PUBLISH = 'publish', '发布'
        ONLINE = 'online', '上线'
        OFFLINE = 'offline', '下线'
        ARCHIVE = 'archive', '归档'
        UPDATE = 'update', '更新'

    product = models.ForeignKey(
        Product, on_delete=models.CASCADE,
        verbose_name='产品', related_name='publish_logs',
    )
    action = models.CharField('动作', max_length=12, choices=Action.choices)
    from_status = models.CharField('原状态', max_length=12, blank=True)
    to_status = models.CharField('新状态', max_length=12, blank=True)
    message = models.CharField('说明', max_length=512, blank=True)
    operator = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='操作人',
    )
    created_at = models.DateTimeField('时间', auto_now_add=True)

    class Meta:
        verbose_name = '产品发布日志'
        verbose_name_plural = '产品发布日志'
        ordering = ['-created_at']

    def __str__(self):
        return f'[{self.get_action_display()}] {self.product.name}'
