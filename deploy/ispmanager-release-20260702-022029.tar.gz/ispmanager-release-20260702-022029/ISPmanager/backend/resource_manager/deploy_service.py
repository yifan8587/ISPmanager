"""
配置下发服务：把 ISPmanager 中维护的 POP 点配置下发到节点 vpopmanager，
实现「中心定义、节点执行」的统一管理。

当前支持下发：
  - 静态路由   StaticRoute     → 节点 desired-routes + apply-system（ip route replace 即时生效）
  - 策略路由   PolicyRoute     → 节点 policy-rules + apply-system
  - 边缘隧道   EdgeAcceleration → 节点 desired-tunnels + apply-system（GRE / VXLAN / WireGuard）
  - 带宽限速   VPS 带宽         → 节点 VM 网卡 rate（allocate_bandwidth）

幂等策略：
  下发前先拉取节点已有的 desired-* 记录，按业务键匹配；已存在的复用其 id，
  不存在的才创建，最后用 apply-system{ids} 选择性下发，避免重复推送脏数据。

dry-run（默认开启）：
  仅计算「将创建 / 将下发」的计划并返回，不实际写节点；前端二次确认后再带
  dry_run=False 真正执行。

不下发：netplan 物理接口、IP 分配、Socks5（节点无对应隧道通道）、PVE 虚机生命周期
（虚机生命周期由 pve_ops 单独处理）。
"""

import re

from django.utils import timezone

from .models import (
    PopPoint, StaticRoute, PolicyRoute, EdgeAcceleration, VPS,
)
from .pemanager_client import PemanagerClient, PemanagerError


# 接口类型 → netplan 设备类
_DEV_CLASS_MAP = {
    'physical': 'ethernets',
    'vlan': 'vlans',
    'bond': 'bonds',
    'bridge': 'bridges',
    'tunnel': 'tunnels',
}


def _dev_class(interface):
    if interface is None:
        return 'ethernets'
    return _DEV_CLASS_MAP.get(interface.interface_type, 'ethernets')


def _is_v6(*values):
    return any(':' in str(v) for v in values if v)


# ═══════════════════════════════════════════════════════════════
# 静态路由下发
# ═══════════════════════════════════════════════════════════════

def _push_static_routes(pop, client, dry_run=True):
    routes = list(
        StaticRoute.objects
        .filter(route_table__pop_point=pop, is_active=True)
        .select_related('route_table', 'interface')
    )
    if not routes:
        return {'pushed': 0, 'created': 0, 'applied': 0, 'skipped': 0,
                'note': '无可下发的静态路由', 'plan': []}

    # 节点已有 desired-routes 索引（记录 id 与当前 on_link，便于纠正漂移）
    existing = client.list_desired_routes()
    index = {}
    for r in existing or []:
        if not isinstance(r, dict):
            continue
        key = (
            str(r.get('interface_name') or ''),
            str(r.get('dest_cidr') or ''),
            str(r.get('gateway') or ''),
        )
        if r.get('id'):
            index[key] = {'id': r['id'], 'on_link': bool(r.get('on_link'))}

    ids = []
    plan = []
    created = patched = skipped = 0
    for rt in routes:
        if not rt.interface or not rt.interface.ifname:
            skipped += 1  # 节点 desired-route 必须指定出接口
            continue
        ifname = rt.interface.ifname
        gateway = rt.gateway or ''
        table_id = rt.route_table.table_id if rt.route_table else None
        # on_link 判定（避免内核 "Nexthop has invalid gateway"）：
        #  - 无网关：on_link=True（直连/设备路由）
        #  - 有网关且出接口是隧道（GRE/VXLAN/WireGuard 等 PtP）：网关在对端，须 on-link
        #  - 有网关且为默认路由（0.0.0.0/0、::/0、default）：按 on-link 处理（桥接/云环境常态，
        #    且接口可能尚未就绪，强制 on-link 保证路由可装入）
        #  - 其余普通接口路由：on_link=False，交由节点按直连子网/自动 onlink 判断
        is_tunnel = getattr(rt.interface, 'interface_type', None) == 'tunnel'
        is_default = str(rt.destination).strip().lower() in ('0.0.0.0/0', '::/0', 'default')
        on_link = (not rt.gateway) or (bool(rt.gateway) and (is_tunnel or is_default))

        key = (ifname, rt.destination, str(gateway))
        rec = index.get(key)
        node_id = rec['id'] if rec else None
        if rec is not None:
            # 复用：若 on_link 漂移则纠正（修复历史 on_link=False 导致的下发失败）
            action_label = '复用'
            if on_link and not rec['on_link']:
                action_label = '纠正on-link'
                if not dry_run:
                    client.patch_desired_route(node_id, {'on_link': True})
                    patched += 1
            plan.append({'dest': rt.destination, 'via': rt.gateway or 'on-link',
                         'dev': ifname, 'action': action_label})
        else:
            plan.append({'dest': rt.destination, 'via': rt.gateway or 'on-link',
                         'dev': ifname, 'action': '新建'})
            if dry_run:
                created += 1
                continue
            payload = {
                'interface_name': ifname,
                'netplan_device_class': _dev_class(rt.interface),
                'dest_cidr': rt.destination,
                'gateway': rt.gateway or None,
                'on_link': on_link,
                'metric': rt.metric or None,
                'route_table': table_id if table_id and table_id != 254 else None,
                'remark': 'ISPmanager 下发',
            }
            obj = client.create_desired_route(payload)
            node_id = obj.get('id') if isinstance(obj, dict) else None
            if node_id:
                created += 1
        if node_id:
            ids.append(node_id)

    if dry_run:
        return {'dry_run': True, 'would_push': len(plan), 'would_create': created,
                'skipped': skipped, 'plan': plan}

    applied = 0
    apply_result = {}
    if ids:
        apply_result = client.apply_desired_routes(ids=ids, phase='full')
        applied = len(apply_result.get('applied') or ids)

    return {
        'pushed': len(ids), 'created': created, 'patched': patched, 'applied': applied,
        'skipped': skipped, 'ok': bool(apply_result.get('ok', True)),
    }


# ═══════════════════════════════════════════════════════════════
# 策略路由下发
# ═══════════════════════════════════════════════════════════════

def _push_policy_rules(pop, client, dry_run=True):
    rules = list(
        PolicyRoute.objects
        .filter(pop_point=pop, is_active=True)
        .select_related('lookup_table')
    )
    if not rules:
        return {'pushed': 0, 'created': 0, 'applied': 0, 'skipped': 0,
                'note': '无可下发的策略路由', 'plan': []}

    existing = client.list_policy_rules()
    index = {}
    for r in existing or []:
        if not isinstance(r, dict):
            continue
        key = (
            r.get('priority'),
            str(r.get('family') or 'inet'),
            str(r.get('from_cidr') or ''),
            str(r.get('to_cidr') or ''),
        )
        if r.get('id'):
            index[key] = r['id']

    ids = []
    plan = []
    created = skipped = 0
    skipped_reasons = {}
    for pr in rules:
        family = 'inet6' if _is_v6(pr.src_prefix, pr.dst_prefix) else 'inet'
        from_cidr = pr.src_prefix or ''
        to_cidr = pr.dst_prefix or ''
        fwmark = (pr.fwmark or '').strip()
        key = (pr.priority, family, from_cidr, to_cidr)
        node_id = index.get(key)
        table_id = pr.lookup_table.table_id if pr.lookup_table else None
        # 节点要求每条 ip rule 至少有一个匹配条件（from/to/fwmark/iif/oif）。
        # 无匹配条件的多为内核默认规则（from all lookup local/main/default，优先级 0/32766/32767），
        # 不应、也无法下发到节点（否则节点校验失败返回 500）。
        if not (from_cidr or to_cidr or fwmark):
            skipped += 1
            skipped_reasons.setdefault('无匹配条件(内核默认规则)', 0)
            skipped_reasons['无匹配条件(内核默认规则)'] += 1
            continue
        if pr.action == 'lookup' and not table_id:
            skipped += 1  # lookup 必须有查找表
            skipped_reasons.setdefault('lookup 缺少查找表', 0)
            skipped_reasons['lookup 缺少查找表'] += 1
            continue
        plan.append({'priority': pr.priority, 'family': family,
                     'from': from_cidr or 'all', 'to': to_cidr or 'all',
                     'action': pr.action, 'table': table_id,
                     'state': '复用' if node_id else '新建'})
        if node_id is None:
            if dry_run:
                created += 1
                continue
            payload = {
                'priority': pr.priority,
                'family': family,
                'from_cidr': from_cidr,
                'to_cidr': to_cidr,
                'fwmark': fwmark,
                'action': pr.action,
                'table_id': table_id,
                'enabled': True,
                'remark': 'ISPmanager 下发',
            }
            obj = client.create_policy_rule(payload)
            node_id = obj.get('id') if isinstance(obj, dict) else None
            if node_id:
                created += 1
        if node_id:
            ids.append(node_id)

    if dry_run:
        return {'dry_run': True, 'would_push': len(plan), 'would_create': created,
                'skipped': skipped, 'skipped_reasons': skipped_reasons, 'plan': plan}

    applied = 0
    apply_result = {}
    if ids:
        apply_result = client.apply_policy_rules(ids=ids, phase='full')
        applied = int(apply_result.get('added') or 0)

    return {
        'pushed': len(ids), 'created': created, 'applied': applied,
        'skipped': skipped, 'skipped_reasons': skipped_reasons,
        'ok': bool(apply_result.get('ok', True)),
    }


# ═══════════════════════════════════════════════════════════════
# 边缘隧道下发（GRE / WireGuard → desired-tunnels）
# ═══════════════════════════════════════════════════════════════

_IFNAME_PREFIX = {
    EdgeAcceleration.Protocol.WIREGUARD: 'wg',
    EdgeAcceleration.Protocol.GRE: 'gre',
    EdgeAcceleration.Protocol.VXLAN: 'vxlan',
}


def _edge_ifname(edge):
    """节点隧道接口名：优先用已回填的 node_ifname，否则按协议+主键生成（<=15 字符）。"""
    if edge.node_ifname:
        return edge.node_ifname[:15]
    prefix = _IFNAME_PREFIX.get(edge.protocol, 'tun')
    return f'{prefix}{edge.pk}'[:15]


def _split_csv(value):
    """把逗号/空白分隔的字符串拆成去空列表。"""
    if not value:
        return []
    return [s.strip() for s in re.split(r'[,\s]+', str(value)) if s.strip()]


def _maybe_int(value):
    """GRE key 等：数字字符串转 int，否则原样返回。"""
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return value


def _infer_p2p_peer_ip(address_cidr: str):
    """从 PtP addresses 推断对端 IP（与 ip_ops / vpop peer_ip 一致）。"""
    import ipaddress

    if not address_cidr:
        return None
    raw = str(address_cidr).strip()
    if '/' not in raw:
        raw = f'{raw}/32'
    try:
        iface = ipaddress.ip_interface(raw)
    except ValueError:
        return None
    net = iface.network
    local = iface.ip
    try:
        if net.prefixlen in (31, 127):
            cands = [net[0], net[1]]
        elif net.prefixlen in (30, 126):
            cands = list(net.hosts())
        else:
            return None
    except ValueError:
        return None
    for c in cands:
        if c != local:
            return str(c)
    return None


def _normalize_wg_peer_endpoint(endpoint: str, listen_port: int) -> str:
    """纯 IP 时补全 :listen_port，满足节点 wg-quick 校验。"""
    ep = (endpoint or '').strip()
    if not ep:
        return ''
    if ep.startswith('[') and ']:' in ep:
        return ep
    if ep.count(':') == 1:
        _, port_part = ep.rsplit(':', 1)
        if port_part.isdigit():
            return ep
    return f'{ep}:{listen_port or 51820}'


def _wg_peer_allowed_ips(interface_ip: str, explicit: str) -> list[str]:
    """PtP 未填 allowed_ips 时默认对端 /32；避免误用 0.0.0.0/0 或 /30 与本端冲突。"""
    parts = _split_csv(explicit)
    if parts:
        return parts
    addrs = _split_csv(interface_ip)
    if addrs:
        peer = _infer_p2p_peer_ip(addrs[0])
        if peer:
            return [f'{peer}/32']
    return ['0.0.0.0/0']


def _build_tunnel_spec(edge):
    """
    把 EdgeAcceleration 协议配置映射为节点 desired-tunnel spec，返回 (kind, spec) 或 None。
    spec 结构与 vpopmanager DesiredTunnelConfig 完全一致：以 spec.netplan_tunnel 为唯一配置源。
    """
    if edge.protocol == EdgeAcceleration.Protocol.WIREGUARD:
        wg = getattr(edge, 'wg_config', None)
        if wg is None:
            return None
        peer = {}
        if wg.peer_public_key:
            peer['public_key'] = wg.peer_public_key
            peer['allowed_ips'] = _wg_peer_allowed_ips(wg.interface_ip, wg.peer_allowed_ips)
            listen_port = wg.listen_port or 51820
            if wg.peer_endpoint:
                peer['endpoint'] = _normalize_wg_peer_endpoint(wg.peer_endpoint, listen_port)
            if wg.persistent_keepalive:
                peer['persistent_keepalive'] = wg.persistent_keepalive
            if wg.peer_preshared_key:
                peer['preshared_key'] = wg.peer_preshared_key
        netplan_tunnel = {
            'mode': 'wireguard',
            'addresses': _split_csv(wg.interface_ip),
            'keys': {'private': wg.private_key or '', 'public': wg.public_key or ''},
            'listen_port': wg.listen_port or 51820,
        }
        if wg.fwmark:
            netplan_tunnel['fwmark'] = wg.fwmark
        if wg.mtu:
            netplan_tunnel['mtu'] = wg.mtu
        if wg.dns:
            netplan_tunnel['dns'] = _split_csv(wg.dns)
        if peer:
            netplan_tunnel['peers'] = [peer]
        return 'wireguard', {'type': 'wireguard', 'netplan_tunnel': netplan_tunnel}

    if edge.protocol == EdgeAcceleration.Protocol.GRE:
        gre = getattr(edge, 'gre_config', None)
        if gre is None:
            return None
        netplan_tunnel = {
            'mode': 'gre',
            'local': gre.local_ip,
            'remote': gre.remote_ip,
            'addresses': [gre.tunnel_ip] if gre.tunnel_ip else [],
        }
        # ttl 为 netplan 版本相关的可选键（部分节点 netplan 不识别 'ttl'）；
        # 仅在显式配置时下发，避免无意义的默认值导致 netplan generate 失败。
        if gre.ttl:
            netplan_tunnel['ttl'] = gre.ttl
        if gre.key not in (None, ''):
            netplan_tunnel['key'] = _maybe_int(gre.key)
        return 'gre', {'type': 'gre', 'netplan_tunnel': netplan_tunnel}

    if edge.protocol == EdgeAcceleration.Protocol.VXLAN:
        vx = getattr(edge, 'vxlan_config', None)
        if vx is None:
            return None
        netplan_tunnel = {
            'mode': 'vxlan',
            'id': vx.vni,
            'addresses': [vx.tunnel_ip] if vx.tunnel_ip else [],
        }
        if vx.port:
            netplan_tunnel['port'] = vx.port
        if vx.ttl:
            netplan_tunnel['ttl'] = vx.ttl
        if vx.local_ip:
            netplan_tunnel['local'] = vx.local_ip
        if vx.remote_ip:
            netplan_tunnel['remote'] = vx.remote_ip
        return 'vxlan', {'type': 'vxlan', 'netplan_tunnel': netplan_tunnel}

    return None


# 接口类型 → 节点 apply-config kind
_IFACE_KIND_MAP = {
    'physical': 'ether',
    'vlan': 'vlan',
    'bond': 'bond',
    'bridge': 'bridge',
    'loopback': 'ether',
    'tunnel': 'gre',
    'dummy': 'ether',
}


def push_interface_to_node(pop, interface):
    """
    将 NetworkInterface.netplan_config 下发到节点（apply-config）。
    interface 需有 ifname 与 netplan_config={kind, spec}。
    """
    ifname = (interface.ifname or '').strip()
    cfg = interface.netplan_config if isinstance(interface.netplan_config, dict) else {}
    kind = cfg.get('kind') or _IFACE_KIND_MAP.get(interface.interface_type, 'ether')
    spec = cfg.get('spec') if isinstance(cfg.get('spec'), dict) else {}
    if not ifname:
        return {'ok': False, 'detail': '接口名为空'}
    if not spec and interface.interface_type not in ('tunnel',):
        return {'ok': False, 'detail': '未配置 netplan spec，无法下发'}

    base = pop.api_base_url or (f'http://{pop.mgmt_ip}' if pop.mgmt_ip else '')
    username = pop.api_username or pop.mgmt_username
    password = pop.api_password or pop.mgmt_password
    client = PemanagerClient(base, username, password)
    client.login()

    # 隧道类接口走 desired-tunnels（若 spec 含 netplan_tunnel）
    if kind in ('gre', 'vxlan', 'wireguard') or spec.get('netplan_tunnel'):
        tunnel_spec = spec.get('netplan_tunnel') or spec
        payload = {
            'ifname': ifname,
            'kind': kind if kind in ('gre', 'vxlan', 'wireguard') else 'gre',
            'spec': {'type': kind, 'netplan_tunnel': tunnel_spec},
            'remark': interface.description or 'ISPmanager 下发',
        }
        existing = client.list_desired_tunnels() or []
        node_id = None
        for t in existing:
            if isinstance(t, dict) and str(t.get('ifname')) == ifname:
                node_id = t.get('id')
                break
        if node_id:
            client.patch_desired_tunnel(node_id, payload)
        else:
            client.create_desired_tunnel(payload)
        apply_result = client.apply_desired_tunnels()
        ok = bool(apply_result.get('ok', True)) if isinstance(apply_result, dict) else True
        return {'ok': ok, 'detail': f'隧道 {ifname} 已下发', 'apply': apply_result}

    # 补齐 MTU
    if interface.mtu and 'mtu' not in spec:
        spec = {**spec, 'mtu': interface.mtu}
    result = client.apply_interface_config(ifname, kind, spec)
    ok = bool(result.get('ok', True)) if isinstance(result, dict) else True
    return {'ok': ok, 'detail': f'接口 {ifname} 配置已下发', 'apply': result}


def push_vps_bandwidth_to_node(vps):
    """将单台同步 VPS 的带宽下发到节点 VM 网卡（net0 rate）。"""
    if not vps.is_synced or not vps.source_ref:
        return {'ok': False, 'detail': '仅支持已同步且有关联节点 VM 的 VPS'}
    if not vps.bandwidth_mbps or vps.bandwidth_mbps <= 0:
        return {'ok': False, 'detail': '带宽必须大于 0'}
    pop = vps.pop_point
    if pop is None:
        return {'ok': False, 'detail': 'VPS 未关联 POP 点'}

    base = pop.api_base_url or (f'http://{pop.mgmt_ip}' if pop.mgmt_ip else '')
    username = pop.api_username or pop.mgmt_username
    password = pop.api_password or pop.mgmt_password
    client = PemanagerClient(base, username, password)
    client.login()

    pool_name = _resolve_pool_name(pop, client, dry_run=False)
    payload = {
        'pool_name': pool_name,
        'vm_id': vps.source_ref,
        'net_index': 0,
        'allocated_mbps': vps.bandwidth_mbps,
        'remark': f'ISPmanager 下发 {vps.name}',
    }
    cust_code = _customer_code(vps.customer)
    if cust_code:
        payload['customer_code'] = cust_code
    result = client.allocate_vm_bandwidth(payload)
    ok = bool(result.get('ok', True)) if isinstance(result, dict) else True
    return {'ok': ok, 'detail': f'VPS {vps.name} 带宽 {vps.bandwidth_mbps}Mbps 已下发', 'result': result}


def delete_interface_on_node(pop, ifname, interface_type):
    """
    把 ISPmanager 中删除接口的操作传播到节点。
    - 隧道接口（gre/vxlan/wireguard/tunnel）：按 ifname 找到 desired-tunnel 并删除，
      再全量 apply-system，使节点 netplan 拆除该隧道（GRE/VXLAN 生效；WireGuard 为尽力而为）。
    - 普通接口（physical/vlan/bridge 等）：删除节点为其托管的 netplan 片段（remove-config）。
    返回 {ok, detail}；调用方负责异常处理。
    """
    base = pop.api_base_url or (f'http://{pop.mgmt_ip}' if pop.mgmt_ip else '')
    username = pop.api_username or pop.mgmt_username
    password = pop.api_password or pop.mgmt_password
    client = PemanagerClient(base, username, password)
    client.login()

    ifname = (ifname or '').strip()
    if not ifname:
        return {'ok': False, 'detail': '接口名为空，无法在节点删除'}

    tunnel_kinds = {'gre', 'vxlan', 'wireguard', 'tunnel'}
    if interface_type in tunnel_kinds:
        existing = client.list_desired_tunnels() or []
        tid = None
        for t in existing:
            if isinstance(t, dict) and str(t.get('ifname')) == ifname:
                tid = t.get('id')
                break
        if tid is None:
            return {'ok': True, 'detail': f'节点无对应隧道意图 {ifname}，无需删除'}
        client.delete_desired_tunnel(tid)
        # 必须全量 apply-system（{}），GRE/VXLAN 才会从 netplan 拆除
        client.apply_desired_tunnels()
        return {'ok': True, 'detail': f'已删除节点隧道 {ifname} 并重建 netplan'}

    # 普通接口：删除 pemanager 托管的 netplan 片段
    client.remove_interface_config(ifname)
    return {'ok': True, 'detail': f'已删除节点接口配置 {ifname}'}


def _push_edge_tunnels(pop, client, dry_run=True):
    edges = list(
        EdgeAcceleration.objects
        .filter(pop_point=pop)
        .select_related('gre_config', 'vxlan_config', 'wg_config', 'customer')
    )
    if not edges:
        return {'pushed': 0, 'created': 0, 'applied': 0, 'skipped': 0,
                'note': '无边缘加速节点', 'plan': []}

    existing = client.list_desired_tunnels()
    index = {}
    for t in existing or []:
        if isinstance(t, dict) and t.get('ifname') and t.get('id'):
            index[str(t['ifname'])] = t['id']

    ids = []
    plan = []
    applied_edges = []      # [(edge, ifname)]
    created = skipped = 0
    socks5 = 0
    for edge in edges:
        if edge.protocol == EdgeAcceleration.Protocol.SOCKS5:
            socks5 += 1
            skipped += 1
            continue
        built = _build_tunnel_spec(edge)
        if built is None:
            skipped += 1  # 缺少协议配置
            continue
        kind, spec = built
        ifname = _edge_ifname(edge)
        node_id = index.get(ifname)
        plan.append({'edge_no': edge.edge_no, 'name': edge.name,
                     'protocol': edge.protocol, 'ifname': ifname,
                     'state': '更新' if node_id else '新建'})
        if dry_run:
            created += int(node_id is None)
            applied_edges.append((edge, ifname))
            continue

        payload = {
            'ifname': ifname,
            'kind': kind,
            'spec': spec,
            'remark': f'ISPmanager 边缘加速 {edge.edge_no}',
        }
        cust_code = _customer_code(edge.customer)
        if cust_code:
            payload['customer'] = cust_code  # 节点按 code 绑定 ResourceCustomer
        if node_id:
            client.patch_desired_tunnel(node_id, payload)
        else:
            obj = client.create_desired_tunnel(payload)
            node_id = obj.get('id') if isinstance(obj, dict) else None
            if node_id:
                created += 1
        if node_id:
            ids.append(node_id)
            applied_edges.append((edge, ifname))

    if dry_run:
        return {'dry_run': True, 'would_push': len(plan), 'would_create': created,
                'skipped': skipped, 'socks5_skipped': socks5, 'plan': plan}

    apply_result = {}
    if ids:
        apply_result = client.apply_desired_tunnels(ids=ids)

    # 回填下发状态 + 同步隧道接口带宽（interface_code = ifname，对齐 vpopmanager）
    now = timezone.now()
    bw_pool = None
    bw_pushed = 0
    for edge, ifname in applied_edges:
        edge.node_pushed = True
        edge.is_synced = True  # 兼容别名
        edge.node_ifname = ifname
        edge.last_synced_at = now
        edge.save(update_fields=['node_pushed', 'is_synced', 'node_ifname',
                                 'last_synced_at', 'updated_at'])
        if edge.bandwidth_mbps and edge.bandwidth_mbps > 0:
            if bw_pool is None:
                bw_pool = _resolve_pool_name(pop, client, dry_run=False)
            try:
                bw_payload = {
                    'pool_name': bw_pool,
                    'interface_code': ifname,
                    'allocated_mbps': edge.bandwidth_mbps,
                    'remark': f'ISPmanager 边缘加速 {edge.edge_no}',
                }
                _edge_cust = _customer_code(edge.customer)
                if _edge_cust:
                    bw_payload['customer_code'] = _edge_cust
                client.upsert_bandwidth_allocation(bw_payload)
                bw_pushed += 1
            except Exception:  # noqa: BLE001  带宽下发失败不阻断隧道下发
                pass

    return {
        'pushed': len(ids), 'created': created, 'applied': len(ids),
        'skipped': skipped, 'socks5_skipped': socks5, 'bandwidth_pushed': bw_pushed,
        'ok': bool(apply_result.get('ok', True)) if isinstance(apply_result, dict) else True,
    }


# ═══════════════════════════════════════════════════════════════
# 带宽限速下发（VPS 带宽 → 节点 VM 网卡 rate）
# ═══════════════════════════════════════════════════════════════

def _resolve_pool_name(pop, client, dry_run):
    """选择节点带宽池：复用已有的第一个；dry_run 不创建，实际执行时按需创建。"""
    pools = client.list_bandwidth_pools()
    if pools:
        for p in pools:
            if isinstance(p, dict) and p.get('name'):
                return p['name']
    if dry_run:
        return 'ispmanager'
    total = pop.total_bandwidth_mbps or 10000
    client.create_bandwidth_pool({'name': 'ispmanager', 'total_mbps': total,
                                  'remark': 'ISPmanager 自动创建'})
    return 'ispmanager'


def _push_bandwidth(pop, client, dry_run=True):
    """把同步虚机的带宽限速下发到节点 VM 网卡（net0 rate）。"""
    vps_list = list(
        VPS.objects
        .filter(pop_point=pop, is_synced=True)
        .exclude(source_ref='')
        .filter(bandwidth_mbps__gt=0)
        .select_related('customer')
    )
    if not vps_list:
        return {'pushed': 0, 'skipped': 0, 'note': '无可下发带宽的同步虚机', 'plan': []}

    pool_name = _resolve_pool_name(pop, client, dry_run)
    plan = []
    pushed = failed = 0
    errors = []
    for vps in vps_list:
        plan.append({'vps': vps.name, 'vm_id': vps.source_ref,
                     'net_index': 0, 'mbps': vps.bandwidth_mbps})
        if dry_run:
            continue
        try:
            vm_bw_payload = {
                'pool_name': pool_name,
                'vm_id': vps.source_ref,
                'net_index': 0,
                'allocated_mbps': vps.bandwidth_mbps,
                'remark': f'ISPmanager 下发 {vps.name}',
            }
            _vps_cust = _customer_code(vps.customer)
            if _vps_cust:
                vm_bw_payload['customer_code'] = _vps_cust
            client.allocate_vm_bandwidth(vm_bw_payload)
            pushed += 1
        except PemanagerError as e:
            failed += 1
            errors.append(f'{vps.name}: {e}')

    if dry_run:
        return {'dry_run': True, 'would_push': len(plan),
                'pool_name': pool_name, 'plan': plan}

    return {'pushed': pushed, 'failed': failed, 'pool_name': pool_name,
            'errors': errors, 'ok': not failed}


# ═══════════════════════════════════════════════════════════════
# 客户信息下发（ISPmanager Customer → 节点 ResourceCustomer，按 code 对齐）
# ═══════════════════════════════════════════════════════════════

def _customer_code(customer):
    """节点 ResourceCustomer.code 采用 ISPmanager 的 customer_no（唯一、slug 安全）。"""
    return customer.customer_no if customer else None


def _collect_pop_customers(pop):
    """汇总该 POP 下资源（VPS / 边缘加速）关联的客户，去重。"""
    seen = {}
    for vps in VPS.objects.filter(pop_point=pop).select_related('customer'):
        if vps.customer_id and vps.customer:
            seen[vps.customer_id] = vps.customer
    for edge in EdgeAcceleration.objects.filter(pop_point=pop).select_related('customer'):
        if edge.customer_id and edge.customer:
            seen[edge.customer_id] = edge.customer
    return list(seen.values())


def _push_customers(pop, client, dry_run=True):
    """把该 POP 下资源关联的客户主数据下发到节点（upsert by code=customer_no）。"""
    customers = _collect_pop_customers(pop)
    if not customers:
        return {'pushed': 0, 'created': 0, 'updated': 0, 'note': '无关联客户', 'plan': []}

    existing = client.customers() or []
    by_code = {str(c.get('code')): c for c in existing if isinstance(c, dict) and c.get('code')}

    plan = []
    created = updated = 0
    for cust in customers:
        code = _customer_code(cust)
        if not code:
            continue
        node_c = by_code.get(code)
        is_active = cust.status == 'active'
        plan.append({'code': code, 'name': cust.name,
                     'state': '更新' if node_c else '新建'})
        if dry_run:
            created += int(node_c is None)
            updated += int(node_c is not None)
            continue
        payload = {'code': code, 'name': cust.name,
                   'remark': f'ISPmanager 同步 {cust.customer_no}', 'is_active': is_active}
        try:
            if node_c:
                client.update_customer(node_c.get('id'), payload)
                updated += 1
            else:
                client.create_customer(payload)
                created += 1
        except PemanagerError:
            # 客户已存在（并发）或校验失败时忽略，不阻断后续下发
            pass

    if dry_run:
        return {'dry_run': True, 'would_create': created, 'would_update': updated, 'plan': plan}
    return {'pushed': created + updated, 'created': created, 'updated': updated, 'ok': True}


# ═══════════════════════════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════════════════════════

_SECTION_HANDLERS = {
    'customers': _push_customers,
    'static_routes': _push_static_routes,
    'policy_rules': _push_policy_rules,
    'edge_tunnels': _push_edge_tunnels,
    'bandwidth': _push_bandwidth,
}


def push_pop_to_node(pop: PopPoint, sections=None, dry_run=True):
    """
    把 POP 点配置下发到节点。sections 为待下发区块列表，缺省下发全部。
    dry_run=True 仅返回下发计划，不实际写节点。
    返回 {ok, dry_run, node_user, summary, errors}。
    """
    base = pop.api_base_url or (f'http://{pop.mgmt_ip}' if pop.mgmt_ip else '')
    username = pop.api_username or pop.mgmt_username
    password = pop.api_password or pop.mgmt_password
    client = PemanagerClient(base, username, password)
    user = client.login()

    if not sections:
        sections = list(_SECTION_HANDLERS.keys())

    summary = {}
    errors = {}
    for sec in sections:
        handler = _SECTION_HANDLERS.get(sec)
        if handler is None:
            errors[sec] = '不支持的下发区块'
            continue
        try:
            summary[sec] = handler(pop, client, dry_run=dry_run)
        except PemanagerError as e:
            errors[sec] = str(e)
        except Exception as e:  # noqa: BLE001
            errors[sec] = f'下发异常：{e}'

    # 实际下发（非 dry-run）且全部成功时，清除「待下发」标记
    if not dry_run and not errors:
        from django.utils import timezone
        PopPoint.objects.filter(pk=pop.pk).update(
            config_dirty=False, last_push_at=timezone.now())

    return {'ok': not errors, 'dry_run': dry_run, 'node_user': user,
            'summary': summary, 'errors': errors}
