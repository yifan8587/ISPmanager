"""
PE Manager 节点 API 客户端（依据 deploy/API.md）。

部署完成后，POP 节点上运行 pemanager 面板，对外暴露统一 REST API。
本客户端用节点的 API 基址 + 账号登录获取 JWT，然后拉取接口 / 路由 / 策略 /
IP / 带宽等系统现场数据，供 ISPmanager 同步入库。

注意（各端点的真实返回结构，参考 pemanager 后端源码）：
  - GET /api/interfacemanage/interfaces/      → { summary, count, interfaces: [...], sources }
  - GET /api/routemanage/system-routes/?table=all → { ok, table, routes: [...] }
  - GET /api/routemanage/system-rules/        → { ok, rules: [...] }
  - GET /api/resourcemanage/ip-addresses/     → [ ... ]（无分页，纯数组）
  - GET /api/resourcemanage/bandwidth-allocations/ → [ ... ]
  - GET /api/resourcemanage/customers/        → [ ... ]
  - GET /api/resourcemanage/bandwidth-pools/  → [ ... ]

因此不能简单地把响应当成列表使用，必须按 key 解包。早期实现遗漏了这点，
导致接口 / 路由 / 策略路由实际从未同步成功。
"""

import requests


class PemanagerError(Exception):
    pass


class PemanagerClient:
    def __init__(self, base_url, username, password, timeout=20, verify=False):
        if not base_url:
            raise PemanagerError('节点 API 基址为空')
        self.base = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.timeout = timeout
        self.verify = verify
        self.session = requests.Session()
        self._token = None

    # ── 鉴权 ──────────────────────────────────────────────────
    def login(self):
        url = f'{self.base}/api/accountmanage/auth/login/'
        try:
            r = self.session.post(
                url, json={'username': self.username, 'password': self.password},
                timeout=self.timeout, verify=self.verify,
            )
        except requests.RequestException as e:
            raise PemanagerError(f'连接节点失败（{self.base}）：{e}')
        if r.status_code != 200:
            raise PemanagerError(f'节点登录失败（HTTP {r.status_code}）：{r.text[:200]}')
        data = r.json()
        self._token = data.get('access')
        if not self._token:
            raise PemanagerError('节点登录未返回 access token')
        self.session.headers['Authorization'] = f'Bearer {self._token}'
        return data.get('user') or {}

    # ── 通用 GET ──────────────────────────────────────────────
    def _get_raw(self, path, params=None):
        """返回原始 JSON（dict 或 list），404 → None。"""
        url = f'{self.base}{path}'
        try:
            r = self.session.get(url, params=params, timeout=self.timeout, verify=self.verify)
        except requests.RequestException as e:
            raise PemanagerError(f'请求 {path} 失败：{e}')
        if r.status_code == 404:
            return None
        if r.status_code == 403:
            raise PemanagerError(f'请求 {path} 无权限（HTTP 403），请使用管理员账号同步')
        if r.status_code != 200:
            raise PemanagerError(f'请求 {path} 失败（HTTP {r.status_code}）')
        try:
            return r.json()
        except ValueError:
            return None

    def _get_list(self, path, params=None, key=None):
        """
        统一把响应解包成 list：
          - 若响应是 list，直接返回
          - 若是分页 dict（含 results），返回 results
          - 若指定 key 且响应是 dict，返回 data[key]
        """
        data = self._get_raw(path, params=params)
        if data is None:
            return []
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            if key and isinstance(data.get(key), list):
                return data[key]
            if isinstance(data.get('results'), list):
                return data['results']
        return []

    # ── 健康检查 ──────────────────────────────────────────────
    def health(self):
        return self._get_raw('/api/accountmanage/health/')

    # ── 接口管理 ──────────────────────────────────────────────
    def interfaces(self):
        """系统现场接口（kernel + netplan + wg 合并），返回接口数组。"""
        return self._get_list('/api/interfacemanage/interfaces/', key='interfaces')

    # ── 路由管理 ──────────────────────────────────────────────
    def system_routes(self, table='all'):
        """
        内核路由表。默认 table=all 抓取所有路由表（含 main/local/自定义表），
        每条 route 带有 `table` 字段，便于按表归类。
        """
        params = {'table': table} if table else None
        return self._get_list('/api/routemanage/system-routes/', params=params, key='routes')

    def system_rules(self):
        """内核 ip rule 策略路由，返回 rules 数组。"""
        return self._get_list('/api/routemanage/system-rules/', key='rules')

    # ── 资源管理 ──────────────────────────────────────────────
    def ip_addresses(self):
        """受管 IP 资源（含 state/customer/subnet_label）。"""
        return self._get_list('/api/resourcemanage/ip-addresses/')

    def bulk_create_ips(self, payload):
        return self._post('/api/resourcemanage/ip-addresses/actions/bulk-create/', payload)

    def allocate_ip(self, payload):
        return self._post('/api/resourcemanage/ip-addresses/actions/allocate/', payload)

    def allocate_ip_with_route(self, payload):
        return self._post('/api/resourcemanage/ip-addresses/actions/allocate-with-route/', payload)

    def release_ip(self, payload):
        return self._post('/api/resourcemanage/ip-addresses/actions/release/', payload)

    def reserve_ip(self, payload):
        return self._post('/api/resourcemanage/ip-addresses/actions/reserve/', payload)

    def delete_desired_route(self, route_id):
        return self._delete(f'/api/routemanage/desired-routes/{route_id}/')

    def bandwidth_allocations(self):
        return self._get_list('/api/resourcemanage/bandwidth-allocations/')

    def bandwidth_pools(self):
        return self._get_list('/api/resourcemanage/bandwidth-pools/')

    def customers(self):
        return self._get_list('/api/resourcemanage/customers/')

    def create_customer(self, payload):
        return self._post('/api/resourcemanage/customers/', payload)

    def update_customer(self, customer_id, payload):
        return self._patch(f'/api/resourcemanage/customers/{customer_id}/', payload)

    # ── PVE 虚机（vpopmanager 专有，pemanager 无此模块则 404 → []） ──
    def vms(self):
        """PVE 虚拟机列表（pvemanager）。节点无该模块时返回空列表。"""
        return self._get_list('/api/pvemanager/vms/')

    # ── 通用 POST（下发 / 写操作） ────────────────────────────
    def _post(self, path, payload=None):
        return self._write('post', path, payload)

    def _patch(self, path, payload=None):
        return self._write('patch', path, payload)

    def _delete(self, path):
        return self._write('delete', path, None)

    def _write(self, method, path, payload):
        url = f'{self.base}{path}'
        fn = getattr(self.session, method)
        try:
            if method == 'delete':
                r = fn(url, timeout=self.timeout, verify=self.verify)
            else:
                r = fn(url, json=payload or {}, timeout=self.timeout, verify=self.verify)
        except requests.RequestException as e:
            raise PemanagerError(f'请求 {path} 失败：{e}')
        if r.status_code == 403:
            raise PemanagerError(f'操作 {path} 无权限（HTTP 403），请使用管理员账号')
        if r.status_code == 204:
            return {}
        try:
            data = r.json()
        except ValueError:
            data = {}
        if r.status_code not in (200, 201, 202):
            detail = ''
            if isinstance(data, dict):
                detail = data.get('error') or data.get('detail') or str(data)[:200]
                # apply-system 等带 steps 的接口：附带失败步骤的 stderr，便于定位
                # （例如某条隧道含节点 netplan 不支持的键时，会拖累整体 netplan generate）
                steps = data.get('steps')
                if isinstance(steps, list):
                    for s in steps:
                        if isinstance(s, dict) and s.get('ok') is False and s.get('stderr'):
                            detail = f"{detail}；{str(s.get('stderr')).strip()[:300]}"
                            break
            raise PemanagerError(f'操作 {path} 失败（HTTP {r.status_code}）：{detail}')
        return data

    # ── 静态路由意图（下发） ──────────────────────────────────
    def list_desired_routes(self):
        return self._get_list('/api/routemanage/desired-routes/')

    def create_desired_route(self, payload):
        return self._post('/api/routemanage/desired-routes/', payload)

    def patch_desired_route(self, route_id, payload):
        return self._patch(f'/api/routemanage/desired-routes/{route_id}/', payload)

    def apply_desired_routes(self, ids=None, phase='full', persist_to_netplan=False):
        body = {'phase': phase}
        if ids is not None:
            body['ids'] = ids
            if persist_to_netplan:
                body['persist_to_netplan'] = True
        return self._post('/api/routemanage/desired-routes/apply-system/', body)

    def apply_wireguard_routes(self, ids=None):
        """WireGuard 路由：写入 wg conf PostUp/PostDown 并 wg-quick down/up。"""
        body = {}
        if ids is not None:
            body['ids'] = ids
        return self._post('/api/routemanage/desired-routes/apply-wireguard/', body)

    # ── 策略路由意图（下发） ──────────────────────────────────
    def list_policy_rules(self):
        return self._get_list('/api/routemanage/policy-rules/')

    def create_policy_rule(self, payload):
        return self._post('/api/routemanage/policy-rules/', payload)

    def apply_policy_rules(self, ids=None, phase='full'):
        body = {'phase': phase}
        if ids is not None:
            body['ids'] = ids
        return self._post('/api/routemanage/policy-rules/apply-system/', body)

    # ── 隧道意图（边缘加速下发 → desired-tunnels） ─────────────
    def list_desired_tunnels(self):
        return self._get_list('/api/interfacemanage/db/desired-tunnels/')

    def create_desired_tunnel(self, payload):
        return self._post('/api/interfacemanage/db/desired-tunnels/', payload)

    def patch_desired_tunnel(self, tunnel_id, payload):
        return self._patch(f'/api/interfacemanage/db/desired-tunnels/{tunnel_id}/', payload)

    def delete_desired_tunnel(self, tunnel_id):
        return self._delete(f'/api/interfacemanage/db/desired-tunnels/{tunnel_id}/')

    def remove_interface_config(self, ifname):
        """删除节点为该接口托管的 netplan 片段（apply-config 创建的普通接口）。"""
        return self._post(f'/api/interfacemanage/interfaces/{ifname}/remove-config/', {})

    def apply_interface_config(self, ifname, kind, spec):
        """写入单接口 netplan 片段并 netplan generate + try（对齐 vpop apply-config）。"""
        return self._post(
            f'/api/interfacemanage/interfaces/{ifname}/apply-config/',
            {'kind': kind, 'spec': spec or {}},
        )

    def apply_desired_tunnels(self, ids=None):
        body = {}
        if ids is not None:
            body['ids'] = ids
        return self._post('/api/interfacemanage/db/desired-tunnels/apply-system/', body)

    def wg_genkey(self):
        return self._post('/api/interfacemanage/tools/wg/genkey/', {})

    def wg_pubkey(self, private_key):
        return self._post('/api/interfacemanage/tools/wg/pubkey/', {'private': private_key})

    # ── 带宽（池 + 分配） ─────────────────────────────────────
    def list_bandwidth_pools(self):
        return self._get_list('/api/resourcemanage/bandwidth-pools/')

    def create_bandwidth_pool(self, payload):
        return self._post('/api/resourcemanage/bandwidth-pools/', payload)

    def upsert_bandwidth_allocation(self, payload):
        return self._post('/api/resourcemanage/bandwidth-allocations/actions/upsert/', payload)

    def delete_bandwidth_allocation(self, payload):
        return self._post('/api/resourcemanage/bandwidth-allocations/actions/delete-by-key/', payload)

    def allocate_vm_bandwidth(self, payload):
        return self._post('/api/pvemanager/vms/allocate_bandwidth/', payload)

    # ── PVE 虚机生命周期（vpopmanager pvemanager） ────────────
    def list_pve_hosts(self):
        return self._get_list('/api/pvemanager/hosts/')

    def list_nodes(self, host_id):
        # 节点 list_nodes 端点返回 {success, nodes:[...], default}，需按 nodes 解包
        return self._get_list('/api/pvemanager/vms/list_nodes/',
                              params={'host_id': host_id}, key='nodes')

    def list_templates(self):
        return self._get_list('/api/pvemanager/templates/')

    def host_storages(self, host_id, node=None):
        params = {'node': node} if node else None
        return self._get_list(f'/api/pvemanager/hosts/{host_id}/storages/', params=params)

    def vm_detail(self, vm_pk):
        return self._get_raw(f'/api/pvemanager/vms/{vm_pk}/detail/')

    def sync_vms(self):
        return self._post('/api/pvemanager/vms/sync/', {})

    def vm_action(self, vm_pk, action, payload=None):
        """action ∈ start/stop/restart/shutdown"""
        return self._post(f'/api/pvemanager/vms/{vm_pk}/{action}/', payload or {})

    def create_vm(self, payload):
        return self._post('/api/pvemanager/vms/create_vm/', payload)

    def create_vm_from_template(self, payload):
        return self._post('/api/pvemanager/vms/create_from_template/', payload)

    def clone_vm(self, vm_pk, payload):
        return self._post(f'/api/pvemanager/vms/{vm_pk}/clone/', payload)

    def delete_vm(self, vm_pk):
        return self._delete(f'/api/pvemanager/vms/{vm_pk}/')

    def vnc_ticket(self, vm_pk):
        """获取节点 PVE 虚机的 VNC 票据（触发节点上的 vncproxy，30 秒内须建立 WS）。"""
        return self._get_raw(f'/api/pvemanager/vms/{vm_pk}/vnc_ticket/')

    # ── WebSocket 中继辅助 ────────────────────────────────────
    @property
    def token(self):
        """节点登录后获得的 JWT access token（用于节点 WebSocket 鉴权）。"""
        return self._token

    def node_vnc_ws_url(self, vm_pk, vncticket=None, port=None):
        """
        构造节点 noVNC WebSocket 地址：
          wss://<节点host>/ws/pvemanager/vnc/<vm_pk>/?token=<节点JWT>&vncticket=...&port=...
        节点已把 /ws/pvemanager/vnc/ 暴露在与 API 同一 host 上。
        """
        from urllib.parse import urlsplit, urlencode
        parts = urlsplit(self.base)
        scheme = 'wss' if parts.scheme == 'https' else 'ws'
        netloc = parts.netloc or parts.path  # base 形如 http://host:port
        qs = {'token': self._token or ''}
        if vncticket:
            qs['vncticket'] = vncticket
        if port is not None:
            qs['port'] = str(port)
        return f'{scheme}://{netloc}/ws/pvemanager/vnc/{vm_pk}/?{urlencode(qs)}'
