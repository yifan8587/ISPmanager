"""
noVNC 远程控制台中继消费者。

ISPmanager 不直接连接 PVE，而是经由 POP/PE 节点的 vpopmanager 暴露的 noVNC
WebSocket（节点再代理到 Proxmox vncwebsocket）。本消费者把浏览器的 noVNC 流量
中继到节点 WebSocket，实现「浏览器 ↔ ISPmanager ↔ 节点 ↔ PVE」的链路：

  浏览器 RFB ──ws/resource/vnc/<vps_id>/?token=<ISP JWT>&vncticket=&port=──▶ 本消费者
  本消费者 ──wss://<节点host>/ws/pvemanager/vnc/<source_ref>/?token=<节点 JWT>&...──▶ 节点
  节点 ──wss://<pve>/api2/json/.../vncwebsocket──▶ Proxmox

票据流程（与 vpopmanager 一致，避免重复调用 vncproxy 使票据失效）：
  前端先调 REST /vps/{id}/vnc_ticket/ 取得 ticket/port/password（仅调用一次 vncproxy），
  随后立即用 ticket/port 建立本 WebSocket；本消费者把 ticket/port 原样透传给节点，
  节点不会再次调用 vncproxy。
"""

import asyncio
import logging
import ssl
from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer

logger = logging.getLogger(__name__)

try:
    import websockets
except ImportError:  # pragma: no cover
    websockets = None


class VPSVNCConsumer(AsyncWebsocketConsumer):
    """路径: ws/resource/vnc/<vps_id>/?token=<JWT>&vncticket=<t>&port=<p>"""

    node_ws = None

    async def connect(self):
        if websockets is None:
            await self.close(code=4401)
            return

        user = self.scope.get('user')
        if not user or not getattr(user, 'is_authenticated', False):
            await self.close(code=4401)
            return

        self.vps_id = self.scope['url_route']['kwargs']['vps_id']
        vps = await self._get_vps(self.vps_id)
        if vps is None:
            await self.close(code=4404)
            return
        if not vps['source_ref']:
            # 非同步虚机或缺少节点主键，无法定位节点 VM
            await self.close(code=4400)
            return

        qs = parse_qs(self.scope.get('query_string', b'').decode())
        vncticket = (qs.get('vncticket') or [None])[0]
        port = (qs.get('port') or [None])[0]

        # 登录节点拿 JWT，并构造节点 noVNC WebSocket 地址（透传 ticket/port）
        try:
            node_url = await asyncio.to_thread(self._build_node_ws_url, vps, vncticket, port)
        except Exception as e:  # noqa: BLE001
            logger.error('build node vnc ws url failed: %s', e)
            await self.close(code=4500)
            return

        ssl_ctx = None
        if node_url.startswith('wss://'):
            ssl_ctx = ssl.create_default_context()
            ssl_ctx.check_hostname = False
            ssl_ctx.verify_mode = ssl.CERT_NONE

        connect_kwargs = dict(subprotocols=['binary'], max_size=None)
        if ssl_ctx is not None:
            connect_kwargs['ssl'] = ssl_ctx
        try:
            self.node_ws = await websockets.connect(node_url, **connect_kwargs)
        except Exception as e:  # noqa: BLE001
            logger.error('connect node vnc ws failed: %s url=%s', e, node_url)
            await self.close(code=4502)
            return

        # 回选 noVNC 要求的 'binary' 子协议
        chosen = 'binary' if 'binary' in self._client_subprotocols() else None
        await self.accept(subprotocol=chosen)
        self._relay_task = asyncio.create_task(self._relay_from_node())

    def _client_subprotocols(self):
        headers = dict(self.scope.get('headers') or [])
        raw = headers.get(b'sec-websocket-protocol', b'').decode()
        return [p.strip() for p in raw.split(',') if p.strip()]

    @staticmethod
    def _build_node_ws_url(vps, vncticket, port):
        from .pemanager_client import PemanagerClient
        base = vps['api_base_url'] or (f'http://{vps["mgmt_ip"]}' if vps['mgmt_ip'] else '')
        client = PemanagerClient(base, vps['api_username'], vps['api_password'])
        client.login()
        return client.node_vnc_ws_url(vps['source_ref'], vncticket=vncticket, port=port)

    @staticmethod
    @database_sync_to_async
    def _get_vps(vps_id):
        from .models import VPS
        try:
            vps = VPS.objects.select_related('pop_point').get(pk=vps_id)
        except VPS.DoesNotExist:
            return None
        pop = vps.pop_point
        return {
            'source_ref': vps.source_ref or '',
            'api_base_url': pop.api_base_url or '',
            'mgmt_ip': pop.mgmt_ip or '',
            'api_username': pop.api_username or pop.mgmt_username or '',
            'api_password': pop.api_password or pop.mgmt_password or '',
        }

    async def _relay_from_node(self):
        try:
            async for message in self.node_ws:
                if isinstance(message, bytes):
                    await self.send(bytes_data=message)
                else:
                    await self.send(text_data=message)
        except Exception as e:  # noqa: BLE001
            logger.debug('node vnc relay end: %s', e)
        finally:
            await self.close()

    async def receive(self, text_data=None, bytes_data=None):
        if not self.node_ws:
            return
        try:
            if bytes_data is not None:
                await self.node_ws.send(bytes_data)
            elif text_data is not None:
                await self.node_ws.send(text_data)
        except Exception as e:  # noqa: BLE001
            logger.warning('send to node vnc: %s', e)
            await self.close()

    async def disconnect(self, code):
        if getattr(self, '_relay_task', None):
            self._relay_task.cancel()
        if self.node_ws:
            try:
                await self.node_ws.close()
            except Exception:  # noqa: BLE001
                pass
