"""
Channels WebSocket JWT 鉴权中间件。

浏览器 WebSocket 无法自定义请求头，故 access token 通过 query string 传入：
    ws://host/ws/resource/pop-ssh/<pop_id>/?token=<JWT access>

校验通过后把 user 注入 scope；失败则注入 AnonymousUser，由消费者拒绝连接。
"""

from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from channels.middleware import BaseMiddleware
from django.contrib.auth.models import AnonymousUser


@database_sync_to_async
def _get_user(validated_token):
    from rest_framework_simplejwt.authentication import JWTAuthentication
    auth = JWTAuthentication()
    try:
        return auth.get_user(validated_token)
    except Exception:
        return AnonymousUser()


class JWTAuthMiddleware(BaseMiddleware):
    async def __call__(self, scope, receive, send):
        from rest_framework_simplejwt.tokens import AccessToken
        from rest_framework_simplejwt.exceptions import TokenError

        query = parse_qs(scope.get('query_string', b'').decode())
        token = (query.get('token') or [None])[0]

        user = AnonymousUser()
        if token:
            try:
                validated = AccessToken(token)
                user = await _get_user(validated)
            except TokenError:
                user = AnonymousUser()
            except Exception:
                user = AnonymousUser()

        scope['user'] = user
        return await super().__call__(scope, receive, send)
