"""
service_manager/models.py
服务管理模块 — 连接客户管理与资源管理的业务层

模型层次：
  ServicePlan         服务套餐/产品目录
  ServiceOrder        服务工单（客户需求）
  ServiceInstance     服务实例（已分配的具体资源）
  ServiceAllocation   资源分配/回收明细记录
  ServiceChangeRecord 服务变更申请与记录
  ServiceOperationLog 服务模块统一操作日志

核心联动：
  - ServiceInstance.activate()   → 更新关联资源 customer / status
  - ServiceInstance.suspend()    → 冻结资源
  - ServiceInstance.terminate()  → 释放资源，IP 回收，带宽归还
  - Django signals post_save     → 自动同步资源状态
"""

import datetime
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone


# ═══════════════════════════════════════════════════════════════
# § 1  服务套餐（产品目录）
# ═══════════════════════════════════════════════════════════════

class ServicePlan(models.Model):
    """服务套餐/产品定义"""

    class PlanType(models.TextChoices):
        VPS = 'vps', 'VPS 主机'
        EDGE_GRE = 'edge_gre', '边缘加速(GRE)'
        EDGE_WG = 'edge_wg', '边缘加速(WireGuard)'
        EDGE_SOCKS5 = 'edge_socks5', '边缘加速(Socks5)'
        IP_NATIVE = 'ip_native', '原生IP'
        IP_BROADCAST = 'ip_broadcast', '广播IP'
        BANDWIDTH = 'bandwidth', '带宽'
        COMBO = 'combo', '组合套餐'

    class BillingCycle(models.TextChoices):
        MONTHLY = 'monthly', '按月'
        QUARTERLY = 'quarterly', '按季'
        SEMI_ANNUAL = 'semi_annual', '半年'
        ANNUAL = 'annual', '按年'
        ONE_TIME = 'one_time', '一次性'
        ON_DEMAND = 'on_demand', '按需'

    name = models.CharField('套餐名称', max_length=128)
    plan_no = models.CharField('套餐编号', max_length=32, unique=True, editable=False)
    plan_type = models.CharField('套餐类型', max_length=20, choices=PlanType.choices)
    billing_cycle = models.CharField(
        '计费周期', max_length=16,
        choices=BillingCycle.choices, default=BillingCycle.MONTHLY,
    )
    price = models.DecimalField('单价', max_digits=10, decimal_places=2, default=0)
    is_active = models.BooleanField('启用', default=True)

    # VPS 默认规格
    default_vcpu = models.PositiveSmallIntegerField('vCPU', null=True, blank=True)
    default_ram_mb = models.PositiveIntegerField('内存(MB)', null=True, blank=True)
    default_disk_gb = models.PositiveIntegerField('硬盘(GB)', null=True, blank=True)

    # 通用带宽/IP 规格
    default_bandwidth_mbps = models.PositiveIntegerField('带宽(Mbps)', null=True, blank=True)
    default_ip_count = models.PositiveSmallIntegerField('IP 数量', null=True, blank=True)

    description = models.TextField('套餐描述', blank=True)
    remark = models.TextField('内部备注', blank=True)
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='创建人',
    )
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '服务套餐'
        verbose_name_plural = '服务套餐列表'
        ordering = ['plan_type', 'name']

    def __str__(self):
        return f'[{self.plan_no}] {self.name}'

    def save(self, *args, **kwargs):
        if not self.plan_no:
            prefix = 'PLAN'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = ServicePlan.objects.filter(
                plan_no__startswith=f'{prefix}{date_str}'
            ).order_by('-plan_no').first()
            seq = int(last.plan_no[-4:]) + 1 if last else 1
            self.plan_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


# ═══════════════════════════════════════════════════════════════
# § 2  服务工单
# ═══════════════════════════════════════════════════════════════

class ServiceOrder(models.Model):
    """客户服务工单（需求/申请入口）"""

    class OrderStatus(models.TextChoices):
        DRAFT = 'draft', '草稿'
        PENDING = 'pending', '待审批'
        APPROVED = 'approved', '已审批'
        PROVISIONING = 'provisioning', '开通中'
        ACTIVE = 'active', '服务中'
        SUSPEND_PENDING = 'suspend_pending', '待暂停'
        SUSPENDED = 'suspended', '已暂停'
        TERMINATE_PENDING = 'terminate_pending', '待终止'
        TERMINATED = 'terminated', '已终止'
        REJECTED = 'rejected', '已驳回'

    class OrderType(models.TextChoices):
        NEW = 'new', '新开服务'
        RENEW = 'renew', '续期'
        UPGRADE = 'upgrade', '升级'
        DOWNGRADE = 'downgrade', '降级'
        TERMINATE = 'terminate', '终止'
        CHANGE = 'change', '变更'

    class BusinessType(models.TextChoices):
        VPS = 'vps', 'VPS 主机'
        EDGE_GRE = 'edge_gre', '边缘加速 · GRE'
        EDGE_WG = 'edge_wg', '边缘加速 · WireGuard'
        EDGE_SOCKS5 = 'edge_socks5', '边缘加速 · Socks5'
        IP = 'ip', 'IP 资源'
        BANDWIDTH = 'bandwidth', '带宽资源'

    order_no = models.CharField('工单编号', max_length=32, unique=True, editable=False)
    order_type = models.CharField('工单类型', max_length=16, choices=OrderType.choices, default=OrderType.NEW)
    business_type = models.CharField(
        '业务类型', max_length=16,
        choices=BusinessType.choices, default=BusinessType.VPS,
        help_text='VPS 主机 / 边缘加速(GRE·WireGuard·Socks5) / IP / 带宽',
    )
    status = models.CharField(
        '状态', max_length=20,
        choices=OrderStatus.choices, default=OrderStatus.DRAFT,
    )
    customer = models.ForeignKey(
        'customer_manager.Customer',
        on_delete=models.PROTECT,
        verbose_name='客户', related_name='service_orders',
    )
    contract = models.ForeignKey(
        'customer_manager.Contract',
        on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联合同', related_name='service_orders',
    )
    service_plan = models.ForeignKey(
        ServicePlan,
        on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='服务套餐', related_name='orders',
    )

    # ── 通用资源需求 ──────────────────────────────────────────
    preferred_pop = models.ForeignKey(
        'resource_manager.PopPoint',
        on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='期望 POP 节点', related_name='preferred_orders',
    )
    requested_bandwidth_mbps = models.PositiveIntegerField('需求带宽(Mbps)', null=True, blank=True)
    requested_ip_count = models.PositiveSmallIntegerField('需求IP数', null=True, blank=True)
    requirements = models.TextField('需求描述', blank=True)

    # ── VPS 专属需求 ──────────────────────────────────────────
    requested_vcpu = models.PositiveSmallIntegerField('需求 vCPU', null=True, blank=True)
    requested_ram_mb = models.PositiveIntegerField('需求内存(MB)', null=True, blank=True)
    requested_disk_gb = models.PositiveIntegerField('需求硬盘(GB)', null=True, blank=True)
    requested_os = models.CharField(
        '期望操作系统', max_length=64, blank=True,
        help_text='如 Ubuntu 22.04 / CentOS 7 / Debian 12',
    )

    # ── 边缘加速通用需求 ──────────────────────────────────────
    # GRE 专属
    edge_local_ip = models.GenericIPAddressField(
        '本端 IP (GRE)', null=True, blank=True,
        help_text='GRE 隧道本端地址',
    )
    edge_remote_ip = models.GenericIPAddressField(
        '对端 IP (GRE)', null=True, blank=True,
        help_text='GRE 隧道对端地址',
    )
    # WireGuard 专属
    edge_wg_port = models.PositiveIntegerField(
        'WG 监听端口', null=True, blank=True, default=51820,
    )
    edge_wg_keepalive = models.PositiveSmallIntegerField(
        'WG 保活间隔(s)', null=True, blank=True, default=25,
    )
    edge_wg_allowed_ips = models.TextField(
        'WG 允许 IP 段', blank=True,
        help_text='每行一条，如 0.0.0.0/0 或 10.0.0.0/8',
    )
    edge_wg_client_pubkey = models.CharField(
        '客户端公钥 (WG)', max_length=64, blank=True,
    )
    # Socks5 专属
    edge_socks5_port = models.PositiveIntegerField(
        'Socks5 端口', null=True, blank=True, default=1080,
    )
    edge_socks5_user = models.CharField(
        'Socks5 认证用户名', max_length=64, blank=True,
    )
    edge_socks5_pass = models.CharField(
        'Socks5 认证密码', max_length=128, blank=True,
    )

    # ── 服务期限与费用 ────────────────────────────────────────
    service_start = models.DateField('服务开始日', null=True, blank=True)
    service_end = models.DateField('服务结束日', null=True, blank=True)
    billing_cycle = models.CharField(
        '计费周期', max_length=16,
        choices=ServicePlan.BillingCycle.choices, default=ServicePlan.BillingCycle.MONTHLY,
        blank=True,
    )
    quoted_price = models.DecimalField('报价', max_digits=10, decimal_places=2, null=True, blank=True)

    # ── 审批 ──────────────────────────────────────────────────
    approved_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='审批人', related_name='approved_orders',
    )
    approved_at = models.DateTimeField('审批时间', null=True, blank=True)
    reject_reason = models.CharField('驳回原因', max_length=512, blank=True)

    # ── 操作人 ────────────────────────────────────────────────
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='创建人', related_name='created_orders',
    )
    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '服务工单'
        verbose_name_plural = '服务工单列表'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['customer']),
            models.Index(fields=['order_type']),
            models.Index(fields=['business_type']),
        ]

    def __str__(self):
        return f'[{self.order_no}] {self.get_business_type_display()} - {self.customer.name}'

    def save(self, *args, **kwargs):
        if not self.order_no:
            prefix = 'SO'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = ServiceOrder.objects.filter(
                order_no__startswith=f'{prefix}{date_str}'
            ).order_by('-order_no').first()
            seq = int(last.order_no[-4:]) + 1 if last else 1
            self.order_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)

    @property
    def is_vps(self):
        return self.business_type == self.BusinessType.VPS

    @property
    def is_edge(self):
        return self.business_type in (
            self.BusinessType.EDGE_GRE,
            self.BusinessType.EDGE_WG,
            self.BusinessType.EDGE_SOCKS5,
        )


# ─────────────────────────────────────────────────────────────
# 代理模型：用于 Admin 按业务类型分离展示
# ─────────────────────────────────────────────────────────────

class VPSServiceOrder(ServiceOrder):
    """VPS 服务工单（代理模型）"""
    class Meta:
        proxy = True
        verbose_name = 'VPS 服务工单'
        verbose_name_plural = 'VPS 服务工单列表'


class EdgeServiceOrder(ServiceOrder):
    """边缘加速工单（代理模型，含 GRE / WireGuard / Socks5）"""
    class Meta:
        proxy = True
        verbose_name = '边缘加速工单'
        verbose_name_plural = '边缘加速工单列表'


# ═══════════════════════════════════════════════════════════════
# § 3  服务实例（已分配的具体资源）
# ═══════════════════════════════════════════════════════════════

class ServiceInstance(models.Model):
    """
    服务实例 — 一个工单可对应多个实例（如 1 个 VPS + 1 个 EdgeAcceleration）
    实例与资源管理中的具体对象直接关联，并在状态变更时同步更新资源。
    """

    class InstanceStatus(models.TextChoices):
        PROVISIONING = 'provisioning', '开通中'
        ACTIVE = 'active', '运行中'
        SUSPENDED = 'suspended', '已暂停'
        TERMINATED = 'terminated', '已终止'
        EXPIRED = 'expired', '已过期'
        ERROR = 'error', '故障'

    class ServiceType(models.TextChoices):
        VPS = 'vps', 'VPS'
        EDGE_ACCELERATION = 'edge', '边缘加速'
        IP_ADDRESS = 'ip', 'IP 地址'
        BANDWIDTH = 'bandwidth', '带宽'

    instance_no = models.CharField('实例编号', max_length=32, unique=True, editable=False)
    service_order = models.ForeignKey(
        ServiceOrder,
        on_delete=models.PROTECT,
        verbose_name='所属工单', related_name='instances',
    )
    service_type = models.CharField('服务类型', max_length=16, choices=ServiceType.choices)
    status = models.CharField(
        '状态', max_length=16,
        choices=InstanceStatus.choices, default=InstanceStatus.PROVISIONING,
    )

    # ── 资源绑定（按类型设置对应 FK，其余为 NULL）──────────────
    vps = models.OneToOneField(
        'resource_manager.VPS',
        on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联 VPS', related_name='service_instance',
    )
    edge = models.OneToOneField(
        'resource_manager.EdgeAcceleration',
        on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联边缘加速', related_name='service_instance',
    )
    bandwidth_alloc = models.OneToOneField(
        'resource_manager.BandwidthAllocation',
        on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='关联带宽分配', related_name='service_instance',
    )

    # IP 地址为多对多（一个实例可绑定多个 IP）
    ip_addresses = models.ManyToManyField(
        'resource_manager.IPAddress',
        blank=True,
        verbose_name='关联 IP 地址', related_name='service_instances',
    )

    # ── 规格快照（实例化时拍摄，记录历史）────────────────────────
    spec_snapshot = models.JSONField('规格快照', default=dict, blank=True,
                                     help_text='开通时的资源规格 JSON 快照')

    # ── 计费信息 ──────────────────────────────────────────────
    monthly_fee = models.DecimalField(
        '月费', max_digits=12, decimal_places=2, default=0,
        help_text='该实例整月费用（按所属币种）；为 0 时回退取工单报价',
    )
    fee_currency = models.CharField('费用币种', max_length=8, default='CNY',
                                    help_text='CNY 人民币 / USD 美元 / CREDIT 信誉额')
    is_trial = models.BooleanField('测试服务', default=False,
                                   help_text='测试期间默认不计入账单，可转入计费周期')
    trial_start = models.DateField('测试开始日', null=True, blank=True)
    trial_end = models.DateField('测试结束日', null=True, blank=True)
    billing_start_date = models.DateField(
        '计费起始日', null=True, blank=True,
        help_text='正式计费起始日期；测试转正后置为转入日期',
    )

    # ── 生命周期 ──────────────────────────────────────────────
    provisioned_at = models.DateTimeField('开通时间', null=True, blank=True)
    activated_at = models.DateTimeField('激活时间', null=True, blank=True)
    suspended_at = models.DateTimeField('暂停时间', null=True, blank=True)
    terminated_at = models.DateTimeField('终止时间', null=True, blank=True)
    expire_time = models.DateTimeField('到期时间', null=True, blank=True)

    provisioned_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='开通人', related_name='provisioned_instances',
    )
    terminated_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='终止人', related_name='terminated_instances',
    )

    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '服务实例'
        verbose_name_plural = '服务实例列表'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['service_type']),
            models.Index(fields=['service_order']),
        ]

    def __str__(self):
        return f'[{self.instance_no}] {self.get_service_type_display()} - {self.service_order.customer.name}'

    def save(self, *args, **kwargs):
        if not self.instance_no:
            prefix = 'INS'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = ServiceInstance.objects.filter(
                instance_no__startswith=f'{prefix}{date_str}'
            ).order_by('-instance_no').first()
            seq = int(last.instance_no[-4:]) + 1 if last else 1
            self.instance_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)

    # ── 资源联动方法 ───────────────────────────────────────────

    @property
    def customer(self):
        return self.service_order.customer

    def _get_resource(self):
        """返回当前绑定的主资源对象"""
        return self.vps or self.edge or self.bandwidth_alloc

    # ── 计费相关 ──────────────────────────────────────────────

    def billed_resource(self):
        """返回该实例绑定的、可据产品计费的资源 (resource, kind)。"""
        if self.vps_id and self.vps:
            return self.vps, 'vps'
        if self.edge_id and self.edge:
            return self.edge, 'edge'
        if self.bandwidth_alloc_id and self.bandwidth_alloc:
            return self.bandwidth_alloc, 'bandwidth'
        return None, None

    def product_billing(self):
        """若绑定资源已关联产品，返回产品计费明细（基础+超出）；否则 None。"""
        resource, kind = self.billed_resource()
        if resource is None or getattr(resource, 'product_id', None) is None:
            return None
        try:
            from product_manager import services as product_services
            return product_services.compute_resource_billing(resource, kind)
        except Exception:
            return None

    def effective_monthly_fee(self):
        """整月费用。

        优先级：实例自身月费(人工覆盖) > 关联产品定价(基础+超出) > 工单报价。
        """
        from decimal import Decimal
        if self.monthly_fee and self.monthly_fee > 0:
            return Decimal(str(self.monthly_fee))
        pb = self.product_billing()
        if pb is not None:
            return Decimal(str(pb['monthly_price']))
        quoted = getattr(self.service_order, 'quoted_price', None)
        return Decimal(str(quoted)) if quoted else Decimal('0')

    def effective_fee_currency(self):
        """整月费用对应币种。人工月费用 fee_currency；产品定价用产品币种。"""
        if self.monthly_fee and self.monthly_fee > 0:
            return (self.fee_currency or 'CNY').upper()
        pb = self.product_billing()
        if pb is not None:
            return (pb['currency'] or 'CNY').upper()
        return (self.fee_currency or 'CNY').upper()

    def billing_effective_start(self):
        """正式计费起始日期：计费起始日 > 激活日 > 工单服务开始日。"""
        if self.billing_start_date:
            return self.billing_start_date
        if self.activated_at:
            return self.activated_at.date()
        if self.provisioned_at:
            return self.provisioned_at.date()
        return getattr(self.service_order, 'service_start', None)

    def service_end_date(self):
        """服务结束日期：终止日 > 工单服务结束日 > 到期时间。"""
        if self.terminated_at:
            return self.terminated_at.date()
        if getattr(self.service_order, 'service_end', None):
            return self.service_order.service_end
        if self.expire_time:
            return self.expire_time.date()
        return None

    def convert_to_billing(self, operator=None, billing_start=None):
        """把测试服务转入正式计费周期。"""
        self.is_trial = False
        self.trial_end = self.trial_end or timezone.now().date()
        self.billing_start_date = billing_start or timezone.now().date()
        self.save(update_fields=['is_trial', 'trial_end', 'billing_start_date', 'updated_at'])
        ServiceAllocation.objects.create(
            service_instance=self,
            action_type=ServiceAllocation.ActionType.MODIFY,
            description=f'测试服务转入计费周期，计费起始 {self.billing_start_date}',
            operator=operator,
        )
        _log_service(
            operator=operator,
            action_type=ServiceOperationLog.ActionType.CHANGE,
            description=f'测试服务 [{self.instance_no}] 转入计费周期，起始 {self.billing_start_date}',
            service_instance=self,
            service_order=self.service_order,
        )

    def activate(self, operator=None):
        """激活实例：更新资源状态并关联客户"""
        now = timezone.now()
        customer = self.customer

        if self.vps:
            self.vps.customer = customer
            self.vps.start_time = self.vps.start_time or now
            self.vps.status = 'running'
            self.vps.save(update_fields=['customer', 'start_time', 'status', 'updated_at'])

        if self.edge:
            self.edge.customer = customer
            self.edge.start_time = self.edge.start_time or now
            self.edge.status = 'active'
            self.edge.save(update_fields=['customer', 'start_time', 'status', 'updated_at'])

        if self.bandwidth_alloc:
            self.bandwidth_alloc.is_active = True
            self.bandwidth_alloc.save(update_fields=['is_active', 'updated_at'])

        # 更新 IP 状态
        for ip in self.ip_addresses.all():
            if ip.status != 'assigned':
                ip.status = 'assigned'
                ip.assigned_at = now
                if self.vps:
                    ip.assigned_vps = self.vps
                if self.edge:
                    ip.assigned_edge = self.edge
                ip.save(update_fields=['status', 'assigned_at', 'assigned_vps', 'assigned_edge'])

        self.status = self.InstanceStatus.ACTIVE
        self.activated_at = now
        self.provisioned_at = self.provisioned_at or now
        if operator:
            self.provisioned_by = operator
        self.save(update_fields=['status', 'activated_at', 'provisioned_at', 'provisioned_by', 'updated_at'])

        ServiceAllocation.objects.create(
            service_instance=self,
            action_type=ServiceAllocation.ActionType.ACTIVATE,
            description=f'激活服务实例 {self.instance_no}',
            operator=operator,
        )
        _log_service(
            operator=operator,
            action_type=ServiceOperationLog.ActionType.ACTIVATE,
            description=f'激活服务实例 [{self.instance_no}]',
            service_instance=self,
            service_order=self.service_order,
        )

    def suspend(self, operator=None, reason=''):
        """暂停实例：冻结资源"""
        now = timezone.now()

        if self.vps:
            self.vps.status = 'suspended'
            self.vps.save(update_fields=['status', 'updated_at'])

        if self.edge:
            self.edge.status = 'stopped'
            self.edge.save(update_fields=['status', 'updated_at'])

        self.status = self.InstanceStatus.SUSPENDED
        self.suspended_at = now
        self.save(update_fields=['status', 'suspended_at', 'updated_at'])

        ServiceAllocation.objects.create(
            service_instance=self,
            action_type=ServiceAllocation.ActionType.SUSPEND,
            description=f'暂停服务实例 {self.instance_no}，原因：{reason}',
            operator=operator,
        )
        _log_service(
            operator=operator,
            action_type=ServiceOperationLog.ActionType.SUSPEND,
            description=f'暂停服务实例 [{self.instance_no}] 原因：{reason}',
            service_instance=self,
            service_order=self.service_order,
        )

    def resume(self, operator=None):
        """恢复暂停的实例"""
        now = timezone.now()

        if self.vps:
            self.vps.status = 'running'
            self.vps.save(update_fields=['status', 'updated_at'])

        if self.edge:
            self.edge.status = 'active'
            self.edge.save(update_fields=['status', 'updated_at'])

        self.status = self.InstanceStatus.ACTIVE
        self.suspended_at = None
        self.save(update_fields=['status', 'suspended_at', 'updated_at'])

        ServiceAllocation.objects.create(
            service_instance=self,
            action_type=ServiceAllocation.ActionType.RESUME,
            description=f'恢复服务实例 {self.instance_no}',
            operator=operator,
        )
        _log_service(
            operator=operator,
            action_type=ServiceOperationLog.ActionType.RESUME,
            description=f'恢复服务实例 [{self.instance_no}]',
            service_instance=self,
            service_order=self.service_order,
        )

    def terminate(self, operator=None, reason=''):
        """终止实例：释放全部关联资源"""
        now = timezone.now()

        if self.vps:
            self.vps.customer = None
            self.vps.status = 'stopped'
            self.vps.expire_time = now
            self.vps.save(update_fields=['customer', 'status', 'expire_time', 'updated_at'])

        if self.edge:
            self.edge.customer = None
            self.edge.status = 'stopped'
            self.edge.expire_time = now
            self.edge.save(update_fields=['customer', 'status', 'expire_time', 'updated_at'])

        if self.bandwidth_alloc:
            self.bandwidth_alloc.is_active = False
            self.bandwidth_alloc.save(update_fields=['is_active', 'updated_at'])

        # 释放所有关联 IP
        for ip in self.ip_addresses.all():
            ip.status = 'available'
            ip.assigned_vps = None
            ip.assigned_edge = None
            ip.assigned_at = None
            ip.save(update_fields=['status', 'assigned_vps', 'assigned_edge', 'assigned_at'])

        self.status = self.InstanceStatus.TERMINATED
        self.terminated_at = now
        self.terminated_by = operator
        self.save(update_fields=['status', 'terminated_at', 'terminated_by', 'updated_at'])

        ServiceAllocation.objects.create(
            service_instance=self,
            action_type=ServiceAllocation.ActionType.TERMINATE,
            description=f'终止服务实例 {self.instance_no}，原因：{reason}',
            operator=operator,
        )
        _log_service(
            operator=operator,
            action_type=ServiceOperationLog.ActionType.TERMINATE,
            description=f'终止服务实例 [{self.instance_no}] 原因：{reason}',
            service_instance=self,
            service_order=self.service_order,
        )


# ═══════════════════════════════════════════════════════════════
# § 4  资源分配/回收明细记录
# ═══════════════════════════════════════════════════════════════

class ServiceAllocation(models.Model):
    """资源分配、暂停、恢复、终止的每步明细"""

    class ActionType(models.TextChoices):
        ALLOCATE = 'allocate', '分配资源'
        ACTIVATE = 'activate', '激活服务'
        MODIFY = 'modify', '变更规格'
        SUSPEND = 'suspend', '暂停服务'
        RESUME = 'resume', '恢复服务'
        TERMINATE = 'terminate', '终止/回收'
        RENEW = 'renew', '续期'
        IP_ADD = 'ip_add', '增加 IP'
        IP_REMOVE = 'ip_remove', '移除 IP'
        BW_CHANGE = 'bw_change', '带宽变更'
        OTHER = 'other', '其他'

    service_instance = models.ForeignKey(
        ServiceInstance,
        on_delete=models.CASCADE,
        verbose_name='服务实例', related_name='allocations',
    )
    action_type = models.CharField('操作类型', max_length=16, choices=ActionType.choices)
    description = models.CharField('操作描述', max_length=512)

    # 资源快照（操作前后）
    before_state = models.JSONField('操作前状态', null=True, blank=True)
    after_state = models.JSONField('操作后状态', null=True, blank=True)

    # 操作涉及的具体资源（可选，用于精确追踪）
    resource_type = models.CharField('资源类型', max_length=32, blank=True,
                                      help_text='如 VPS / EdgeAcceleration / IPAddress')
    resource_id = models.PositiveIntegerField('资源 ID', null=True, blank=True)
    resource_repr = models.CharField('资源描述', max_length=256, blank=True)

    operator = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='操作人',
    )
    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('操作时间', auto_now_add=True)

    class Meta:
        verbose_name = '分配记录'
        verbose_name_plural = '分配记录'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['service_instance', 'created_at']),
            models.Index(fields=['action_type']),
        ]

    def __str__(self):
        return f'[{self.get_action_type_display()}] {self.service_instance.instance_no} - {self.description[:40]}'


# ═══════════════════════════════════════════════════════════════
# § 5  服务变更申请与记录
# ═══════════════════════════════════════════════════════════════

class ServiceChangeRecord(models.Model):
    """服务变更申请（升降配、续期、IP 变更、带宽调整等）"""

    class ChangeType(models.TextChoices):
        UPGRADE = 'upgrade', '升配'
        DOWNGRADE = 'downgrade', '降配'
        EXTEND = 'extend', '续期'
        IP_CHANGE = 'ip_change', 'IP 变更'
        BW_CHANGE = 'bw_change', '带宽调整'
        PROTOCOL_CHANGE = 'protocol_change', '协议变更'
        MIGRATE = 'migrate', '迁移节点'
        OTHER = 'other', '其他变更'

    class ChangeStatus(models.TextChoices):
        PENDING = 'pending', '待审批'
        APPROVED = 'approved', '已审批'
        IN_PROGRESS = 'in_progress', '变更中'
        COMPLETED = 'completed', '已完成'
        REJECTED = 'rejected', '已驳回'
        CANCELLED = 'cancelled', '已取消'

    change_no = models.CharField('变更单号', max_length=32, unique=True, editable=False)
    service_instance = models.ForeignKey(
        ServiceInstance,
        on_delete=models.PROTECT,
        verbose_name='服务实例', related_name='change_records',
    )
    change_type = models.CharField('变更类型', max_length=20, choices=ChangeType.choices)
    status = models.CharField(
        '变更状态', max_length=16,
        choices=ChangeStatus.choices, default=ChangeStatus.PENDING,
    )

    # 变更前后规格
    before_spec = models.JSONField('变更前规格', default=dict, blank=True)
    after_spec = models.JSONField('变更后规格', default=dict, blank=True)

    # 变更说明
    change_reason = models.CharField('变更原因', max_length=512)
    change_detail = models.TextField('变更详情', blank=True)

    # 价格调整
    price_delta = models.DecimalField('价格差额', max_digits=10, decimal_places=2,
                                       null=True, blank=True,
                                       help_text='正数为追加费用，负数为退款')

    # 计划/实际执行时间
    scheduled_at = models.DateTimeField('计划执行时间', null=True, blank=True)
    executed_at = models.DateTimeField('实际执行时间', null=True, blank=True)

    # 审批
    approved_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='审批人', related_name='approved_changes',
    )
    approved_at = models.DateTimeField('审批时间', null=True, blank=True)
    reject_reason = models.CharField('驳回原因', max_length=512, blank=True)

    requested_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='申请人', related_name='requested_changes',
    )
    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '服务变更记录'
        verbose_name_plural = '服务变更记录'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['service_instance', 'status']),
            models.Index(fields=['change_type']),
        ]

    def __str__(self):
        return f'[{self.change_no}] {self.get_change_type_display()} - {self.service_instance.instance_no}'

    def save(self, *args, **kwargs):
        if not self.change_no:
            prefix = 'CHG'
            date_str = datetime.date.today().strftime('%Y%m%d')
            last = ServiceChangeRecord.objects.filter(
                change_no__startswith=f'{prefix}{date_str}'
            ).order_by('-change_no').first()
            seq = int(last.change_no[-4:]) + 1 if last else 1
            self.change_no = f'{prefix}{date_str}{seq:04d}'
        super().save(*args, **kwargs)


# ═══════════════════════════════════════════════════════════════
# § 6  服务操作日志
# ═══════════════════════════════════════════════════════════════

class ServiceOperationLog(models.Model):
    """服务管理模块统一操作日志"""

    class ActionType(models.TextChoices):
        CREATE_ORDER = 'create_order', '创建工单'
        APPROVE_ORDER = 'approve_order', '审批工单'
        REJECT_ORDER = 'reject_order', '驳回工单'
        PROVISION = 'provision', '开通资源'
        ACTIVATE = 'activate', '激活服务'
        SUSPEND = 'suspend', '暂停服务'
        RESUME = 'resume', '恢复服务'
        TERMINATE = 'terminate', '终止服务'
        RENEW = 'renew', '续期服务'
        CHANGE = 'change', '变更服务'
        ASSIGN_IP = 'assign_ip', '分配 IP'
        RELEASE_IP = 'release_ip', '释放 IP'
        BW_ADJUST = 'bw_adjust', '调整带宽'
        OTHER = 'other', '其他'

    operator = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='操作人',
    )
    action_type = models.CharField('操作类型', max_length=20, choices=ActionType.choices)
    description = models.CharField('操作描述', max_length=512)

    service_order = models.ForeignKey(
        ServiceOrder, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='关联工单', related_name='operation_logs',
    )
    service_instance = models.ForeignKey(
        ServiceInstance, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='关联实例', related_name='operation_logs',
    )

    old_value = models.JSONField('变更前', null=True, blank=True)
    new_value = models.JSONField('变更后', null=True, blank=True)
    ip_address = models.GenericIPAddressField('操作 IP', null=True, blank=True)
    created_at = models.DateTimeField('操作时间', auto_now_add=True)

    class Meta:
        verbose_name = '服务操作日志'
        verbose_name_plural = '服务操作日志'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['action_type', 'created_at']),
            models.Index(fields=['service_order', 'created_at']),
            models.Index(fields=['service_instance', 'created_at']),
        ]

    def __str__(self):
        op = self.operator.username if self.operator else '系统'
        return f'[{self.get_action_type_display()}] {op} - {self.description[:40]}'


# ═══════════════════════════════════════════════════════════════
# § 工具函数
# ═══════════════════════════════════════════════════════════════

def _log_service(*, operator, action_type, description,
                 service_order=None, service_instance=None,
                 old_value=None, new_value=None, request=None):
    """内部日志工具，供模型方法和外部调用"""
    ip_address = None
    if request:
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        ip_address = (
            x_forwarded_for.split(',')[0].strip()
            if x_forwarded_for
            else request.META.get('REMOTE_ADDR')
        )
    ServiceOperationLog.objects.create(
        operator=operator,
        action_type=action_type,
        description=description,
        service_order=service_order,
        service_instance=service_instance,
        old_value=old_value,
        new_value=new_value,
        ip_address=ip_address,
    )


def service_snapshot(instance):
    """获取服务实例的当前资源状态快照"""
    snap = {
        'instance_no': instance.instance_no,
        'service_type': instance.service_type,
        'status': instance.status,
    }
    if instance.vps_id:
        vps = instance.vps
        snap['vps'] = {
            'id': vps.pk, 'vps_no': vps.vps_no, 'name': vps.name,
            'vcpu': vps.vcpu, 'ram_mb': vps.ram_mb, 'disk_gb': vps.disk_gb,
            'status': vps.status, 'bandwidth_mbps': vps.bandwidth_mbps,
        }
    if instance.edge_id:
        edge = instance.edge
        snap['edge'] = {
            'id': edge.pk, 'edge_no': edge.edge_no, 'name': edge.name,
            'protocol': edge.protocol, 'status': edge.status,
            'bandwidth_mbps': edge.bandwidth_mbps,
        }
    if instance.bandwidth_alloc_id:
        bw = instance.bandwidth_alloc
        snap['bandwidth'] = {
            'id': bw.pk, 'allocated_mbps': bw.allocated_mbps, 'is_active': bw.is_active,
        }
    snap['ip_addresses'] = list(
        instance.ip_addresses.values('id', 'address', 'prefix_len', 'status')
    )
    return snap
