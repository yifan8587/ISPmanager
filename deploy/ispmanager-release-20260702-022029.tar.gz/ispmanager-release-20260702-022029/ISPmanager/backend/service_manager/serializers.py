"""
service_manager/serializers.py
服务管理模块 DRF 序列化器
"""
from rest_framework import serializers

from .models import (
    ServicePlan, ServiceOrder, ServiceInstance,
    ServiceAllocation, ServiceChangeRecord, ServiceOperationLog,
)


# ─────────────────────────────────────────────────────────────
# 通用工具
# ─────────────────────────────────────────────────────────────

class UserBriefSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    username = serializers.CharField()
    first_name = serializers.CharField()
    last_name = serializers.CharField()


# ═══════════════════════════════════════════════════════════════
# § 1  服务套餐
# ═══════════════════════════════════════════════════════════════

class ServicePlanSerializer(serializers.ModelSerializer):
    plan_type_label = serializers.CharField(source='get_plan_type_display', read_only=True)
    billing_cycle_label = serializers.CharField(source='get_billing_cycle_display', read_only=True)

    class Meta:
        model = ServicePlan
        fields = [
            'id', 'plan_no', 'name', 'plan_type', 'plan_type_label',
            'billing_cycle', 'billing_cycle_label',
            'price', 'is_active',
            'default_vcpu', 'default_ram_mb', 'default_disk_gb',
            'default_bandwidth_mbps', 'default_ip_count',
            'description', 'remark', 'created_at', 'updated_at',
        ]
        read_only_fields = ['plan_no', 'created_at', 'updated_at']


class ServicePlanBriefSerializer(serializers.ModelSerializer):
    plan_type_label = serializers.CharField(source='get_plan_type_display', read_only=True)

    class Meta:
        model = ServicePlan
        fields = ['id', 'plan_no', 'name', 'plan_type', 'plan_type_label', 'price', 'billing_cycle']


# ═══════════════════════════════════════════════════════════════
# § 2  服务工单
# ═══════════════════════════════════════════════════════════════

class ServiceOrderListSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    order_type_label = serializers.CharField(source='get_order_type_display', read_only=True)
    billing_cycle_label = serializers.CharField(source='get_billing_cycle_display', read_only=True)
    customer_name = serializers.CharField(source='customer.name', read_only=True)
    customer_no = serializers.CharField(source='customer.customer_no', read_only=True)
    service_plan_name = serializers.CharField(source='service_plan.name', read_only=True)
    instance_count = serializers.SerializerMethodField()
    created_by_name = serializers.SerializerMethodField()

    class Meta:
        model = ServiceOrder
        fields = [
            'id', 'order_no', 'order_type', 'order_type_label',
            'status', 'status_label',
            'customer', 'customer_name', 'customer_no',
            'service_plan', 'service_plan_name',
            'billing_cycle', 'billing_cycle_label',
            'quoted_price',
            'service_start', 'service_end',
            'instance_count',
            'created_by', 'created_by_name',
            'created_at', 'updated_at',
        ]

    def get_instance_count(self, obj):
        return obj.instances.count()

    def get_created_by_name(self, obj):
        return obj.created_by.get_full_name() or obj.created_by.username if obj.created_by else None


class ServiceOrderDetailSerializer(ServiceOrderListSerializer):
    instances = serializers.SerializerMethodField()
    approved_by_info = serializers.SerializerMethodField()
    recent_logs = serializers.SerializerMethodField()

    class Meta(ServiceOrderListSerializer.Meta):
        fields = ServiceOrderListSerializer.Meta.fields + [
            'contract', 'requirements',
            'requested_vcpu', 'requested_ram_mb', 'requested_disk_gb',
            'requested_bandwidth_mbps', 'requested_ip_count',
            'approved_by', 'approved_by_info', 'approved_at', 'reject_reason',
            'remark', 'instances', 'recent_logs',
        ]

    def get_instances(self, obj):
        return ServiceInstanceBriefSerializer(
            obj.instances.all(), many=True, context=self.context
        ).data

    def get_approved_by_info(self, obj):
        if obj.approved_by:
            return {'id': obj.approved_by.id, 'username': obj.approved_by.username}
        return None

    def get_recent_logs(self, obj):
        logs = obj.operation_logs.order_by('-created_at')[:10]
        return ServiceOperationLogSerializer(logs, many=True).data


class ServiceOrderWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceOrder
        fields = [
            'order_type', 'status', 'customer', 'contract', 'service_plan',
            'requested_vcpu', 'requested_ram_mb', 'requested_disk_gb',
            'requested_bandwidth_mbps', 'requested_ip_count',
            'requirements',
            'service_start', 'service_end', 'billing_cycle',
            'quoted_price', 'reject_reason', 'remark',
        ]

    def validate(self, data):
        service_start = data.get('service_start')
        service_end = data.get('service_end')
        if service_start and service_end and service_end <= service_start:
            raise serializers.ValidationError({'service_end': '服务结束日期必须晚于开始日期'})
        return data


# ═══════════════════════════════════════════════════════════════
# § 3  服务实例
# ═══════════════════════════════════════════════════════════════

class ServiceInstanceBriefSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    service_type_label = serializers.CharField(source='get_service_type_display', read_only=True)
    resource_name = serializers.SerializerMethodField()

    class Meta:
        model = ServiceInstance
        fields = [
            'id', 'instance_no', 'service_type', 'service_type_label',
            'status', 'status_label', 'resource_name',
            'is_trial', 'monthly_fee', 'fee_currency',
            'expire_time', 'provisioned_at',
        ]

    def get_resource_name(self, obj):
        if obj.vps_id:
            return f'[VPS] {obj.vps.name}' if obj.vps else None
        if obj.edge_id:
            return f'[EDGE] {obj.edge.name}' if obj.edge else None
        if obj.bandwidth_alloc_id:
            bw = obj.bandwidth_alloc
            return f'[BW] {bw.allocated_mbps}Mbps' if bw else None
        return None


class ServiceInstanceListSerializer(ServiceInstanceBriefSerializer):
    customer_name = serializers.CharField(source='service_order.customer.name', read_only=True)
    customer_no = serializers.CharField(source='service_order.customer.customer_no', read_only=True)
    order_no = serializers.CharField(source='service_order.order_no', read_only=True)
    ip_count = serializers.SerializerMethodField()
    vps_info = serializers.SerializerMethodField()
    edge_info = serializers.SerializerMethodField()

    class Meta(ServiceInstanceBriefSerializer.Meta):
        fields = ServiceInstanceBriefSerializer.Meta.fields + [
            'service_order', 'order_no',
            'customer_name', 'customer_no',
            'ip_count', 'vps_info', 'edge_info',
            'trial_start', 'trial_end', 'billing_start_date',
            'activated_at', 'suspended_at', 'terminated_at',
            'created_at',
        ]

    def get_ip_count(self, obj):
        return obj.ip_addresses.count()

    def get_vps_info(self, obj):
        if obj.vps:
            return {
                'id': obj.vps.pk, 'vps_no': obj.vps.vps_no,
                'name': obj.vps.name, 'status': obj.vps.status,
            }
        return None

    def get_edge_info(self, obj):
        if obj.edge:
            return {
                'id': obj.edge.pk, 'edge_no': obj.edge.edge_no,
                'name': obj.edge.name, 'protocol': obj.edge.protocol,
                'status': obj.edge.status,
            }
        return None


class ServiceInstanceDetailSerializer(ServiceInstanceListSerializer):
    ip_addresses = serializers.SerializerMethodField()
    allocations = serializers.SerializerMethodField()
    change_records = serializers.SerializerMethodField()
    recent_logs = serializers.SerializerMethodField()
    provisioned_by_name = serializers.SerializerMethodField()
    terminated_by_name = serializers.SerializerMethodField()
    bandwidth_info = serializers.SerializerMethodField()

    class Meta(ServiceInstanceListSerializer.Meta):
        fields = ServiceInstanceListSerializer.Meta.fields + [
            'vps', 'edge', 'bandwidth_alloc',
            'bandwidth_info', 'ip_addresses',
            'spec_snapshot',
            'provisioned_by', 'provisioned_by_name',
            'terminated_by', 'terminated_by_name',
            'remark', 'updated_at',
            'allocations', 'change_records', 'recent_logs',
        ]

    def get_ip_addresses(self, obj):
        return list(obj.ip_addresses.values('id', 'address', 'prefix_len', 'ip_version', 'status'))

    def get_allocations(self, obj):
        allocs = obj.allocations.order_by('-created_at')[:20]
        return ServiceAllocationSerializer(allocs, many=True).data

    def get_change_records(self, obj):
        records = obj.change_records.order_by('-created_at')[:10]
        return ServiceChangeRecordListSerializer(records, many=True).data

    def get_recent_logs(self, obj):
        logs = obj.operation_logs.order_by('-created_at')[:10]
        return ServiceOperationLogSerializer(logs, many=True).data

    def get_provisioned_by_name(self, obj):
        if obj.provisioned_by:
            return obj.provisioned_by.get_full_name() or obj.provisioned_by.username
        return None

    def get_terminated_by_name(self, obj):
        if obj.terminated_by:
            return obj.terminated_by.get_full_name() or obj.terminated_by.username
        return None

    def get_bandwidth_info(self, obj):
        if obj.bandwidth_alloc:
            bw = obj.bandwidth_alloc
            return {
                'id': bw.pk, 'allocated_mbps': bw.allocated_mbps,
                'used_mbps': getattr(bw, 'used_mbps', None),
                'is_active': bw.is_active,
            }
        return None


class ServiceInstanceWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceInstance
        fields = [
            'service_order', 'service_type', 'status',
            'vps', 'edge', 'bandwidth_alloc', 'ip_addresses',
            'spec_snapshot', 'expire_time', 'remark',
            'monthly_fee', 'fee_currency',
            'is_trial', 'trial_start', 'trial_end', 'billing_start_date',
        ]

    def validate(self, data):
        service_type = data.get('service_type')
        vps = data.get('vps')
        edge = data.get('edge')
        bw = data.get('bandwidth_alloc')

        if service_type == 'vps' and not vps:
            raise serializers.ValidationError({'vps': 'VPS 类型服务必须绑定 VPS 资源'})
        if service_type == 'edge' and not edge:
            raise serializers.ValidationError({'edge': '边缘加速类型服务必须绑定 EdgeAcceleration 资源'})
        if service_type == 'bandwidth' and not bw:
            raise serializers.ValidationError({'bandwidth_alloc': '带宽类型服务必须绑定带宽分配'})
        return data


# ═══════════════════════════════════════════════════════════════
# § 4  资源分配记录
# ═══════════════════════════════════════════════════════════════

class ServiceAllocationSerializer(serializers.ModelSerializer):
    action_type_label = serializers.CharField(source='get_action_type_display', read_only=True)
    operator_name = serializers.SerializerMethodField()

    class Meta:
        model = ServiceAllocation
        fields = [
            'id', 'action_type', 'action_type_label',
            'description', 'resource_type', 'resource_id', 'resource_repr',
            'before_state', 'after_state',
            'operator', 'operator_name', 'remark', 'created_at',
        ]
        read_only_fields = fields

    def get_operator_name(self, obj):
        if obj.operator:
            return obj.operator.get_full_name() or obj.operator.username
        return '系统'


# ═══════════════════════════════════════════════════════════════
# § 5  服务变更记录
# ═══════════════════════════════════════════════════════════════

class ServiceChangeRecordListSerializer(serializers.ModelSerializer):
    change_type_label = serializers.CharField(source='get_change_type_display', read_only=True)
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    customer_name = serializers.CharField(
        source='service_instance.service_order.customer.name', read_only=True,
    )
    # 添加实例编号，方便前端直接展示（不需要再查询关联对象）
    instance_no = serializers.CharField(source='service_instance.instance_no', read_only=True)
    requested_by_name = serializers.SerializerMethodField()

    class Meta:
        model = ServiceChangeRecord
        fields = [
            'id', 'change_no', 'service_instance', 'instance_no',
            'change_type', 'change_type_label',
            'status', 'status_label',
            'change_reason', 'customer_name',
            'price_delta', 'scheduled_at', 'executed_at',
            'requested_by', 'requested_by_name',
            'created_at', 'updated_at',
        ]

    def get_requested_by_name(self, obj):
        if obj.requested_by:
            return obj.requested_by.get_full_name() or obj.requested_by.username
        return None


class ServiceChangeRecordDetailSerializer(ServiceChangeRecordListSerializer):
    approved_by_name = serializers.SerializerMethodField()

    class Meta(ServiceChangeRecordListSerializer.Meta):
        fields = ServiceChangeRecordListSerializer.Meta.fields + [
            'change_detail',
            'before_spec', 'after_spec',
            'approved_by', 'approved_by_name', 'approved_at',
            'reject_reason', 'remark',
        ]

    def get_approved_by_name(self, obj):
        if obj.approved_by:
            return obj.approved_by.get_full_name() or obj.approved_by.username
        return None


class ServiceChangeRecordWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceChangeRecord
        fields = [
            'service_instance', 'change_type', 'status',
            'change_reason', 'change_detail',
            'before_spec', 'after_spec',
            'price_delta', 'scheduled_at',
            'reject_reason', 'remark',
        ]


# ═══════════════════════════════════════════════════════════════
# § 6  服务操作日志
# ═══════════════════════════════════════════════════════════════

class ServiceOperationLogSerializer(serializers.ModelSerializer):
    action_type_label = serializers.CharField(source='get_action_type_display', read_only=True)
    operator_name = serializers.SerializerMethodField()
    order_no = serializers.CharField(source='service_order.order_no', read_only=True)
    instance_no = serializers.CharField(source='service_instance.instance_no', read_only=True)

    class Meta:
        model = ServiceOperationLog
        fields = [
            'id', 'action_type', 'action_type_label',
            'description',
            'service_order', 'order_no',
            'service_instance', 'instance_no',
            'old_value', 'new_value',
            'operator', 'operator_name', 'ip_address',
            'created_at',
        ]
        read_only_fields = fields

    def get_operator_name(self, obj):
        if obj.operator:
            return obj.operator.get_full_name() or obj.operator.username
        return '系统'


# ═══════════════════════════════════════════════════════════════
# § 动作专用序列化器
# ═══════════════════════════════════════════════════════════════

class StatusChangeSerializer(serializers.Serializer):
    reason = serializers.CharField(required=False, allow_blank=True, default='')


class ApproveOrderSerializer(serializers.Serializer):
    approved = serializers.BooleanField()
    reject_reason = serializers.CharField(required=False, allow_blank=True, default='')

    def validate(self, data):
        if not data['approved'] and not data.get('reject_reason'):
            raise serializers.ValidationError({'reject_reason': '驳回时必须填写驳回原因'})
        return data


class ChangeStatusSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=ServiceChangeRecord.ChangeStatus.choices)
    reject_reason = serializers.CharField(required=False, allow_blank=True, default='')


class IPManageSerializer(serializers.Serializer):
    ip_ids = serializers.ListField(
        child=serializers.IntegerField(), min_length=1,
        help_text='IPAddress 的 ID 列表',
    )
