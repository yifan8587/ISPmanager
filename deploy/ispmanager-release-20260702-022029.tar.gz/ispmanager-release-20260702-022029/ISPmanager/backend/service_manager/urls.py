from rest_framework.routers import DefaultRouter
from .views import (
    ServicePlanViewSet,
    ServiceOrderViewSet,
    ServiceInstanceViewSet,
    ServiceAllocationViewSet,
    ServiceChangeRecordViewSet,
    ServiceOperationLogViewSet,
)

router = DefaultRouter()
router.register(r'plans', ServicePlanViewSet, basename='serviceplan')
router.register(r'orders', ServiceOrderViewSet, basename='serviceorder')
router.register(r'instances', ServiceInstanceViewSet, basename='serviceinstance')
router.register(r'allocations', ServiceAllocationViewSet, basename='serviceallocation')
router.register(r'changes', ServiceChangeRecordViewSet, basename='servicechange')
router.register(r'logs', ServiceOperationLogViewSet, basename='servicelog')

urlpatterns = router.urls
