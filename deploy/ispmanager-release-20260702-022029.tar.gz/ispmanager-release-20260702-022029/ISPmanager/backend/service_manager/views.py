"""
service_manager/views.py
服务管理模块 DRF ViewSets
"""
from django.utils import timezone
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from accounts.drf_mixins import (
    ServiceModulePermissionMixin,
    CustomerScopedQuerysetMixin,
    ViewOnlyPermissionMixin,
)
from accounts.role_permissions import Perm

from .models import (
    ServicePlan, ServiceOrder, ServiceInstance,
    ServiceAllocation, ServiceChangeRecord, ServiceOperationLog,
    _log_service, service_snapshot,
)
from .serializers import (
    ServicePlanSerializer, ServicePlanBriefSerializer,
    ServiceOrderListSerializer, ServiceOrderDetailSerializer, ServiceOrderWriteSerializer,
    ServiceInstanceListSerializer, ServiceInstanceDetailSerializer, ServiceInstanceWriteSerializer,
    ServiceAllocationSerializer,
    ServiceChangeRecordListSerializer, ServiceChangeRecordDetailSerializer, ServiceChangeRecordWriteSerializer,
    ServiceOperationLogSerializer,
    StatusChangeSerializer, ApproveOrderSerializer, ChangeStatusSerializer, IPManageSerializer,
)


# ─────────────────────────────────────────────────────────────
# 通用 Mixin
# ─────────────────────────────────────────────────────────────

class ServiceLogMixin:
    """统一日志写入辅助"""
    def _log(self, request, action_type, description,
             service_order=None, service_instance=None,
             old_value=None, new_value=None):
        _log_service(
            operator=request.user,
            action_type=action_type,
            description=description,
            service_order=service_order,
            service_instance=service_instance,
            old_value=old_value,
            new_value=new_value,
            request=request,
        )


# ═══════════════════════════════════════════════════════════════
# § 1  服务套餐
# ═══════════════════════════════════════════════════════════════

class ServicePlanViewSet(ServiceModulePermissionMixin, ServiceLogMixin, viewsets.ModelViewSet):
    """
    服务套餐增删改查
    list   GET    /api/service/plans/
    create POST   /api/service/plans/
    retrieve GET  /api/service/plans/{id}/
    update PUT    /api/service/plans/{id}/
    destroy DELETE /api/service/plans/{id}/
    """
    queryset = ServicePlan.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['plan_type', 'billing_cycle', 'is_active']
    search_fields = ['name', 'plan_no', 'description']
    ordering_fields = ['plan_type', 'price', 'created_at']
    ordering = ['plan_type', 'name']

    def get_serializer_class(self):
        if self.action == 'list':
            return ServicePlanSerializer
        if self.action in ['create', 'update', 'partial_update']:
            return ServicePlanSerializer
        return ServicePlanSerializer

    def perform_create(self, serializer):
        obj = serializer.save(created_by=self.request.user)
        self._log(
            self.request,
            ServiceOperationLog.ActionType.OTHER,
            f'创建套餐 [{obj.plan_no}] {obj.name}',
        )

    def perform_destroy(self, instance):
        name = str(instance)
        instance.delete()
        self._log(self.request, ServiceOperationLog.ActionType.OTHER, f'删除套餐 {name}')

    @action(detail=False, methods=['get'], url_path='brief')
    def brief_list(self, request):
        """获取套餐简要列表（用于下拉选择）"""
        qs = self.get_queryset().filter(is_active=True)
        return Response(ServicePlanBriefSerializer(qs, many=True).data)


# ═══════════════════════════════════════════════════════════════
# § 2  服务工单
# ═══════════════════════════════════════════════════════════════

class ServiceOrderViewSet(
    CustomerScopedQuerysetMixin,
    ServiceModulePermissionMixin,
    ServiceLogMixin,
    viewsets.ModelViewSet,
):
    """
    服务工单完整 CRUD + 审批/驳回/统计
    custom actions:
      approve  POST /orders/{id}/approve/    审批或驳回工单
      logs     GET  /orders/{id}/logs/       工单操作日志
      statistics GET /orders/statistics/    工单统计汇总
    """
    extra_read_actions = frozenset({'logs', 'statistics'})

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'order_type', 'customer', 'billing_cycle']
    search_fields = ['order_no', 'customer__name', 'customer__customer_no', 'requirements']
    ordering_fields = ['created_at', 'service_start', 'quoted_price']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = ServiceOrder.objects.select_related(
            'customer', 'contract', 'service_plan', 'created_by', 'approved_by'
        ).prefetch_related('instances')
        return self.apply_customer_scope(qs)

    def get_serializer_class(self):
        if self.action == 'list':
            return ServiceOrderListSerializer
        if self.action in ['create', 'update', 'partial_update']:
            return ServiceOrderWriteSerializer
        return ServiceOrderDetailSerializer

    def perform_create(self, serializer):
        obj = serializer.save(created_by=self.request.user)
        self._log(
            self.request,
            ServiceOperationLog.ActionType.CREATE_ORDER,
            f'创建服务工单 [{obj.order_no}] 客户: {obj.customer.name}',
            service_order=obj,
        )

    def perform_update(self, serializer):
        old = service_snapshot(serializer.instance) if hasattr(serializer.instance, 'instance_no') else {}
        obj = serializer.save()
        self._log(
            self.request,
            ServiceOperationLog.ActionType.OTHER,
            f'更新工单 [{obj.order_no}]',
            service_order=obj,
        )

    def perform_destroy(self, instance):
        if instance.status not in ['draft', 'rejected']:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied('只能删除草稿或已驳回的工单')
        order_no = instance.order_no
        instance.delete()
        self._log(self.request, ServiceOperationLog.ActionType.OTHER, f'删除工单 [{order_no}]')

    @action(detail=True, methods=['post'], url_path='approve')
    def approve(self, request, pk=None):
        """审批或驳回工单"""
        order = self.get_object()
        if order.status != 'pending':
            return Response({'detail': '只有待审批状态的工单才能审批'}, status=status.HTTP_400_BAD_REQUEST)

        serializer = ApproveOrderSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        if data['approved']:
            order.status = 'approved'
            order.approved_by = request.user
            order.approved_at = timezone.now()
            order.save(update_fields=['status', 'approved_by', 'approved_at', 'updated_at'])
            self._log(request, ServiceOperationLog.ActionType.APPROVE_ORDER,
                      f'审批通过工单 [{order.order_no}]', service_order=order)
        else:
            order.status = 'rejected'
            order.reject_reason = data['reject_reason']
            order.save(update_fields=['status', 'reject_reason', 'updated_at'])
            self._log(request, ServiceOperationLog.ActionType.REJECT_ORDER,
                      f'驳回工单 [{order.order_no}] 原因: {data["reject_reason"]}',
                      service_order=order)

        return Response(ServiceOrderDetailSerializer(order, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='submit')
    def submit(self, request, pk=None):
        """提交草稿工单"""
        order = self.get_object()
        if order.status != 'draft':
            return Response({'detail': '只有草稿状态的工单才能提交'}, status=status.HTTP_400_BAD_REQUEST)
        order.status = 'pending'
        order.save(update_fields=['status', 'updated_at'])
        self._log(request, ServiceOperationLog.ActionType.OTHER,
                  f'提交工单 [{order.order_no}] 待审批', service_order=order)
        return Response(ServiceOrderDetailSerializer(order, context={'request': request}).data)

    @action(detail=True, methods=['get'], url_path='logs')
    def logs(self, request, pk=None):
        """获取工单操作日志"""
        order = self.get_object()
        logs = order.operation_logs.order_by('-created_at')
        serializer = ServiceOperationLogSerializer(logs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='statistics')
    def statistics(self, request):
        """工单统计汇总"""
        from django.db.models import Count, Sum
        qs = self.get_queryset()
        by_status = dict(qs.values_list('status').annotate(cnt=Count('id')).order_by())
        by_type = dict(qs.values_list('order_type').annotate(cnt=Count('id')).order_by())
        total_quoted = qs.aggregate(t=Sum('quoted_price'))['t'] or 0
        return Response({
            'total': qs.count(),
            'by_status': by_status,
            'by_order_type': by_type,
            'total_quoted_price': float(total_quoted),
        })


# ═══════════════════════════════════════════════════════════════
# § 3  服务实例
# ═══════════════════════════════════════════════════════════════

class ServiceInstanceViewSet(
    CustomerScopedQuerysetMixin,
    ServiceModulePermissionMixin,
    ServiceLogMixin,
    viewsets.ModelViewSet,
):
    """
    服务实例完整 CRUD + 生命周期操作
    custom actions:
      activate   POST /instances/{id}/activate/
      suspend    POST /instances/{id}/suspend/
      resume     POST /instances/{id}/resume/
      terminate  POST /instances/{id}/terminate/
      assign_ips POST /instances/{id}/assign_ips/    绑定 IP
      release_ips POST /instances/{id}/release_ips/  移除 IP
      logs       GET  /instances/{id}/logs/
      allocations GET /instances/{id}/allocations/   分配记录
      statistics GET /instances/statistics/
    """
    customer_scope_field = 'service_order__customer'
    extra_read_actions = frozenset({'logs', 'statistics', 'allocations'})

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'service_type', 'service_order', 'service_order__customer', 'is_trial']
    search_fields = [
        'instance_no',
        'service_order__order_no',
        'service_order__customer__name',
        'vps__vps_no', 'edge__edge_no',
    ]
    ordering_fields = ['created_at', 'activated_at', 'expire_time']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = ServiceInstance.objects.select_related(
            'service_order__customer',
            'vps', 'edge', 'bandwidth_alloc',
            'provisioned_by', 'terminated_by',
        ).prefetch_related('ip_addresses')
        return self.apply_customer_scope(qs)

    def get_serializer_class(self):
        if self.action == 'list':
            return ServiceInstanceListSerializer
        if self.action in ['create', 'update', 'partial_update']:
            return ServiceInstanceWriteSerializer
        if self.action in ['assign_ips', 'release_ips']:
            return IPManageSerializer
        if self.action in ['activate', 'suspend', 'resume', 'terminate']:
            return StatusChangeSerializer
        return ServiceInstanceDetailSerializer

    def perform_create(self, serializer):
        obj = serializer.save(provisioned_by=self.request.user)
        self._log(
            self.request,
            ServiceOperationLog.ActionType.PROVISION,
            f'创建服务实例 [{obj.instance_no}] 类型: {obj.get_service_type_display()}',
            service_order=obj.service_order,
            service_instance=obj,
        )

    def perform_destroy(self, instance):
        if instance.status not in ['terminated', 'error']:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied('只能删除已终止或故障状态的实例，请先终止服务')
        no = instance.instance_no
        instance.delete()
        self._log(self.request, ServiceOperationLog.ActionType.OTHER, f'删除实例记录 [{no}]')

    # ── 生命周期动作 ──────────────────────────────────────────

    @action(detail=True, methods=['post'], url_path='activate')
    def activate(self, request, pk=None):
        """激活服务实例（同步更新资源）"""
        instance = self.get_object()
        if instance.status not in ['provisioning', 'suspended']:
            return Response({'detail': f'当前状态 [{instance.get_status_display()}] 不允许激活'},
                            status=status.HTTP_400_BAD_REQUEST)
        instance.activate(operator=request.user)
        return Response(ServiceInstanceDetailSerializer(instance, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='suspend')
    def suspend(self, request, pk=None):
        """暂停服务实例"""
        instance = self.get_object()
        if instance.status != 'active':
            return Response({'detail': '只有运行中的实例才能暂停'},
                            status=status.HTTP_400_BAD_REQUEST)
        serializer = StatusChangeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance.suspend(operator=request.user, reason=serializer.validated_data.get('reason', ''))
        return Response(ServiceInstanceDetailSerializer(instance, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='resume')
    def resume(self, request, pk=None):
        """恢复已暂停的实例"""
        instance = self.get_object()
        if instance.status != 'suspended':
            return Response({'detail': '只有已暂停的实例才能恢复'},
                            status=status.HTTP_400_BAD_REQUEST)
        instance.resume(operator=request.user)
        return Response(ServiceInstanceDetailSerializer(instance, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='terminate')
    def terminate(self, request, pk=None):
        """终止服务实例（释放全部资源）"""
        instance = self.get_object()
        if instance.status == 'terminated':
            return Response({'detail': '实例已终止'}, status=status.HTTP_400_BAD_REQUEST)
        serializer = StatusChangeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance.terminate(
            operator=request.user,
            reason=serializer.validated_data.get('reason', ''),
        )
        return Response(ServiceInstanceDetailSerializer(instance, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='convert_to_billing')
    def convert_to_billing(self, request, pk=None):
        """测试服务转入正式计费周期"""
        instance = self.get_object()
        if not instance.is_trial:
            return Response({'detail': '该实例不是测试服务，无需转入'},
                            status=status.HTTP_400_BAD_REQUEST)
        billing_start = request.data.get('billing_start') or None
        if billing_start:
            from datetime import date
            try:
                billing_start = date.fromisoformat(billing_start)
            except (TypeError, ValueError):
                return Response({'detail': '计费起始日格式应为 YYYY-MM-DD'},
                                status=status.HTTP_400_BAD_REQUEST)
        instance.convert_to_billing(operator=request.user, billing_start=billing_start)
        return Response(ServiceInstanceDetailSerializer(instance, context={'request': request}).data)

    # ── IP 管理动作 ───────────────────────────────────────────

    @action(detail=True, methods=['post'], url_path='assign_ips')
    def assign_ips(self, request, pk=None):
        """给实例分配 IP 地址"""
        from resource_manager.models import IPAddress
        instance = self.get_object()
        if instance.status not in ['provisioning', 'active']:
            return Response({'detail': '只有开通中或运行中的实例才能分配 IP'},
                            status=status.HTTP_400_BAD_REQUEST)
        serializer = IPManageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ip_ids = serializer.validated_data['ip_ids']
        ips = IPAddress.objects.filter(id__in=ip_ids, status='available')
        if not ips.exists():
            return Response({'detail': '未找到可分配的 IP（确认 IP 状态为 available）'},
                            status=status.HTTP_400_BAD_REQUEST)
        now = timezone.now()
        for ip in ips:
            ip.status = 'assigned'
            ip.assigned_at = now
            if instance.vps:
                ip.assigned_vps = instance.vps
            if instance.edge:
                ip.assigned_edge = instance.edge
            ip.save(update_fields=['status', 'assigned_at', 'assigned_vps', 'assigned_edge'])
            instance.ip_addresses.add(ip)

        ServiceAllocation.objects.create(
            service_instance=instance,
            action_type=ServiceAllocation.ActionType.IP_ADD,
            description=f'为实例 {instance.instance_no} 分配 {ips.count()} 个 IP',
            resource_type='IPAddress',
            resource_repr=', '.join(ips.values_list('address', flat=True)),
            operator=request.user,
        )
        self._log(request, ServiceOperationLog.ActionType.ASSIGN_IP,
                  f'为实例 [{instance.instance_no}] 分配 IP: {", ".join(ips.values_list("address", flat=True))}',
                  service_order=instance.service_order, service_instance=instance)
        return Response({'detail': f'成功分配 {ips.count()} 个 IP',
                         'ip_count': instance.ip_addresses.count()})

    @action(detail=True, methods=['post'], url_path='release_ips')
    def release_ips(self, request, pk=None):
        """从实例移除（释放）IP 地址"""
        from resource_manager.models import IPAddress
        instance = self.get_object()
        serializer = IPManageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ip_ids = serializer.validated_data['ip_ids']
        ips = instance.ip_addresses.filter(id__in=ip_ids)
        if not ips.exists():
            return Response({'detail': '未找到关联的 IP'}, status=status.HTTP_400_BAD_REQUEST)
        addrs = list(ips.values_list('address', flat=True))
        for ip in ips:
            ip.status = 'available'
            ip.assigned_at = None
            ip.assigned_vps = None
            ip.assigned_edge = None
            ip.save(update_fields=['status', 'assigned_at', 'assigned_vps', 'assigned_edge'])
        instance.ip_addresses.remove(*ips)

        ServiceAllocation.objects.create(
            service_instance=instance,
            action_type=ServiceAllocation.ActionType.IP_REMOVE,
            description=f'从实例 {instance.instance_no} 移除 {len(addrs)} 个 IP',
            resource_type='IPAddress',
            resource_repr=', '.join(addrs),
            operator=request.user,
        )
        self._log(request, ServiceOperationLog.ActionType.RELEASE_IP,
                  f'从实例 [{instance.instance_no}] 释放 IP: {", ".join(addrs)}',
                  service_order=instance.service_order, service_instance=instance)
        return Response({'detail': f'已释放 {len(addrs)} 个 IP',
                         'ip_count': instance.ip_addresses.count()})

    # ── 查询动作 ─────────────────────────────────────────────

    @action(detail=True, methods=['get'], url_path='logs')
    def logs(self, request, pk=None):
        """获取实例操作日志"""
        instance = self.get_object()
        logs = instance.operation_logs.order_by('-created_at')
        return Response(ServiceOperationLogSerializer(logs, many=True).data)

    @action(detail=True, methods=['get'], url_path='allocations')
    def allocations(self, request, pk=None):
        """获取实例资源分配/回收记录"""
        instance = self.get_object()
        allocs = instance.allocations.order_by('-created_at')
        return Response(ServiceAllocationSerializer(allocs, many=True).data)

    @action(detail=False, methods=['get'], url_path='statistics')
    def statistics(self, request):
        """服务实例统计"""
        from django.db.models import Count
        qs = self.get_queryset()
        by_status = dict(qs.values_list('status').annotate(cnt=Count('id')).order_by())
        by_type = dict(qs.values_list('service_type').annotate(cnt=Count('id')).order_by())
        return Response({
            'total': qs.count(),
            'by_status': by_status,
            'by_service_type': by_type,
            'active_count': qs.filter(status='active').count(),
            'expiring_soon': qs.filter(
                status='active',
                expire_time__isnull=False,
                expire_time__lte=timezone.now() + timezone.timedelta(days=30),
            ).count(),
        })


# ═══════════════════════════════════════════════════════════════
# § 4  资源分配记录（只读）
# ═══════════════════════════════════════════════════════════════

class ServiceAllocationViewSet(
    CustomerScopedQuerysetMixin,
    ViewOnlyPermissionMixin,
    viewsets.ReadOnlyModelViewSet,
):
    """
    分配/回收记录只读接口
    list    GET /allocations/
    retrieve GET /allocations/{id}/
    """
    queryset = ServiceAllocation.objects.select_related(
        'service_instance__service_order__customer', 'operator'
    )
    view_permission = Perm.SERVICE_VIEW
    customer_scope_field = 'service_instance__service_order__customer'
    serializer_class = ServiceAllocationSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['action_type', 'resource_type', 'service_instance']
    search_fields = ['description', 'resource_repr', 'service_instance__instance_no']
    ordering_fields = ['created_at']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = ServiceAllocation.objects.select_related(
            'service_instance__service_order__customer', 'operator'
        )
        return self.apply_customer_scope(qs)


# ═══════════════════════════════════════════════════════════════
# § 5  服务变更记录
# ═══════════════════════════════════════════════════════════════

class ServiceChangeRecordViewSet(
    CustomerScopedQuerysetMixin,
    ServiceModulePermissionMixin,
    ServiceLogMixin,
    viewsets.ModelViewSet,
):
    """
    服务变更申请与记录
    custom actions:
      approve  POST /changes/{id}/approve_change/   审批变更
      complete POST /changes/{id}/complete/          标记完成
      cancel   POST /changes/{id}/cancel/            取消变更
    """
    customer_scope_field = 'service_instance__service_order__customer'

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['change_type', 'status', 'service_instance']
    search_fields = [
        'change_no', 'change_reason',
        'service_instance__instance_no',
        'service_instance__service_order__customer__name',
    ]
    ordering_fields = ['created_at', 'scheduled_at']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = ServiceChangeRecord.objects.select_related(
            'service_instance__service_order__customer',
            'requested_by', 'approved_by',
        )
        return self.apply_customer_scope(qs)

    def get_serializer_class(self):
        if self.action == 'list':
            return ServiceChangeRecordListSerializer
        if self.action in ['create', 'update', 'partial_update']:
            return ServiceChangeRecordWriteSerializer
        return ServiceChangeRecordDetailSerializer

    def perform_create(self, serializer):
        obj = serializer.save(requested_by=self.request.user)
        self._log(
            self.request,
            ServiceOperationLog.ActionType.CHANGE,
            f'提交变更申请 [{obj.change_no}] 类型: {obj.get_change_type_display()}',
            service_instance=obj.service_instance,
            service_order=obj.service_instance.service_order,
        )

    @action(detail=True, methods=['post'], url_path='approve_change')
    def approve_change(self, request, pk=None):
        """审批变更申请"""
        record = self.get_object()
        if record.status != 'pending':
            return Response({'detail': '只有待审批的变更才能审批'}, status=status.HTTP_400_BAD_REQUEST)
        s = ChangeStatusSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        new_status = s.validated_data['status']
        if new_status not in ['approved', 'rejected']:
            return Response({'detail': '该接口只接受 approved 或 rejected'},
                            status=status.HTTP_400_BAD_REQUEST)
        record.status = new_status
        if new_status == 'approved':
            record.approved_by = request.user
            record.approved_at = timezone.now()
        else:
            record.reject_reason = s.validated_data.get('reject_reason', '')
        record.save()
        self._log(request, ServiceOperationLog.ActionType.CHANGE,
                  f'变更单 [{record.change_no}] {record.get_status_display()}',
                  service_instance=record.service_instance,
                  service_order=record.service_instance.service_order)
        return Response(ServiceChangeRecordDetailSerializer(record, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='complete')
    def complete(self, request, pk=None):
        """标记变更已完成"""
        record = self.get_object()
        if record.status not in ['approved', 'in_progress']:
            return Response({'detail': '变更必须处于已审批或进行中状态才能完成'},
                            status=status.HTTP_400_BAD_REQUEST)
        record.status = 'completed'
        record.executed_at = timezone.now()
        record.save(update_fields=['status', 'executed_at', 'updated_at'])
        self._log(request, ServiceOperationLog.ActionType.CHANGE,
                  f'变更单 [{record.change_no}] 已完成',
                  service_instance=record.service_instance,
                  service_order=record.service_instance.service_order)
        return Response(ServiceChangeRecordDetailSerializer(record, context={'request': request}).data)

    @action(detail=True, methods=['post'], url_path='cancel')
    def cancel(self, request, pk=None):
        """取消变更申请"""
        record = self.get_object()
        if record.status in ['completed', 'cancelled']:
            return Response({'detail': '已完成或已取消的变更不可再次取消'},
                            status=status.HTTP_400_BAD_REQUEST)
        record.status = 'cancelled'
        record.save(update_fields=['status', 'updated_at'])
        self._log(request, ServiceOperationLog.ActionType.CHANGE,
                  f'取消变更单 [{record.change_no}]',
                  service_instance=record.service_instance,
                  service_order=record.service_instance.service_order)
        return Response(ServiceChangeRecordDetailSerializer(record, context={'request': request}).data)


# ═══════════════════════════════════════════════════════════════
# § 6  服务操作日志（只读）
# ═══════════════════════════════════════════════════════════════

class ServiceOperationLogViewSet(
    CustomerScopedQuerysetMixin,
    ViewOnlyPermissionMixin,
    viewsets.ReadOnlyModelViewSet,
):
    """
    服务操作日志只读接口
    list    GET /logs/
    retrieve GET /logs/{id}/
    """
    queryset = ServiceOperationLog.objects.select_related(
        'operator', 'service_order__customer', 'service_instance'
    )
    view_permission = Perm.SERVICE_VIEW
    customer_scope_field = 'service_order__customer'
    serializer_class = ServiceOperationLogSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['action_type', 'operator', 'service_order', 'service_instance']
    search_fields = ['description', 'service_order__order_no', 'service_instance__instance_no']
    ordering_fields = ['created_at']
    ordering = ['-created_at']

    def get_queryset(self):
        qs = ServiceOperationLog.objects.select_related(
            'operator', 'service_order__customer', 'service_instance'
        )
        return self.apply_customer_scope(qs)
