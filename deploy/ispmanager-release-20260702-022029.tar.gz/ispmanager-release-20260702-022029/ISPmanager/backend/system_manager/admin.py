from django.contrib import admin

from .models import (
    IMChannel, IMMessageLog, NotificationRule, SystemSetting,
)


@admin.register(SystemSetting)
class SystemSettingAdmin(admin.ModelAdmin):
    list_display = ('key', 'label', 'category', 'value_type', 'value', 'is_public', 'is_editable', 'updated_at')
    list_filter = ('category', 'value_type', 'is_public', 'is_editable')
    search_fields = ('key', 'label', 'description')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('category', 'sort_order', 'key')

    def save_model(self, request, obj, form, change):
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(IMChannel)
class IMChannelAdmin(admin.ModelAdmin):
    list_display = ('name', 'channel_type', 'enabled', 'last_test_status', 'last_test_at', 'updated_at')
    list_filter = ('channel_type', 'enabled', 'last_test_status')
    search_fields = ('name', 'remark')
    readonly_fields = ('last_test_at', 'last_test_status', 'last_test_message', 'created_at', 'updated_at')


@admin.register(NotificationRule)
class NotificationRuleAdmin(admin.ModelAdmin):
    list_display = ('name', 'event', 'enabled', 'updated_at')
    list_filter = ('event', 'enabled')
    search_fields = ('name', 'remark')
    filter_horizontal = ('channels',)


@admin.register(IMMessageLog)
class IMMessageLogAdmin(admin.ModelAdmin):
    list_display = ('title', 'channel', 'channel_type', 'event', 'target', 'success', 'created_at')
    list_filter = ('channel_type', 'event', 'success')
    search_fields = ('title', 'content', 'target')
    readonly_fields = tuple(f.name for f in IMMessageLog._meta.fields)
