"""
system_manager/currency_services.py
币种与信誉额汇率换算。

约定（可在「系统设置 → 账单设置」中调整）：
  - 默认结算币种 default_currency，默认 CNY
  - 1 信誉额(CREDIT)  = credit_rate_cny 元人民币（默认 1.0）
  - 1 美元(USD)       = exchange_rate_usd_cny 元人民币（默认 7.2）
  - 人民币(CNY)        = 基准币种

所有换算以人民币(CNY)为中间基准：先把金额折算到 CNY，再折算到目标币种。
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

CNY = 'CNY'
USD = 'USD'
CREDIT = 'CREDIT'

CURRENCY_CHOICES = [
    {'value': CNY, 'label': '人民币', 'symbol': '¥'},
    {'value': USD, 'label': '美元', 'symbol': '$'},
    {'value': CREDIT, 'label': '信誉额', 'symbol': '积分'},
]

_SYMBOL = {CNY: '¥', USD: '$', CREDIT: '积分'}


def _dec(v, default='0') -> Decimal:
    try:
        return Decimal(str(v))
    except Exception:  # noqa: BLE001
        return Decimal(default)


def get_rates() -> dict:
    """读取当前汇率配置（以 1 单位币种折算为多少 CNY 表示）。"""
    from .services import get_setting
    usd = _dec(get_setting('exchange_rate_usd_cny', '7.20'), '7.20')
    credit = _dec(get_setting('credit_rate_cny', '1.00'), '1.00')
    default_currency = get_setting('default_currency', CNY) or CNY
    return {
        'default_currency': default_currency,
        'to_cny': {
            CNY: Decimal('1'),
            USD: usd,
            CREDIT: credit,
        },
    }


def currency_symbol(currency: str) -> str:
    return _SYMBOL.get(currency, currency)


def convert(amount, from_currency: str, to_currency: str, rates: dict | None = None) -> Decimal:
    """把 amount 从 from_currency 换算到 to_currency，保留 2 位小数。"""
    amount = _dec(amount)
    if amount == 0:
        return Decimal('0.00')
    from_currency = (from_currency or CNY).upper()
    to_currency = (to_currency or CNY).upper()
    if from_currency == to_currency:
        return amount.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    table = (rates or get_rates())['to_cny']
    rate_from = table.get(from_currency, Decimal('1'))
    rate_to = table.get(to_currency, Decimal('1'))
    cny = amount * rate_from
    result = cny / rate_to if rate_to else cny
    return result.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def default_currency() -> str:
    from .services import get_setting
    return get_setting('default_currency', CNY) or CNY
