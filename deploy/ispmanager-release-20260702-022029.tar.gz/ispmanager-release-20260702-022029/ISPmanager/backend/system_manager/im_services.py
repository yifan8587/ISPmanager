"""
system_manager/im_services.py
IM 通道发送实现与事件分发：Telegram / 企业微信 / 钉钉 / 自定义 Webhook。

对外主要接口：
  - test_channel(channel)                  发送测试消息并回写测试状态
  - send_to_channel(channel, title, body)  向单个通道（其全部接口人）发送
  - dispatch_event(event, title, body)     按通知规则把变更/异动推送到对应通道
  - notify(event, title, body)             dispatch_event 的安全包装（吞掉异常）
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import time
import urllib.parse

import requests
from django.utils import timezone

from .models import (
    IMChannel, IMChannelType, IMMessageLog, IMTestStatus,
    NotificationRule,
)

logger = logging.getLogger(__name__)

_TIMEOUT = 10


class IMSendError(Exception):
    pass


# ─────────────────────────────────────────────────────────────
# 各平台发送实现：返回 (success: bool, response_text: str)
# ─────────────────────────────────────────────────────────────

def _send_telegram(channel: IMChannel, text: str, target: str) -> tuple[bool, str]:
    if not channel.bot_token:
        return False, '未配置 Bot Token'
    url = f'https://api.telegram.org/bot{channel.bot_token}/sendMessage'
    try:
        resp = requests.post(url, json={'chat_id': target, 'text': text}, timeout=_TIMEOUT)
        ok = resp.status_code == 200 and resp.json().get('ok', False)
        return ok, resp.text[:1000]
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def _wecom_access_token(channel: IMChannel) -> str | None:
    if not (channel.corp_id and channel.corp_secret):
        return None
    url = ('https://qyapi.weixin.qq.com/cgi-bin/gettoken'
           f'?corpid={channel.corp_id}&corpsecret={channel.corp_secret}')
    resp = requests.get(url, timeout=_TIMEOUT)
    return resp.json().get('access_token')


def _send_wecom(channel: IMChannel, text: str, target: str) -> tuple[bool, str]:
    # 优先应用模式（需 corp_id/secret/agent_id），否则走群机器人 webhook
    if channel.corp_id and channel.corp_secret and channel.agent_id:
        try:
            token = _wecom_access_token(channel)
            if not token:
                return False, '获取企业微信 access_token 失败'
            url = f'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={token}'
            payload = {
                'touser': target or '@all',
                'msgtype': 'text',
                'agentid': channel.agent_id,
                'text': {'content': text},
            }
            resp = requests.post(url, json=payload, timeout=_TIMEOUT)
            ok = resp.json().get('errcode') == 0
            return ok, resp.text[:1000]
        except Exception as e:  # noqa: BLE001
            return False, str(e)
    # 群机器人 webhook
    if not channel.webhook_url:
        return False, '未配置 Webhook 或企业应用参数'
    try:
        resp = requests.post(channel.webhook_url, json={'msgtype': 'text', 'text': {'content': text}}, timeout=_TIMEOUT)
        ok = resp.json().get('errcode') == 0
        return ok, resp.text[:1000]
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def _send_dingtalk(channel: IMChannel, text: str, target: str) -> tuple[bool, str]:
    if not channel.webhook_url:
        return False, '未配置 Webhook 地址'
    url = channel.webhook_url
    # 加签
    if channel.secret:
        ts = str(round(time.time() * 1000))
        string_to_sign = f'{ts}\n{channel.secret}'
        hmac_code = hmac.new(channel.secret.encode(), string_to_sign.encode(), hashlib.sha256).digest()
        sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))
        sep = '&' if '?' in url else '?'
        url = f'{url}{sep}timestamp={ts}&sign={sign}'
    at_mobiles = [target] if target else []
    payload = {
        'msgtype': 'text',
        'text': {'content': text},
        'at': {'atMobiles': at_mobiles, 'isAtAll': False},
    }
    try:
        resp = requests.post(url, json=payload, timeout=_TIMEOUT)
        ok = resp.json().get('errcode') == 0
        return ok, resp.text[:1000]
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def _send_webhook(channel: IMChannel, title: str, text: str, target: str) -> tuple[bool, str]:
    if not channel.webhook_url:
        return False, '未配置 Webhook 地址'
    headers = {}
    if channel.secret:
        headers['Authorization'] = channel.secret
    payload = {'title': title, 'content': text, 'target': target}
    try:
        resp = requests.post(channel.webhook_url, json=payload, headers=headers, timeout=_TIMEOUT)
        return 200 <= resp.status_code < 300, resp.text[:1000]
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def _format_text(title: str, body: str) -> str:
    return f'【{title}】\n{body}' if title else body


def _send_one(channel: IMChannel, title: str, body: str, target: str) -> tuple[bool, str]:
    text = _format_text(title, body)
    ct = channel.channel_type
    if ct == IMChannelType.TELEGRAM:
        return _send_telegram(channel, text, target)
    if ct == IMChannelType.WECOM:
        return _send_wecom(channel, text, target)
    if ct == IMChannelType.DINGTALK:
        return _send_dingtalk(channel, text, target)
    if ct == IMChannelType.WEBHOOK:
        return _send_webhook(channel, title, body, target)
    return False, f'未知通道类型 {ct}'


# ─────────────────────────────────────────────────────────────
# 对外接口
# ─────────────────────────────────────────────────────────────

def send_to_channel(channel: IMChannel, title: str, body: str,
                    event: str = '', targets: list[str] | None = None) -> dict:
    """向单个通道（其全部接口人/默认目标）发送消息，记录日志。"""
    target_list = targets if targets is not None else channel.target_list()
    if not target_list:
        target_list = ['']  # 群机器人/webhook 无需指定接收人
    sent, failed = 0, 0
    last_resp = ''
    for target in target_list:
        ok, resp = _send_one(channel, title, body, target)
        last_resp = resp
        IMMessageLog.objects.create(
            channel=channel, channel_type=channel.channel_type, event=event,
            target=target, title=title, content=body, success=ok, response=resp,
        )
        if ok:
            sent += 1
        else:
            failed += 1
    return {'channel': channel.name, 'sent': sent, 'failed': failed, 'last_response': last_resp}


def test_channel(channel: IMChannel) -> dict:
    """发送测试消息并回写测试状态。"""
    result = send_to_channel(
        channel, 'ISP Manager 测试消息',
        '这是一条来自 ISP Manager 的 IM 对接测试消息，如收到说明配置成功。',
        event='custom',
    )
    success = result['sent'] > 0 and result['failed'] == 0
    channel.last_test_at = timezone.now()
    channel.last_test_status = IMTestStatus.SUCCESS if success else IMTestStatus.FAILED
    channel.last_test_message = (result.get('last_response') or '')[:512]
    channel.save(update_fields=['last_test_at', 'last_test_status', 'last_test_message', 'updated_at'])
    return {'success': success, **result}


def dispatch_event(event: str, title: str, body: str) -> dict:
    """按通知规则把某类变更/异动推送到对应 IM 通道。"""
    # 全局 IM 开关
    from .services import get_setting
    if not get_setting('notify_im_enabled', True):
        return {'event': event, 'dispatched': 0, 'disabled': True, 'results': []}
    rules = (NotificationRule.objects
             .filter(event=event, enabled=True)
             .prefetch_related('channels'))
    results = []
    for rule in rules:
        # 规则自定义模板
        text = body
        if rule.template:
            try:
                text = rule.template.format(title=title, content=body)
            except Exception:  # noqa: BLE001
                text = body
        for channel in rule.channels.filter(enabled=True):
            results.append(send_to_channel(channel, title, text, event=event))
    return {'event': event, 'dispatched': len(results), 'results': results}


def notify(event: str, title: str, body: str) -> None:
    """安全包装：用于业务侧/信号触发，绝不因通知失败而影响主流程。"""
    try:
        dispatch_event(event, title, body)
    except Exception:  # noqa: BLE001
        logger.warning('IM 通知发送失败 event=%s', event, exc_info=True)
