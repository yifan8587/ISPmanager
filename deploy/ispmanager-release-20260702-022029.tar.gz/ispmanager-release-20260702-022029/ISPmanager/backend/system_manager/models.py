"""
system_manager/models.py
系统配置项（键值 + 分类 + 类型）
"""
import json

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models


class SystemSetting(models.Model):
    """系统配置项"""

    class Category(models.TextChoices):
        GENERAL = 'general', '基础设置'
        SECURITY = 'security', '安全设置'
        BILLING = 'billing', '账单设置'
        NOTIFICATION = 'notification', '通知设置'
        INTEGRATION = 'integration', '集成设置'

    class ValueType(models.TextChoices):
        STRING = 'string', '字符串'
        TEXT = 'text', '多行文本'
        INTEGER = 'integer', '整数'
        DECIMAL = 'decimal', '小数'
        BOOLEAN = 'boolean', '布尔'
        JSON = 'json', 'JSON'

    key = models.CharField('配置键', max_length=64, unique=True, db_index=True)
    category = models.CharField(
        '分类', max_length=32,
        choices=Category.choices, default=Category.GENERAL,
    )
    label = models.CharField('显示名称', max_length=128)
    description = models.TextField('说明', blank=True, default='')
    value_type = models.CharField(
        '值类型', max_length=16,
        choices=ValueType.choices, default=ValueType.STRING,
    )
    value = models.TextField('配置值', blank=True, default='')
    default_value = models.TextField('默认值', blank=True, default='')
    options = models.JSONField(
        '可选值', null=True, blank=True,
        help_text='下拉选项，如 [{"label":"开启","value":"true"}]',
    )
    sort_order = models.PositiveSmallIntegerField('排序', default=0)
    is_public = models.BooleanField(
        '公开可读', default=False,
        help_text='无需 system.view 权限即可读取（如站点名称）',
    )
    is_editable = models.BooleanField('允许编辑', default=True)
    updated_by = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='最后修改人', related_name='updated_system_settings',
    )
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '系统配置'
        verbose_name_plural = '系统配置'
        ordering = ['category', 'sort_order', 'key']
        indexes = [
            models.Index(fields=['category']),
            models.Index(fields=['is_public']),
        ]

    def __str__(self):
        return f'{self.label} ({self.key})'

    def clean(self):
        try:
            self.get_typed_value()
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            raise ValidationError({'value': f'配置值与类型 {self.value_type} 不匹配：{exc}'}) from exc

    def get_raw_value(self) -> str:
        return self.value if self.value != '' else self.default_value

    def get_typed_value(self):
        raw = self.get_raw_value()
        if self.value_type == self.ValueType.STRING:
            return raw
        if self.value_type == self.ValueType.TEXT:
            return raw
        if self.value_type == self.ValueType.INTEGER:
            return int(raw) if raw != '' else 0
        if self.value_type == self.ValueType.DECIMAL:
            from decimal import Decimal
            return Decimal(raw) if raw != '' else Decimal('0')
        if self.value_type == self.ValueType.BOOLEAN:
            return str(raw).lower() in ('1', 'true', 'yes', 'on')
        if self.value_type == self.ValueType.JSON:
            return json.loads(raw) if raw else {}
        return raw

    @classmethod
    def get_value(cls, key: str, default=None):
        try:
            setting = cls.objects.get(key=key)
        except cls.DoesNotExist:
            return default
        return setting.get_typed_value()

    @classmethod
    def set_value(cls, key: str, value, user=None):
        setting, _ = cls.objects.get_or_create(
            key=key,
            defaults={
                'label': key,
                'category': cls.Category.GENERAL,
                'value_type': cls.ValueType.STRING,
            },
        )
        if setting.value_type == cls.ValueType.BOOLEAN:
            setting.value = 'true' if value else 'false'
        elif setting.value_type == cls.ValueType.JSON:
            setting.value = json.dumps(value, ensure_ascii=False)
        else:
            setting.value = str(value)
        if user:
            setting.updated_by = user
        setting.save(update_fields=['value', 'updated_by', 'updated_at'])
        return setting


# ═══════════════════════════════════════════════════════════════
# § IM 通知对接（Telegram / 企业微信 / 钉钉 / 自定义 Webhook）
# ═══════════════════════════════════════════════════════════════

class IMChannelType(models.TextChoices):
    TELEGRAM = 'telegram', 'Telegram'
    WECOM = 'wecom', '企业微信'
    DINGTALK = 'dingtalk', '钉钉'
    WEBHOOK = 'webhook', '自定义 Webhook'


class IMTestStatus(models.TextChoices):
    NEVER = 'never', '未测试'
    SUCCESS = 'success', '成功'
    FAILED = 'failed', '失败'


class IMChannel(models.Model):
    """IM 通道配置：对接 Telegram / 企业微信 / 钉钉 / 自定义 Webhook。"""

    name = models.CharField('通道名称', max_length=64)
    channel_type = models.CharField('通道类型', max_length=16, choices=IMChannelType.choices)
    enabled = models.BooleanField('启用', default=True)

    # ── 通用 Webhook（企业微信群机器人 / 钉钉群机器人 / 自定义）──
    webhook_url = models.CharField('Webhook 地址', max_length=512, blank=True)
    secret = models.CharField('签名密钥', max_length=256, blank=True,
                              help_text='钉钉加签密钥 / 通用签名（可选）')

    # ── Telegram ──
    bot_token = models.CharField('Telegram Bot Token', max_length=128, blank=True)

    # ── 企业微信应用模式（可选，未填则用 Webhook 群机器人）──
    corp_id = models.CharField('企业ID(CorpID)', max_length=128, blank=True)
    agent_id = models.CharField('应用AgentID', max_length=64, blank=True)
    corp_secret = models.CharField('应用Secret', max_length=256, blank=True)

    # ── 接收目标 ──
    default_target = models.CharField(
        '默认接收标识', max_length=256, blank=True,
        help_text='Telegram=chat_id；企业微信=成员账号(touser)；钉钉=@手机号',
    )
    recipients = models.JSONField(
        '接口人列表', default=list, blank=True,
        help_text='[{"name":"张三","target":"chat_id或touser或手机号"}]',
    )

    # ── 测试状态 ──
    last_test_at = models.DateTimeField('最近测试时间', null=True, blank=True)
    last_test_status = models.CharField('最近测试结果', max_length=16,
                                        choices=IMTestStatus.choices, default=IMTestStatus.NEVER)
    last_test_message = models.CharField('最近测试信息', max_length=512, blank=True)

    remark = models.TextField('备注', blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = 'IM 通道'
        verbose_name_plural = 'IM 通道'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.name} ({self.get_channel_type_display()})'

    def target_list(self) -> list[str]:
        """汇总该通道全部接收目标（接口人 + 默认）。"""
        targets = []
        for r in (self.recipients or []):
            t = (r or {}).get('target') if isinstance(r, dict) else None
            if t:
                targets.append(str(t).strip())
        if self.default_target:
            targets.extend([t.strip() for t in self.default_target.split(',') if t.strip()])
        # 去重保序
        seen, result = set(), []
        for t in targets:
            if t and t not in seen:
                seen.add(t)
                result.append(t)
        return result


class NotificationEvent(models.TextChoices):
    RESOURCE_CHANGE = 'resource_change', '资源异动'
    VPS_CHANGE = 'vps_change', 'VPS 变更'
    PRODUCT_PUBLISH = 'product_publish', '产品发布/上下线'
    SERVICE_CHANGE = 'service_change', '服务变更'
    BILLING_OVERDUE = 'billing_overdue', '账单逾期'
    SUPPLIER_SYNC = 'supplier_sync', '供应商资源同步'
    SYSTEM_ALERT = 'system_alert', '系统告警'
    CUSTOM = 'custom', '自定义/测试'


class NotificationRule(models.Model):
    """通知规则：某类变更/异动事件 → 推送到哪些 IM 通道。"""

    name = models.CharField('规则名称', max_length=64)
    event = models.CharField('触发事件', max_length=32, choices=NotificationEvent.choices)
    enabled = models.BooleanField('启用', default=True)
    channels = models.ManyToManyField(
        IMChannel, related_name='rules', verbose_name='推送通道', blank=True,
    )
    template = models.TextField(
        '消息模板', blank=True,
        help_text='可选，支持占位符 {title} {content}；留空则使用默认格式',
    )
    remark = models.CharField('备注', max_length=256, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '通知规则'
        verbose_name_plural = '通知规则'
        ordering = ['event', '-created_at']

    def __str__(self):
        return f'{self.name} [{self.get_event_display()}]'


class IMMessageLog(models.Model):
    """IM 消息发送日志。"""

    channel = models.ForeignKey(
        IMChannel, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='message_logs', verbose_name='通道',
    )
    channel_type = models.CharField('通道类型', max_length=16, blank=True)
    event = models.CharField('事件', max_length=32, blank=True)
    target = models.CharField('接收目标', max_length=256, blank=True)
    title = models.CharField('标题', max_length=256, blank=True)
    content = models.TextField('内容', blank=True)
    success = models.BooleanField('是否成功', default=False)
    response = models.TextField('响应/错误', blank=True)
    created_at = models.DateTimeField('时间', auto_now_add=True)

    class Meta:
        verbose_name = 'IM 消息日志'
        verbose_name_plural = 'IM 消息日志'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.title} → {self.target} ({"OK" if self.success else "FAIL"})'
