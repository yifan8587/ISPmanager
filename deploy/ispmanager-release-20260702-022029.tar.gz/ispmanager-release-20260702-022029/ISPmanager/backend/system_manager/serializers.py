from rest_framework import serializers

from .models import (
    IMChannel, IMChannelType, IMMessageLog, NotificationEvent, NotificationRule,
    SystemSetting,
)


class SystemSettingSerializer(serializers.ModelSerializer):
    category_label = serializers.CharField(source='get_category_display', read_only=True)
    value_type_label = serializers.CharField(source='get_value_type_display', read_only=True)
    typed_value = serializers.SerializerMethodField()
    updated_by_name = serializers.SerializerMethodField()

    class Meta:
        model = SystemSetting
        fields = (
            'id', 'key', 'category', 'category_label',
            'label', 'description',
            'value_type', 'value_type_label',
            'value', 'default_value', 'typed_value', 'options',
            'sort_order', 'is_public', 'is_editable',
            'updated_by', 'updated_by_name',
            'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'key', 'created_at', 'updated_at')

    def get_typed_value(self, obj):
        try:
            return obj.get_typed_value()
        except Exception:  # noqa: BLE001
            return obj.get_raw_value()

    def get_updated_by_name(self, obj):
        if not obj.updated_by:
            return None
        return obj.updated_by.get_full_name() or obj.updated_by.username


class SystemSettingWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = SystemSetting
        fields = ('value', 'label', 'description', 'sort_order', 'is_public')

    def validate(self, attrs):
        instance = self.instance
        value = attrs.get('value', getattr(instance, 'value', ''))
        value_type = getattr(instance, 'value_type', SystemSetting.ValueType.STRING)
        probe = SystemSetting(value=value, value_type=value_type, default_value=instance.default_value if instance else '')
        try:
            probe.get_typed_value()
        except Exception as exc:  # noqa: BLE001
            raise serializers.ValidationError({'value': f'配置值无效：{exc}'})
        return attrs


class SystemSettingBulkItemSerializer(serializers.Serializer):
    key = serializers.CharField(max_length=64)
    value = serializers.CharField(allow_blank=True)


class SystemSettingBulkUpdateSerializer(serializers.Serializer):
    items = SystemSettingBulkItemSerializer(many=True)

    def validate_items(self, items):
        if not items:
            raise serializers.ValidationError('items 不能为空')
        keys = [i['key'] for i in items]
        existing = set(SystemSetting.objects.filter(key__in=keys).values_list('key', flat=True))
        missing = set(keys) - existing
        if missing:
            raise serializers.ValidationError(f'未知配置键：{", ".join(sorted(missing))}')
        return items


# ═══════════════════════════════════════════════════════════════
# § IM 通知对接
# ═══════════════════════════════════════════════════════════════

class IMChannelSerializer(serializers.ModelSerializer):
    channel_type_label = serializers.CharField(source='get_channel_type_display', read_only=True)
    last_test_status_label = serializers.CharField(source='get_last_test_status_display', read_only=True)
    recipient_count = serializers.SerializerMethodField()
    # 敏感字段写入用，读取时不回显明文
    bot_token = serializers.CharField(required=False, allow_blank=True)
    corp_secret = serializers.CharField(required=False, allow_blank=True)
    secret = serializers.CharField(required=False, allow_blank=True)
    webhook_url = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = IMChannel
        fields = (
            'id', 'name', 'channel_type', 'channel_type_label', 'enabled',
            'webhook_url', 'secret', 'bot_token',
            'corp_id', 'agent_id', 'corp_secret',
            'default_target', 'recipients', 'recipient_count',
            'last_test_at', 'last_test_status', 'last_test_status_label', 'last_test_message',
            'remark', 'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'last_test_at', 'last_test_status',
                            'last_test_message', 'created_at', 'updated_at')
        extra_kwargs = {
            'bot_token': {'write_only': True},
            'corp_secret': {'write_only': True},
            'secret': {'write_only': True},
        }

    def get_recipient_count(self, obj):
        return len(obj.target_list())

    def _keep_secret(self, validated_data):
        """空字符串不覆盖已有密钥。"""
        for f in ('bot_token', 'corp_secret', 'secret'):
            if validated_data.get(f, None) == '':
                validated_data.pop(f, None)

    def update(self, instance, validated_data):
        self._keep_secret(validated_data)
        return super().update(instance, validated_data)

    def validate_recipients(self, value):
        if value in (None, ''):
            return []
        if not isinstance(value, list):
            raise serializers.ValidationError('接口人需为列表')
        cleaned = []
        for item in value:
            if isinstance(item, dict) and item.get('target'):
                cleaned.append({'name': str(item.get('name', '')), 'target': str(item['target'])})
        return cleaned


class NotificationRuleSerializer(serializers.ModelSerializer):
    event_label = serializers.CharField(source='get_event_display', read_only=True)
    channel_names = serializers.SerializerMethodField()

    class Meta:
        model = NotificationRule
        fields = (
            'id', 'name', 'event', 'event_label', 'enabled',
            'channels', 'channel_names', 'template', 'remark',
            'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'created_at', 'updated_at')

    def get_channel_names(self, obj):
        return [{'id': c.id, 'name': c.name, 'channel_type': c.channel_type} for c in obj.channels.all()]


class IMMessageLogSerializer(serializers.ModelSerializer):
    channel_name = serializers.CharField(source='channel.name', read_only=True, allow_null=True)

    class Meta:
        model = IMMessageLog
        fields = (
            'id', 'channel', 'channel_name', 'channel_type', 'event',
            'target', 'title', 'content', 'success', 'response', 'created_at',
        )
        read_only_fields = fields


class SendTestSerializer(serializers.Serializer):
    title = serializers.CharField(required=False, allow_blank=True, default='ISP Manager 通知')
    content = serializers.CharField()


class DispatchEventSerializer(serializers.Serializer):
    event = serializers.ChoiceField(choices=NotificationEvent.choices)
    title = serializers.CharField(required=False, allow_blank=True, default='ISP Manager 通知')
    content = serializers.CharField()
