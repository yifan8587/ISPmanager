"""应用启动时确保内置配置项存在，并监听变更/异动事件转发到 IM。"""
import logging

from django.db.models.signals import post_migrate, post_save
from django.dispatch import receiver

from .default_settings import DEFAULT_SYSTEM_SETTINGS
from .models import SystemSetting

logger = logging.getLogger(__name__)


@receiver(post_migrate)
def ensure_default_settings(sender, **kwargs):
    if sender.name != 'system_manager':
        return
    for item in DEFAULT_SYSTEM_SETTINGS:
        SystemSetting.objects.get_or_create(
            key=item['key'],
            defaults={
                'category': item['category'],
                'label': item['label'],
                'description': item.get('description', ''),
                'value_type': item['value_type'],
                'default_value': item.get('default_value', ''),
                'value': item.get('default_value', ''),
                'options': item.get('options'),
                'is_public': item.get('is_public', False),
                'is_editable': item.get('is_editable', True),
                'sort_order': item.get('sort_order', 0),
            },
        )


# ─────────────────────────────────────────────────────────────
# 变更/异动 → IM 通知转发（全部弱依赖，失败不影响主流程）
# ─────────────────────────────────────────────────────────────

def _safe_notify(event, title, body):
    from . import im_services
    im_services.notify(event, title, body)


def connect_change_signals():
    """在 AppConfig.ready() 中调用，连接其它模块的变更/异动信号。"""
    # 资源异动（ResourceOperationLog）
    try:
        from resource_manager.models import ResourceOperationLog

        @receiver(post_save, sender=ResourceOperationLog, dispatch_uid='im_resource_oplog')
        def _on_resource_oplog(sender, instance, created, **kwargs):
            if not created:
                return
            operator = (instance.operator.get_full_name() or instance.operator.username
                        if instance.operator else '系统')
            body = (f'类型：{instance.get_action_type_display()}\n'
                    f'对象：{instance.target_repr or instance.get_target_model_display()}\n'
                    f'操作人：{operator}\n详情：{instance.description}')
            _safe_notify('resource_change', '资源异动通知', body)
    except Exception:  # noqa: BLE001
        logger.debug('未连接 ResourceOperationLog 信号', exc_info=True)

    # 产品发布/上下线（ProductPublishLog）
    try:
        from product_manager.models import ProductPublishLog

        @receiver(post_save, sender=ProductPublishLog, dispatch_uid='im_product_publish')
        def _on_product_publish(sender, instance, created, **kwargs):
            if not created:
                return
            body = (f'产品：{instance.product.name}（{instance.product.product_no}）\n'
                    f'动作：{instance.get_action_display()}  {instance.from_status} → {instance.to_status}\n'
                    f'{instance.message or ""}')
            _safe_notify('product_publish', '产品发布异动通知', body)
    except Exception:  # noqa: BLE001
        logger.debug('未连接 ProductPublishLog 信号', exc_info=True)

    # 供应商资源同步（SupplierSyncLog）
    try:
        from supplier_manager.models import SupplierSyncLog

        @receiver(post_save, sender=SupplierSyncLog, dispatch_uid='im_supplier_sync')
        def _on_supplier_sync(sender, instance, created, **kwargs):
            if not created:
                return
            body = (f'供应商：{instance.supplier.name}\n'
                    f'动作：{instance.get_action_display()}  结果：{instance.get_result_display()}\n'
                    f'收 {instance.received_count} / 新增 {instance.created_count} / 更新 {instance.updated_count}')
            _safe_notify('supplier_sync', '供应商同步通知', body)
    except Exception:  # noqa: BLE001
        logger.debug('未连接 SupplierSyncLog 信号', exc_info=True)
