from django.db import transaction
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from accounts.drf_mixins import SystemSystemPermissionMixin
from accounts.permissions import ensure_user_profile
from accounts.role_permissions import check_setting_manage_permission

from . import im_services
from .models import (
    IMChannel, IMChannelType, IMMessageLog, NotificationEvent, NotificationRule,
    SystemSetting,
)
from .serializers import (
    DispatchEventSerializer,
    IMChannelSerializer,
    IMMessageLogSerializer,
    NotificationRuleSerializer,
    SendTestSerializer,
    SystemSettingSerializer,
    SystemSettingWriteSerializer,
    SystemSettingBulkUpdateSerializer,
)


class SystemSettingViewSet(SystemSystemPermissionMixin, viewsets.ModelViewSet):
    """
    系统配置 CRUD

    GET  /api/system/settings/              列表
    GET  /api/system/settings/grouped/      按分类分组
    GET  /api/system/settings/public/       公开配置（无需登录）
    POST /api/system/settings/bulk_update/   批量更新
    """
    extra_read_actions = frozenset({'grouped', 'public_settings', 'categories', 'currencies'})

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category', 'value_type', 'is_public', 'is_editable']
    search_fields = ['key', 'label', 'description']
    ordering_fields = ['category', 'sort_order', 'key', 'updated_at']
    ordering = ['category', 'sort_order', 'key']
    http_method_names = ['get', 'head', 'options', 'patch', 'post']

    def get_queryset(self):
        return SystemSetting.objects.select_related('updated_by').all()

    def get_serializer_class(self):
        if self.action in ('partial_update', 'update'):
            return SystemSettingWriteSerializer
        return SystemSettingSerializer

    def create(self, request, *args, **kwargs):
        return Response({'detail': '请通过迁移或后台初始化配置项'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def destroy(self, request, *args, **kwargs):
        obj = self.get_object()
        if not obj.is_editable:
            return Response({'detail': '内置配置项不可删除'}, status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)

    def perform_update(self, serializer):
        if not serializer.instance.is_editable:
            raise PermissionDenied('该配置项不可编辑')
        profile = ensure_user_profile(self.request.user)
        if not check_setting_manage_permission(profile, serializer.instance.key):
            raise PermissionDenied(f'无权修改配置项 {serializer.instance.key}')
        serializer.save(updated_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='grouped')
    def grouped(self, request):
        """按分类返回配置项"""
        qs = self.filter_queryset(self.get_queryset())
        groups = {}
        for setting in qs:
            cat = setting.category
            if cat not in groups:
                groups[cat] = {
                    'category': cat,
                    'category_label': setting.get_category_display(),
                    'items': [],
                }
            groups[cat]['items'].append(SystemSettingSerializer(setting).data)
        ordered = sorted(groups.values(), key=lambda g: g['category'])
        return Response(ordered)

    @action(detail=False, methods=['get'], url_path='categories')
    def categories(self, request):
        return Response([
            {'value': c[0], 'label': c[1]}
            for c in SystemSetting.Category.choices
        ])

    @action(detail=False, methods=['get'], url_path='currencies')
    def currencies(self, request):
        """币种枚举 + 当前汇率（用于账单/产品换算展示）。"""
        from . import currency_services as cs
        rates = cs.get_rates()
        return Response({
            'choices': cs.CURRENCY_CHOICES,
            'default_currency': rates['default_currency'],
            'rates_to_cny': {k: str(v) for k, v in rates['to_cny'].items()},
        })

    @action(
        detail=False, methods=['get'], url_path='public',
        permission_classes=[AllowAny],
        authentication_classes=[],
    )
    def public_settings(self, request):
        """公开配置（站点名称等），登录页可用"""
        qs = SystemSetting.objects.filter(is_public=True).order_by('sort_order')
        data = {
            s.key: SystemSettingSerializer(s).data.get('typed_value')
            for s in qs
        }
        return Response(data)

    @action(detail=False, methods=['post'], url_path='bulk_update')
    def bulk_update(self, request):
        """批量更新配置值"""
        ser = SystemSettingBulkUpdateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        updated = []
        profile = ensure_user_profile(request.user)
        with transaction.atomic():
            for item in ser.validated_data['items']:
                setting = SystemSetting.objects.get(key=item['key'])
                if not setting.is_editable:
                    return Response(
                        {'detail': f'配置项 {setting.key} 不可编辑'},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                if not check_setting_manage_permission(profile, setting.key):
                    return Response(
                        {'detail': f'无权修改配置项 {setting.key}'},
                        status=status.HTTP_403_FORBIDDEN,
                    )
                write_ser = SystemSettingWriteSerializer(
                    setting, data={'value': item['value']}, partial=True,
                )
                write_ser.is_valid(raise_exception=True)
                write_ser.save(updated_by=request.user)
                updated.append(setting.key)
        qs = SystemSetting.objects.filter(key__in=updated).select_related('updated_by')
        return Response(SystemSettingSerializer(qs, many=True).data)


class IMChannelViewSet(SystemSystemPermissionMixin, viewsets.ModelViewSet):
    """IM 通道配置 CRUD + 连接测试 + 发送。

    POST /api/system/im-channels/{id}/test/          发送测试消息
    POST /api/system/im-channels/{id}/send/          向该通道发送自定义消息
    GET  /api/system/im-channels/channel_types/      通道类型枚举
    """
    extra_read_actions = frozenset({'channel_types'})
    queryset = IMChannel.objects.all()
    serializer_class = IMChannelSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['channel_type', 'enabled']
    search_fields = ['name', 'remark']
    ordering = ['-created_at']

    @action(detail=False, methods=['get'], url_path='channel_types')
    def channel_types(self, request):
        return Response([{'value': v, 'label': l} for v, l in IMChannelType.choices])

    @action(detail=True, methods=['post'])
    def test(self, request, pk=None):
        channel = self.get_object()
        return Response(im_services.test_channel(channel))

    @action(detail=True, methods=['post'])
    def send(self, request, pk=None):
        channel = self.get_object()
        ser = SendTestSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        result = im_services.send_to_channel(
            channel, ser.validated_data.get('title') or 'ISP Manager 通知',
            ser.validated_data['content'], event='custom',
        )
        return Response(result)


class NotificationRuleViewSet(SystemSystemPermissionMixin, viewsets.ModelViewSet):
    """通知规则 CRUD：变更/异动事件 → IM 通道路由。

    GET  /api/system/notification-rules/events/      可选事件枚举
    POST /api/system/notification-rules/dispatch/    手动按事件分发一条消息
    """
    extra_read_actions = frozenset({'events'})
    queryset = NotificationRule.objects.prefetch_related('channels').all()
    serializer_class = NotificationRuleSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['event', 'enabled']
    search_fields = ['name', 'remark']

    @action(detail=False, methods=['get'], url_path='events')
    def events(self, request):
        return Response([{'value': v, 'label': l} for v, l in NotificationEvent.choices])

    @action(detail=False, methods=['post'], url_path='dispatch')
    def dispatch_event(self, request):
        ser = DispatchEventSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        result = im_services.dispatch_event(
            ser.validated_data['event'],
            ser.validated_data.get('title') or 'ISP Manager 通知',
            ser.validated_data['content'],
        )
        return Response(result)


class IMMessageLogViewSet(SystemSystemPermissionMixin, viewsets.ReadOnlyModelViewSet):
    """IM 消息发送日志（只读）。"""
    queryset = IMMessageLog.objects.select_related('channel').all()
    serializer_class = IMMessageLogSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['channel', 'channel_type', 'event', 'success']
    search_fields = ['title', 'content', 'target']
    ordering = ['-created_at']


class SystemOverviewViewSet(SystemSystemPermissionMixin, viewsets.ViewSet):
    """GET /api/system/overview/  系统概览（设置模块首页）"""

    extra_read_actions = frozenset({'list'})

    def list(self, request):
        from django.contrib.auth.models import User
        from customer_manager.models import Customer
        from accounts.models import UserProfile

        setting_count = SystemSetting.objects.count()
        user_count = User.objects.filter(is_active=True).count()
        customer_count = Customer.objects.count()
        return Response({
            'setting_count': setting_count,
            'active_user_count': user_count,
            'customer_count': customer_count,
            'account_types': [
                {'value': k, 'label': v, 'count': UserProfile.objects.filter(account_type=k).count()}
                for k, v in UserProfile.AccountType.choices
            ],
        })
