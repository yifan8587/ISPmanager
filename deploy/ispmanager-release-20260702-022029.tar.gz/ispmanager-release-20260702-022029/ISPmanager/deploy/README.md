# ISPmanager / ISPweb 生产部署说明

面向 **Ubuntu 24.04 LTS** 的一体化生产部署方案，包含系统初始化、数据库、自动化打包、部署、SSL 证书全流程。

---

## 一、架构总览

```
                    ┌──────────────────────── nginx (80/443) ────────────────────────┐
                    │                                                                 │
  admin.example.com │  /            → ISPmanager/frontend/dist  (管理端 SPA)          │
                    │  /admin/      → 反代后端 (Django Admin)                          │
                    │  /api/  /ws/  → 反代后端 (REST / WebSocket)                      │
                    │  /static/     → collectstatic (admin/DRF 静态)                   │
                    │  /media/      → 上传文件 / 部署包                                 │
                    │                                                                 │
 portal.example.com │  /            → ISPweb/dist  (客户门户 SPA)                      │
                    │  /admin/ /api/ /ws/ /static/ /media/ → 同上反代后端              │
                    └────────────────────────────┬────────────────────────────────────┘
                                                  │ 127.0.0.1:8000
                                   ┌──────────────▼───────────────┐
                                   │ gunicorn + uvicorn worker     │  systemd: ispmanager.service
                                   │ backend.asgi:application      │  (HTTP + WebSocket)
                                   └──────────────┬───────────────┘
                                                  │
                                            ┌─────▼─────┐
                                            │  MySQL 8  │
                                            └───────────┘
```

- **后端**：Django 6 + DRF + Channels，用 `gunicorn -k uvicorn.workers.UvicornWorker` 运行 ASGI，**同时支持 HTTP 与 WebSocket**（noVNC 控制台 / WebSSH）。
- **前端**：两个独立 SPA（管理端、客户门户），nginx 按域名分站托管，均为 History 路由（`try_files ... /index.html`）。
- **静态资源**：`collectstatic` 汇集 Django admin / DRF / drf-spectacular 静态到 `STATIC_ROOT`，由 nginx 直接托管，**保证 admin 页面完整加载**。
- **接口适配**：前端 API 走同源相对路径 `/api`、WebSocket 走 `/ws`，由 nginx 反代到后端，**天然无跨域**；同时后端支持 `DJANGO_CORS_ALLOWED_ORIGINS` 白名单以兼容独立域名场景。

---

## 二、目录结构

```
ISPmanager/deploy/
├── README.md                       # 本文档
├── .env.example                    # 环境变量模板（cp 为 .env 后修改）
├── scripts/
│   ├── common.sh                   # 公共库（路径探测 / .env 加载 / 日志）
│   ├── 01-init-ubuntu.sh           # ① 初始化 Ubuntu 24.04（nginx/mysql/python/node/certbot）
│   ├── 02-setup-database.sh        # ② 创建 MySQL 数据库与账号
│   ├── build.sh                    # ③ 自动化构建（前端构建 + 后端依赖 + collectstatic）
│   ├── deploy.sh                   # ④ 部署编排（迁移 + systemd + nginx）
│   ├── setup-ssl.sh                # ⑤ 自动申请 Let's Encrypt SSL
│   ├── package.sh                  # 一键打包发布包（生成单个 tar.gz，可快速上传部署）
│   └── manage-service.sh           # 服务管理与一键更新
├── systemd/
│   └── ispmanager.service.template # systemd 服务模板
├── nginx/
│   └── ispmanager.conf.template    # nginx 站点模板（双站点）
└── gunicorn/
    └── gunicorn_conf.py            # gunicorn 生产配置（ASGI worker）
```

---

## 三、前置条件

1. 一台全新的 **Ubuntu 24.04** 服务器，具备 root / sudo 权限。
2. 两个域名（管理端、客户门户）的 **DNS A 记录** 已解析到服务器公网 IP（申请 SSL 必需）。
3. 代码已放置到服务器，且 `ISPmanager` 与 `ISPweb` 为同级目录，例如：
   ```
   /opt/app/ISPmanager
   /opt/app/ISPweb
   ```
   脚本会自动探测项目根目录（deploy 上级的上级）。

---

## 四、部署步骤

> 所有脚本从 `ISPmanager/deploy/scripts/` 目录执行。

### 步骤 0：准备配置

```bash
cd ISPmanager/deploy
cp .env.example .env
# 生成强随机 SECRET_KEY
python3 -c "import secrets;print(secrets.token_urlsafe(64))"
vim .env      # 填写域名、SECRET_KEY、数据库密码、邮箱等
```

**必改项**：`ADMIN_DOMAIN`、`PORTAL_DOMAIN`、`CERTBOT_EMAIL`、`DJANGO_SECRET_KEY`、`DJANGO_ALLOWED_HOSTS`、`DB_PASSWORD`、`MYSQL_ROOT_PASSWORD`。

### 步骤 1：初始化系统

```bash
cd scripts
sudo bash 01-init-ubuntu.sh
```

安装 nginx、MySQL 8、Python 3.12、Node.js 20、certbot、编译依赖，并创建运行用户 `ispmanager`。

（可选）加固 MySQL：`sudo mysql_secure_installation`

### 步骤 2：初始化数据库

```bash
sudo bash 02-setup-database.sh
```

依据 `.env` 创建数据库 `ISPmanager` 与应用账号，并验证连通性。

### 步骤 3：自动化打包

```bash
bash build.sh
# 如需发布归档：BUILD_ARCHIVE=1 bash build.sh
```

创建 venv、安装后端依赖、构建两个前端 `dist`、执行 `collectstatic`。

### 步骤 4：部署应用

```bash
sudo bash deploy.sh
```

生成运行时环境文件 `/etc/ispmanager.env`、执行数据库迁移、安装并启动 `ispmanager.service`、渲染并启用 nginx 站点。完成后即可通过 HTTP 访问：

- 管理端：`http://admin.example.com/`
- 客户门户：`http://portal.example.com/`
- Django 后台：`http://admin.example.com/admin/`
- API 文档：`http://admin.example.com/api/docs/`

### 步骤 5：启用 HTTPS（SSL 证书）

```bash
sudo bash setup-ssl.sh
```

调用 certbot 为两个域名自动申请证书、改写 nginx（追加 443、HTTP→HTTPS 跳转）、注册自动续期。

---

## 四·补充、一键打包（推荐用于跨机部署）

在**开发机/构建机**上一键生成自包含发布包（含后端源码 + 两个前端 `dist` + 部署脚本），上传目标机即可快速部署，**目标机无需安装 Node**。

```bash
cd ISPmanager/deploy/scripts

bash package.sh                    # 构建前端并打包
# 可选：
SKIP_BUILD=1 bash package.sh       # 复用已有 dist，仅打包
OUTPUT_DIR=/tmp bash package.sh    # 指定输出目录
```

生成物：`ispmanager-release-<时间戳>.tar.gz`（默认在 `deploy/` 下）及 `.sha256` 校验和。

发布包内已排除 `venv`、`__pycache__`、`*.pyc`、`.env`、`staticfiles`、`media` 等，解压后目录结构为标准布局（`ISPmanager/` 与 `ISPweb/` 同级），并附带 `QUICKSTART.md`。

**目标机部署（Ubuntu 24.04）：**

```bash
sudo mkdir -p /opt/app
sudo tar -xzf ispmanager-release-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app/ISPmanager/deploy
cp .env.example .env && vim .env          # 配置域名/密钥/数据库
cd scripts
sudo bash 01-init-ubuntu.sh
sudo bash 02-setup-database.sh
SKIP_FRONTEND_BUILD=1 bash build.sh        # 复用预构建 dist，仅装后端依赖+收集静态
sudo bash deploy.sh
sudo bash setup-ssl.sh
```

---

## 五、日常运维

```bash
cd ISPmanager/deploy/scripts

bash manage-service.sh status        # 查看服务状态
sudo bash manage-service.sh restart  # 重启后端
bash manage-service.sh logs          # 跟踪后端日志
bash manage-service.sh migrate       # 数据库迁移
sudo bash manage-service.sh update   # 一键更新（构建+迁移+收集静态+重启）
```

代码更新后的标准流程：

```bash
git pull                    # 或上传新代码
sudo bash manage-service.sh update
```

---

## 六、关键设计说明

### 6.1 Django Admin 完整加载

- `settings.py` 已配置 `STATIC_ROOT`，`build.sh`/`deploy.sh` 均执行 `collectstatic`。
- nginx `location /static/` 指向 `STATIC_ROOT`，`/admin/` 反代后端，**admin 页面样式与交互完整**。

### 6.2 接口适配与跨域

| 场景 | 处理方式 |
|------|----------|
| 前端调用 API | 相对路径 `/api`，nginx 同域反代 → **无跨域** |
| WebSocket | 相对路径 `/ws`，nginx `Upgrade` 反代 → noVNC/WebSSH 正常 |
| 独立域名/跨域访问 | 后端 `DJANGO_CORS_ALLOWED_ORIGINS` 白名单放行 |
| Admin 表单 CSRF | `DJANGO_CSRF_TRUSTED_ORIGINS` 配置 https 域名 |
| HTTPS 识别 | `DJANGO_SECURE_PROXY_SSL_HEADER=True` + nginx 透传 `X-Forwarded-Proto` |

### 6.3 环境变量与安全

- 生产配置全部通过 `/etc/ispmanager.env`（权限 640，属组 `ispmanager`）注入，**不写入代码库**。
- `settings.py` 向后兼容：未设置环境变量时回退开发默认值，本地开发零改动。
- 生产务必设置：`DJANGO_DEBUG=False`、强随机 `DJANGO_SECRET_KEY`、精确的 `DJANGO_ALLOWED_HOSTS`。

### 6.4 WebSocket 与多 worker

Channels 使用 `InMemoryChannelLayer`，本项目 WebSocket 为点对点（VNC/SSH 中继），多 gunicorn worker 可正常工作。若未来引入需跨 worker 广播的实时功能，需切换到 Redis channel layer。

---

## 七、常见问题排查

| 现象 | 排查 |
|------|------|
| 后端启动失败 | `journalctl -u ispmanager -n 50`，多为数据库连接或 SECRET_KEY/依赖问题 |
| admin 无样式 | 确认 `collectstatic` 已执行、`STATIC_ROOT` 权限 `a+rX`、nginx `/static/` alias 正确 |
| 前端刷新 404 | 确认 nginx `try_files $uri $uri/ /index.html`（History 路由） |
| noVNC 连不上 | 确认 nginx `/ws/` 带 `Upgrade`/`Connection` 头、后端以 uvicorn worker 运行 |
| API 401 跨域 | 检查 `DJANGO_CORS_ALLOWED_ORIGINS` 与 `DJANGO_ALLOWED_HOSTS` |
| certbot 失败 | 确认域名 DNS 已解析到本机、80 端口可从公网访问 |

---

## 八、端口与服务清单

| 组件 | 监听 | 说明 |
|------|------|------|
| nginx | 80 / 443 | 对外入口 |
| gunicorn (ispmanager.service) | 127.0.0.1:8000 | 后端 ASGI，仅本机 |
| MySQL | 127.0.0.1:3306 | 数据库，仅本机 |

服务单元：`/etc/systemd/system/ispmanager.service`
运行时环境：`/etc/ispmanager.env`
nginx 站点：`/etc/nginx/sites-available/ispmanager.conf`
