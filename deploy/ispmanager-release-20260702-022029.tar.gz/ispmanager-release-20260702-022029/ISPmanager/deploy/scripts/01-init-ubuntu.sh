#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# 01-init-ubuntu.sh — 初始化 Ubuntu 24.04 生产环境
#   安装 nginx / MySQL 8 / Python 3.12 / Node.js 20 / certbot 及编译依赖
# 用法：sudo bash 01-init-ubuntu.sh
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env
require_root

# ── MySQL 相关辅助函数 ──────────────────────────────────────────
mysql_installed_ok() {
    dpkg -s mysql-server-8.0 2>/dev/null | grep -q '^Status: install ok installed'
}

ensure_mysql_running() {
    if has_systemd; then
        systemctl enable mysql 2>/dev/null || true
        systemctl start mysql 2>/dev/null || systemctl start mysql.service 2>/dev/null || true
    else
        # 无 systemd（容器/WSL）：用 sysv service 或 mysqld_safe 兜底
        service mysql start 2>/dev/null || {
            mkdir -p /var/run/mysqld
            chown mysql:mysql /var/run/mysqld 2>/dev/null || true
            (mysqld_safe --user=mysql >/dev/null 2>&1 &) 
            sleep 5
        }
    fi
}

diagnose_mysql() {
    warn "───── MySQL 诊断信息 ─────"
    echo "· 内存："; free -h 2>/dev/null | sed 's/^/    /' || true
    echo "· 磁盘："; df -h / 2>/dev/null | sed 's/^/    /' || true
    echo "· systemd：$(has_systemd && echo 有 || echo '无（容器/WSL，postinst 可能无法启动服务）')"
    if [[ -f /var/log/mysql/error.log ]]; then
        echo "· /var/log/mysql/error.log 末尾："
        tail -n 20 /var/log/mysql/error.log 2>/dev/null | sed 's/^/    /'
    fi
    if has_systemd; then
        echo "· journalctl -u mysql 末尾："
        journalctl -u mysql -n 20 --no-pager 2>/dev/null | sed 's/^/    /' || true
    fi
    warn "──────────────────────────"
}

install_mysql() {
    # 幂等：已安装并配置成功则直接确保运行
    if mysql_installed_ok; then
        log "mysql-server-8.0 已安装，确保服务运行..."
        ensure_mysql_running
        ok "MySQL 已就绪"
        return 0
    fi

    # 首次尝试安装
    if apt-get install -y mysql-server; then
        ensure_mysql_running
        ok "MySQL 安装并启动完成"
        return 0
    fi

    warn "MySQL 首次配置失败，进入自愈流程..."
    diagnose_mysql

    # 自愈 1：修复数据目录权限（常见于残留 /var/lib/mysql）
    if [[ -d /var/lib/mysql ]]; then
        log "修复 /var/lib/mysql 属主为 mysql:mysql"
        chown -R mysql:mysql /var/lib/mysql 2>/dev/null || true
    fi

    # 自愈 2：先把服务拉起（无 systemd 环境 postinst 常因无法启动而失败）
    ensure_mysql_running

    # 自愈 3：重新配置 + 修依赖
    dpkg --configure -a || true
    apt-get install -f -y || true

    if mysql_installed_ok; then
        ensure_mysql_running
        ok "MySQL 已恢复并配置成功"
        return 0
    fi

    diagnose_mysql
    err "MySQL 自动修复失败。常见原因与处理："
    err "  1) 内存不足：MySQL 8 建议 ≥1GB 内存，可加 swap 后重试本脚本"
    err "  2) 无 systemd（容器）：postinst 无法启动服务；请在支持 systemd 的系统/或手动初始化"
    err "  3) 数据目录残留：sudo rm -rf /var/lib/mysql/* 后重试（会清空数据，谨慎）"
    err "  修复后重新运行：sudo bash 01-init-ubuntu.sh"
    die "MySQL 安装未完成"
}

step "1/7 检查系统版本"
if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    log "检测到系统：$PRETTY_NAME"
    [[ "$VERSION_ID" == "24.04" ]] || warn "本脚本针对 Ubuntu 24.04 编写，当前为 $VERSION_ID，继续执行但请留意兼容性"
fi

export DEBIAN_FRONTEND=noninteractive

step "2/7 修复中断的 dpkg 状态并更新 APT 源"
# 若上一次安装（如 mysql-server）中断，先尝试自愈，使脚本可重复运行
if dpkg --audit 2>/dev/null | grep -q .; then
    warn "检测到未完成配置的软件包，尝试修复 dpkg 状态..."
fi
dpkg --configure -a || true
apt-get install -f -y || true

apt-get update -y
apt-get install -y \
    ca-certificates curl wget gnupg lsb-release \
    build-essential pkg-config git rsync ufw

step "3/7 安装 Python 3.12 与构建 mysqlclient 所需依赖"
apt-get install -y \
    python3 python3-venv python3-dev \
    default-libmysqlclient-dev libssl-dev
log "Python 版本：$(python3 --version)"

step "4/7 安装 Node.js 20 (NodeSource)"
if ! command -v node >/dev/null 2>&1 || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
log "Node 版本：$(node -v)  npm 版本：$(npm -v)"

step "5/7 安装 MySQL Server"
install_mysql

step "6/7 安装 nginx 与 certbot"
apt-get install -y nginx certbot python3-certbot-nginx
if has_systemd; then
    systemctl enable --now nginx || true
else
    service nginx start 2>/dev/null || true
fi
ok "nginx 已安装并启动"

step "7/7 创建运行用户与防火墙规则"
if ! id "$APP_USER" >/dev/null 2>&1; then
    useradd --system --create-home --shell /usr/sbin/nologin "$APP_USER"
    ok "已创建系统用户：$APP_USER"
else
    log "系统用户已存在：$APP_USER"
fi

# 防火墙（若启用 ufw）：放行 SSH / HTTP / HTTPS
if command -v ufw >/dev/null 2>&1; then
    ufw allow OpenSSH >/dev/null 2>&1 || true
    ufw allow 'Nginx Full' >/dev/null 2>&1 || true
    log "已放行 ufw：OpenSSH / Nginx Full（如未启用 ufw 可忽略）"
fi

echo
ok "════════════════════════════════════════════════════"
ok " Ubuntu 24.04 初始化完成"
ok "════════════════════════════════════════════════════"
echo -e "  下一步："
echo -e "   1) 安全加固 MySQL（可选）：sudo mysql_secure_installation"
echo -e "   2) 初始化数据库：       sudo bash 02-setup-database.sh"
echo -e "   3) 打包构建：           bash build.sh"
echo -e "   4) 部署应用：           sudo bash deploy.sh"
