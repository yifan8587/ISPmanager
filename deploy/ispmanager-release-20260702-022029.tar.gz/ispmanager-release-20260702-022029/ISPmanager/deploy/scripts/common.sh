#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# common.sh — 部署脚本公共库（路径探测 / .env 加载 / 日志）
# 由其它脚本 source 引入，不单独执行。
# ════════════════════════════════════════════════════════════════
set -euo pipefail

# ── 路径探测 ────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_DIR="$(dirname "$SCRIPT_DIR")"          # ISPmanager/deploy
ISPMANAGER_DIR="$(dirname "$DEPLOY_DIR")"      # ISPmanager
DETECTED_ROOT="$(dirname "$ISPMANAGER_DIR")"   # 上级（含 ISPmanager 与 ISPweb）

# ── 日志 ────────────────────────────────────────────────────────
c_reset='\033[0m'; c_blue='\033[1;34m'; c_green='\033[1;32m'
c_yellow='\033[1;33m'; c_red='\033[1;31m'
log()  { echo -e "${c_blue}[INFO]${c_reset} $*"; }
ok()   { echo -e "${c_green}[ OK ]${c_reset} $*"; }
warn() { echo -e "${c_yellow}[WARN]${c_reset} $*"; }
err()  { echo -e "${c_red}[FAIL]${c_reset} $*" >&2; }
die()  { err "$*"; exit 1; }

step() { echo -e "\n${c_blue}━━━ $* ━━━${c_reset}"; }

# ── 加载 .env ───────────────────────────────────────────────────
load_env() {
    local env_file="$DEPLOY_DIR/.env"
    if [[ -f "$env_file" ]]; then
        set -a
        # shellcheck disable=SC1090
        source "$env_file"
        set +a
        ok "已加载配置：$env_file"
    else
        warn "未找到 $env_file，使用 .env.example 默认值（生产请先 cp .env.example .env）"
        local example="$DEPLOY_DIR/.env.example"
        [[ -f "$example" ]] && { set -a; source "$example"; set +a; }
    fi

    # 路径默认值
    PROJECT_ROOT="${PROJECT_ROOT:-$DETECTED_ROOT}"
    [[ -z "$PROJECT_ROOT" ]] && PROJECT_ROOT="$DETECTED_ROOT"
    export PROJECT_ROOT

    export BACKEND_DIR="$PROJECT_ROOT/ISPmanager/backend"
    export ADMIN_FRONTEND_DIR="$PROJECT_ROOT/ISPmanager/frontend"
    export PORTAL_FRONTEND_DIR="$PROJECT_ROOT/ISPweb"
    export VENV_DIR="$PROJECT_ROOT/ISPmanager/venv"

    # 关键变量默认值兜底
    export APP_USER="${APP_USER:-ispmanager}"
    export APP_GROUP="${APP_GROUP:-ispmanager}"
    export APP_BIND="${APP_BIND:-127.0.0.1:8000}"
    export GUNICORN_WORKERS="${GUNICORN_WORKERS:-3}"
    export ADMIN_DOMAIN="${ADMIN_DOMAIN:-admin.example.com}"
    export PORTAL_DOMAIN="${PORTAL_DOMAIN:-portal.example.com}"

    # collectstatic 目录默认落在 backend/staticfiles
    export DJANGO_STATIC_ROOT="${DJANGO_STATIC_ROOT:-$BACKEND_DIR/staticfiles}"
    export DJANGO_MEDIA_ROOT="${DJANGO_MEDIA_ROOT:-$BACKEND_DIR/media}"
}

require_root() {
    [[ "$(id -u)" -eq 0 ]] || die "请使用 root 或 sudo 运行：sudo $0"
}

# 是否运行在 systemd 之下（容器/WSL 可能没有）
has_systemd() {
    [[ -d /run/systemd/system ]]
}

# Python 解释器（优先项目 venv）
py() {
    if [[ -x "$VENV_DIR/bin/python" ]]; then
        "$VENV_DIR/bin/python" "$@"
    else
        python3 "$@"
    fi
}

# 是否为「仅 dist、无源码」的预构建前端（发布包典型布局）
frontend_is_prebuilt() {
    local dir="$1"
    [[ -f "$dir/.prebuilt-dist" ]] && return 0
    [[ -f "$dir/dist/index.html" && ! -f "$dir/package.json" ]] && return 0
    return 1
}

# 校验 dist 是否可用
require_frontend_dist() {
    local name="$1"
    local dir="$2"
    [[ -f "$dir/dist/index.html" ]] || die "$name 缺少 dist/index.html：$dir/dist（发布包不完整或尚未构建）"
}
