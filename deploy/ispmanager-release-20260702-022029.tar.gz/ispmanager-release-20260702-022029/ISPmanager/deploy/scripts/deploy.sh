#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# deploy.sh — 部署编排：迁移库 → 生成运行时环境 → systemd → nginx
#   前置：已执行 01-init-ubuntu.sh、02-setup-database.sh、build.sh
# 用法：sudo bash deploy.sh
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env
require_root

RUNTIME_ENV_FILE="/etc/ispmanager.env"
SERVICE_FILE="/etc/systemd/system/ispmanager.service"
NGINX_AVAIL="/etc/nginx/sites-available/ispmanager.conf"
NGINX_ENABLED="/etc/nginx/sites-enabled/ispmanager.conf"

ADMIN_DIST="$ADMIN_FRONTEND_DIR/dist"
PORTAL_DIST="$PORTAL_FRONTEND_DIR/dist"

# ── 前置校验 ────────────────────────────────────────────────────
step "1/8 前置校验"
[[ -x "$VENV_DIR/bin/python" ]] || die "未找到 venv，请先执行 build.sh"
require_frontend_dist "管理端" "$ADMIN_FRONTEND_DIR"
require_frontend_dist "客户门户" "$PORTAL_FRONTEND_DIR"
[[ "$DJANGO_SECRET_KEY" == "CHANGE_ME_TO_A_LONG_RANDOM_STRING" ]] && \
    warn "DJANGO_SECRET_KEY 仍是默认值，强烈建议在 .env 中修改！"
ok "校验通过"

# ── 生成 systemd 运行时环境文件（不含 .example 无关项）───────────
step "2/8 生成运行时环境文件 $RUNTIME_ENV_FILE"
umask 077
cat > "$RUNTIME_ENV_FILE" <<EOF
# 由 deploy.sh 依据 deploy/.env 生成，请勿手工编辑
DJANGO_SETTINGS_MODULE=backend.settings
PYTHONUNBUFFERED=1
DJANGO_SECRET_KEY=${DJANGO_SECRET_KEY}
DJANGO_DEBUG=${DJANGO_DEBUG:-False}
DJANGO_ALLOWED_HOSTS=${DJANGO_ALLOWED_HOSTS}
DJANGO_CSRF_TRUSTED_ORIGINS=${DJANGO_CSRF_TRUSTED_ORIGINS}
DJANGO_CORS_ALLOWED_ORIGINS=${DJANGO_CORS_ALLOWED_ORIGINS}
DJANGO_SECURE_PROXY_SSL_HEADER=${DJANGO_SECURE_PROXY_SSL_HEADER:-True}
DJANGO_STATIC_ROOT=${DJANGO_STATIC_ROOT}
DJANGO_MEDIA_ROOT=${DJANGO_MEDIA_ROOT}
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASSWORD=${DB_PASSWORD}
DB_HOST=${DB_HOST:-127.0.0.1}
DB_PORT=${DB_PORT:-3306}
APP_BIND=${APP_BIND}
GUNICORN_WORKERS=${GUNICORN_WORKERS}
EOF
chmod 640 "$RUNTIME_ENV_FILE"
chown root:"$APP_GROUP" "$RUNTIME_ENV_FILE" 2>/dev/null || true
ok "已生成（权限 640，属组 $APP_GROUP）"

# ── 数据库迁移 + collectstatic（幂等）────────────────────────────
step "3/8 数据库迁移与静态收集"
pushd "$BACKEND_DIR" >/dev/null
set -a; source "$RUNTIME_ENV_FILE"; set +a
"$VENV_DIR/bin/python" manage.py migrate --noinput
mkdir -p "$DJANGO_STATIC_ROOT" "$DJANGO_MEDIA_ROOT"
"$VENV_DIR/bin/python" manage.py collectstatic --noinput
ok "迁移与静态收集完成"

# ── 可选：创建超级管理员 ────────────────────────────────────────
if [[ -n "${DJANGO_SUPERUSER_USERNAME:-}" && -n "${DJANGO_SUPERUSER_PASSWORD:-}" ]]; then
    step "3b/8 创建/更新 Django 超级管理员：$DJANGO_SUPERUSER_USERNAME"
    DJANGO_SUPERUSER_PASSWORD="$DJANGO_SUPERUSER_PASSWORD" \
        "$VENV_DIR/bin/python" manage.py createsuperuser \
        --noinput --username "$DJANGO_SUPERUSER_USERNAME" \
        --email "${DJANGO_SUPERUSER_EMAIL:-admin@example.com}" 2>/dev/null && \
        ok "超级管理员已创建" || \
        log "超级管理员已存在（跳过创建）"
fi
popd >/dev/null

# ── 目录属主与权限 ──────────────────────────────────────────────
step "4/8 设置目录属主"
chown -R "$APP_USER":"$APP_GROUP" "$BACKEND_DIR" 2>/dev/null || true
# nginx 需读取 dist 与 static，放开目录可执行位
chmod -R a+rX "$ADMIN_DIST" "$PORTAL_DIST" "$DJANGO_STATIC_ROOT" "$DJANGO_MEDIA_ROOT" 2>/dev/null || true
ok "属主/权限设置完成"

# ── 渲染并安装 systemd 服务 ─────────────────────────────────────
step "5/8 安装 systemd 服务"
sed -e "s|__APP_USER__|$APP_USER|g" \
    -e "s|__APP_GROUP__|$APP_GROUP|g" \
    -e "s|__BACKEND_DIR__|$BACKEND_DIR|g" \
    -e "s|__VENV_DIR__|$VENV_DIR|g" \
    -e "s|__DEPLOY_DIR__|$DEPLOY_DIR|g" \
    -e "s|__RUNTIME_ENV_FILE__|$RUNTIME_ENV_FILE|g" \
    "$DEPLOY_DIR/systemd/ispmanager.service.template" > "$SERVICE_FILE"
systemctl daemon-reload
systemctl enable ispmanager.service >/dev/null 2>&1 || true
systemctl restart ispmanager.service
sleep 2
if systemctl is-active --quiet ispmanager.service; then
    ok "后端服务已启动（ispmanager.service）"
else
    err "后端服务启动失败，查看日志：journalctl -u ispmanager -n 50"
    journalctl -u ispmanager -n 20 --no-pager || true
    die "部署中断"
fi

# ── 渲染并安装 nginx 配置 ───────────────────────────────────────
step "6/8 安装 nginx 站点配置"
sed -e "s|__ADMIN_DOMAIN__|$ADMIN_DOMAIN|g" \
    -e "s|__PORTAL_DOMAIN__|$PORTAL_DOMAIN|g" \
    -e "s|__ADMIN_DIST__|$ADMIN_DIST|g" \
    -e "s|__PORTAL_DIST__|$PORTAL_DIST|g" \
    -e "s|__STATIC_ROOT__|$DJANGO_STATIC_ROOT|g" \
    -e "s|__MEDIA_ROOT__|$DJANGO_MEDIA_ROOT|g" \
    -e "s|__APP_BIND__|$APP_BIND|g" \
    "$DEPLOY_DIR/nginx/ispmanager.conf.template" > "$NGINX_AVAIL"
ln -sf "$NGINX_AVAIL" "$NGINX_ENABLED"
# 移除默认站点避免冲突
[[ -e /etc/nginx/sites-enabled/default ]] && rm -f /etc/nginx/sites-enabled/default

step "7/8 校验并重载 nginx"
if nginx -t; then
    systemctl reload nginx
    ok "nginx 配置生效"
else
    die "nginx 配置校验失败，请检查 $NGINX_AVAIL"
fi

# ── 完成 ────────────────────────────────────────────────────────
step "8/8 部署完成"
echo
ok "════════════════════════════════════════════════════"
ok " 部署成功"
ok "════════════════════════════════════════════════════"
echo -e "  管理端：   http://$ADMIN_DOMAIN/"
echo -e "  客户门户： http://$PORTAL_DOMAIN/"
echo -e "  Django后台：http://$ADMIN_DOMAIN/admin/"
echo -e "  API 文档： http://$ADMIN_DOMAIN/api/docs/"
echo
echo -e "  下一步（启用 HTTPS）： sudo bash setup-ssl.sh"
echo -e "  服务管理：            bash manage-service.sh {status|restart|logs}"
