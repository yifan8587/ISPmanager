#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# manage-service.sh — 后端服务与部署便捷管理
# 用法：
#   bash manage-service.sh status        查看后端 + nginx 状态
#   bash manage-service.sh restart       重启后端
#   bash manage-service.sh reload        平滑重载后端（HUP）
#   bash manage-service.sh stop|start    停止/启动后端
#   bash manage-service.sh logs          跟踪后端日志
#   bash manage-service.sh migrate       执行数据库迁移
#   bash manage-service.sh collectstatic 重新收集静态资源
#   sudo bash manage-service.sh update   拉起「构建 + 迁移 + 重启」一键更新
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env

ACTION="${1:-status}"
SVC="ispmanager.service"
RUNTIME_ENV_FILE="/etc/ispmanager.env"

run_manage() {
    pushd "$BACKEND_DIR" >/dev/null
    [[ -f "$RUNTIME_ENV_FILE" ]] && { set -a; source "$RUNTIME_ENV_FILE"; set +a; }
    "$VENV_DIR/bin/python" manage.py "$@"
    popd >/dev/null
}

case "$ACTION" in
    status)
        systemctl status "$SVC" --no-pager || true
        echo; systemctl status nginx --no-pager | head -n 6 || true
        ;;
    start|stop|restart|reload)
        require_root
        systemctl "$ACTION" "$SVC"
        ok "已 $ACTION $SVC"
        ;;
    logs)
        journalctl -u "$SVC" -f
        ;;
    migrate)
        run_manage migrate --noinput
        ;;
    collectstatic)
        run_manage collectstatic --noinput
        ;;
    update)
        require_root
        step "一键更新：构建 → 迁移 → 收集静态 → 重启"
        sudo -u "${SUDO_USER:-root}" bash "$SCRIPT_DIR/build.sh" || bash "$SCRIPT_DIR/build.sh"
        run_manage migrate --noinput
        run_manage collectstatic --noinput
        systemctl restart "$SVC"
        systemctl reload nginx
        ok "更新完成"
        ;;
    *)
        die "未知操作：$ACTION（可用 status|start|stop|restart|reload|logs|migrate|collectstatic|update）"
        ;;
esac
