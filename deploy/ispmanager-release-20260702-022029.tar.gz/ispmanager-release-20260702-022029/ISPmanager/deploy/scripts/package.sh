#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# package.sh — 一键打包发布包
#   构建两个前端 → 收集部署所需文件/文件夹 → 生成单个 tar.gz
#   解压后目录结构即为标准布局（ISPmanager/ 与 ISPweb/ 同级），
#   可直接上传服务器快速部署。
#
# 用法：
#   bash package.sh                     # 构建前端并打包
#   SKIP_BUILD=1 bash package.sh        # 复用已存在的 dist，仅打包
#   OUTPUT_DIR=/tmp bash package.sh     # 指定输出目录
#
# 打进包里的内容：
#   ISPmanager/backend      后端源码（排除 venv / __pycache__ / media / staticfiles / *.pyc）
#   ISPmanager/frontend/dist 管理端构建产物
#   ISPmanager/deploy       全部部署脚本与配置（排除 .env 与历史归档）
#   ISPweb/dist             客户门户构建产物
#   QUICKSTART.md           解压后快速部署指引
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env

SKIP_BUILD="${SKIP_BUILD:-0}"
OUTPUT_DIR="${OUTPUT_DIR:-$DEPLOY_DIR}"
TS="$(date +%Y%m%d-%H%M%S)"
RELEASE_NAME="ispmanager-release-$TS"
STAGE="$(mktemp -d)"
RELEASE_ROOT="$STAGE/$RELEASE_NAME"
ARCHIVE="$OUTPUT_DIR/$RELEASE_NAME.tar.gz"

cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

# ── 1. 构建前端 ─────────────────────────────────────────────────
step "1/4 构建前端产物"
if [[ "$SKIP_BUILD" == "1" ]]; then
    log "SKIP_BUILD=1：跳过构建，复用现有 dist"
else
    command -v npm >/dev/null 2>&1 || die "未找到 npm，无法构建前端（或设 SKIP_BUILD=1 复用现有 dist）"
    for spec in "管理端:$ADMIN_FRONTEND_DIR" "客户门户:$PORTAL_FRONTEND_DIR"; do
        name="${spec%%:*}"
        d="${spec#*:}"
        [[ -d "$d" ]] || { warn "目录不存在，跳过：$d"; continue; }
        [[ -f "$d/package.json" ]] || die "$name 缺少 package.json：$d/package.json"
        [[ -f "$d/index.html" ]] || die "$name 缺少 index.html：$d/index.html"
        log "构建：$d"
        pushd "$d" >/dev/null
        if [[ -f package-lock.json ]]; then npm ci || npm install; else npm install; fi
        npm run build
        popd >/dev/null
    done
fi

require_frontend_dist "管理端" "$ADMIN_FRONTEND_DIR"
require_frontend_dist "客户门户" "$PORTAL_FRONTEND_DIR"
ok "前端产物就绪"

# ── 2. 收集部署文件到暂存目录 ───────────────────────────────────
step "2/4 收集部署文件"
mkdir -p "$RELEASE_ROOT/ISPmanager/frontend" "$RELEASE_ROOT/ISPweb"

# 后端源码 + deploy（用 tar 管道复制并应用排除规则）
log "打包后端源码与 deploy 配置..."
tar -cf - -C "$PROJECT_ROOT/ISPmanager" \
    --exclude='venv' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='*.pyo' \
    --exclude='.git' \
    --exclude='backend/staticfiles' \
    --exclude='backend/media' \
    --exclude='backend/*.sqlite3' \
    --exclude='backend/db.sqlite3' \
    --exclude='deploy/.env' \
    --exclude='deploy/*.tar.gz' \
    --exclude='deploy/build' \
    backend deploy \
    | tar -xf - -C "$RELEASE_ROOT/ISPmanager"

# 前端构建产物（仅 dist + 预构建标记，不含源码/node_modules）
log "复制管理端 dist..."
mkdir -p "$RELEASE_ROOT/ISPmanager/frontend/dist"
cp -r "$ADMIN_FRONTEND_DIR/dist/." "$RELEASE_ROOT/ISPmanager/frontend/dist/"
cat > "$RELEASE_ROOT/ISPmanager/frontend/.prebuilt-dist" <<EOF
# 由 package.sh 生成：本目录为预构建发布包，仅含 dist，不含 package.json / 源码。
# 目标机执行 build.sh 时会自动跳过 npm build，直接复用 dist。
packaged_at=$(date -Iseconds)
admin_dist_files=$(find "$RELEASE_ROOT/ISPmanager/frontend/dist" -type f | wc -l)
EOF

log "复制门户 dist..."
mkdir -p "$RELEASE_ROOT/ISPweb/dist"
cp -r "$PORTAL_FRONTEND_DIR/dist/." "$RELEASE_ROOT/ISPweb/dist/"
cat > "$RELEASE_ROOT/ISPweb/.prebuilt-dist" <<EOF
# 由 package.sh 生成：预构建客户门户 dist
packaged_at=$(date -Iseconds)
portal_dist_files=$(find "$RELEASE_ROOT/ISPweb/dist" -type f | wc -l)
EOF

# 保留一份 requirements 便于查看（源已含于 backend）
ok "文件收集完成"

# ── 3. 生成解压后快速部署指引 ───────────────────────────────────
step "3/4 生成 QUICKSTART.md"
cat > "$RELEASE_ROOT/QUICKSTART.md" <<'QS'
# 快速部署指引（发布包）

本压缩包已包含：后端源码、两个前端构建产物（dist）、全部部署脚本。
目标服务器：Ubuntu 24.04。前端已预构建，**目标机无需 Node**。

## 步骤

```bash
# 1) 解压（假设上传到 /opt）
sudo mkdir -p /opt/app && sudo tar -xzf ispmanager-release-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app/ISPmanager/deploy

# 2) 准备配置
cp .env.example .env
python3 -c "import secrets;print(secrets.token_urlsafe(64))"   # 生成 SECRET_KEY
vim .env            # 填域名 / SECRET_KEY / 数据库密码 / 邮箱

cd scripts

# 3) 初始化系统（nginx / mysql / python，前端已预构建可不装 node）
sudo bash 01-init-ubuntu.sh

# 4) 初始化数据库
sudo bash 02-setup-database.sh

# 5) 安装后端依赖 + 收集静态（发布包已含 dist，build.sh 会自动跳过前端 npm build）
bash build.sh

# 6) 部署（迁移 + systemd + nginx）
sudo bash deploy.sh

# 7) 启用 HTTPS（域名 DNS 需已解析到本机）
sudo bash setup-ssl.sh
```

详见 `ISPmanager/deploy/README.md`。
QS
ok "QUICKSTART.md 生成完成"

# ── 4. 打包压缩 ─────────────────────────────────────────────────
step "4/4 生成压缩包"
mkdir -p "$OUTPUT_DIR"
tar -czf "$ARCHIVE" -C "$STAGE" "$RELEASE_NAME"

# 校验和
if command -v sha256sum >/dev/null 2>&1; then
    ( cd "$OUTPUT_DIR" && sha256sum "$(basename "$ARCHIVE")" > "$ARCHIVE.sha256" )
fi

SIZE="$(du -h "$ARCHIVE" | cut -f1)"
echo
ok "════════════════════════════════════════════════════"
ok " 打包完成"
ok "════════════════════════════════════════════════════"
echo -e "  发布包： $ARCHIVE  ($SIZE)"
[[ -f "$ARCHIVE.sha256" ]] && echo -e "  校验和： $ARCHIVE.sha256"
echo -e "  内容：   ISPmanager(backend+frontend/dist+deploy) + ISPweb/dist + QUICKSTART.md"
echo
echo -e "  上传示例： scp \"$ARCHIVE\" user@server:/opt/"
echo -e "  部署：     解压后见包内 QUICKSTART.md（或 deploy/README.md）"
