#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# setup-ssl.sh — 使用 certbot 为两个域名自动申请并安装 Let's Encrypt SSL
#   前置：deploy.sh 已完成，且两个域名的 DNS A 记录已解析到本机公网 IP
#   自动配置 nginx 443、HTTP→HTTPS 跳转，并注册自动续期
# 用法：
#   sudo bash setup-ssl.sh                # 为 ADMIN_DOMAIN 与 PORTAL_DOMAIN 申请
#   sudo bash setup-ssl.sh admin.x.com    # 仅为指定域名申请
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env
require_root

command -v certbot >/dev/null 2>&1 || die "未找到 certbot，请先执行 01-init-ubuntu.sh"

# 确定要申请的域名列表
DOMAINS=()
if [[ $# -gt 0 ]]; then
    DOMAINS=("$@")
else
    [[ "$ADMIN_DOMAIN"  != "admin.example.com"  ]] && DOMAINS+=("$ADMIN_DOMAIN")
    [[ "$PORTAL_DOMAIN" != "portal.example.com" ]] && DOMAINS+=("$PORTAL_DOMAIN")
fi
[[ ${#DOMAINS[@]} -gt 0 ]] || die "未指定有效域名，请在 .env 配置 ADMIN_DOMAIN/PORTAL_DOMAIN 或作为参数传入"

EMAIL="${CERTBOT_EMAIL:-}"
[[ -z "$EMAIL" || "$EMAIL" == "admin@example.com" ]] && \
    warn "CERTBOT_EMAIL 未正确配置，将使用 --register-unsafely-without-email"

step "为以下域名申请 SSL 证书"
printf '  - %s\n' "${DOMAINS[@]}"

# 组装 -d 参数
D_ARGS=()
for d in "${DOMAINS[@]}"; do D_ARGS+=(-d "$d"); done

# 邮箱参数
if [[ -n "$EMAIL" && "$EMAIL" != "admin@example.com" ]]; then
    MAIL_ARGS=(--email "$EMAIL" --no-eff-email)
else
    MAIL_ARGS=(--register-unsafely-without-email)
fi

step "调用 certbot --nginx（自动改写 nginx 配置并加 443）"
certbot --nginx \
    "${D_ARGS[@]}" \
    "${MAIL_ARGS[@]}" \
    --agree-tos \
    --redirect \
    --non-interactive \
    --keep-until-expiring

step "校验并重载 nginx"
nginx -t && systemctl reload nginx
ok "nginx 已应用 HTTPS 配置"

step "配置自动续期"
# certbot 的 systemd timer 通常已启用；这里显式确保并测试续期
systemctl enable --now certbot.timer 2>/dev/null || true
if certbot renew --dry-run >/dev/null 2>&1; then
    ok "证书自动续期测试通过（certbot.timer 已启用）"
else
    warn "续期 dry-run 未通过，请稍后手动执行：sudo certbot renew --dry-run"
fi

echo
ok "════════════════════════════════════════════════════"
ok " SSL 证书部署完成"
ok "════════════════════════════════════════════════════"
for d in "${DOMAINS[@]}"; do
    echo -e "  https://$d/"
done
echo -e "  证书续期由 certbot.timer 每日自动检查（到期前 30 天续签）"
