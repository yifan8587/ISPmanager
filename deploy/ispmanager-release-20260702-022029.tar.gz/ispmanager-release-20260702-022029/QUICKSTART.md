# 快速部署指引（发布包）

本压缩包已包含：后端源码、两个前端构建产物（dist）、全部部署脚本。
目标服务器：Ubuntu 24.04。前端已预构建，**目标机无需 Node**。

## 步骤

```bash
# 1) 解压（假设上传到 /opt）
sudo mkdir -p /opt/app && sudo tar -xzf ispmanager-release-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app/ISPmanager/deploy

# 2) 准备配置
cp .env.example .env
python3 -c "import secrets;print(secrets.token_urlsafe(64))"   # 生成 SECRET_KEY
vim .env            # 填域名 / SECRET_KEY / 数据库密码 / 邮箱

cd scripts

# 3) 初始化系统（nginx / mysql / python，前端已预构建可不装 node）
sudo bash 01-init-ubuntu.sh

# 4) 初始化数据库
sudo bash 02-setup-database.sh

# 5) 安装后端依赖 + 收集静态（发布包已含 dist，build.sh 会自动跳过前端 npm build）
bash build.sh

# 6) 部署（迁移 + systemd + nginx）
sudo bash deploy.sh

# 7) 启用 HTTPS（域名 DNS 需已解析到本机）
sudo bash setup-ssl.sh
```

详见 `ISPmanager/deploy/README.md`。
