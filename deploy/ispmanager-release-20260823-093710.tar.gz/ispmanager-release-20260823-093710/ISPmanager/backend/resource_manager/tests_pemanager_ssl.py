"""S-M7：节点 HTTPS 校验默认跟随 settings。"""
from django.test import SimpleTestCase, override_settings

from resource_manager.pemanager_client import PemanagerClient


class PemanagerSslVerifyTests(SimpleTestCase):
    @override_settings(PEMANAGER_SSL_VERIFY=True)
    def test_default_follows_settings_true(self):
        client = PemanagerClient('https://node.example', 'u', 'p')
        self.assertTrue(client.verify)

    @override_settings(PEMANAGER_SSL_VERIFY=False)
    def test_default_follows_settings_false(self):
        client = PemanagerClient('https://node.example', 'u', 'p')
        self.assertFalse(client.verify)

    @override_settings(PEMANAGER_SSL_VERIFY=True)
    def test_explicit_false_overrides_settings(self):
        client = PemanagerClient('https://node.example', 'u', 'p', verify=False)
        self.assertFalse(client.verify)
