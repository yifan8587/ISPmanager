from django.apps import AppConfig


class CustomerManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'customer_manager'
    verbose_name = '客户管理'
