"""
product_manager/serializers.py
产品管理模块 DRF 序列化器
"""
from rest_framework import serializers

from . import services
from .models import (
    AccelType, Product, ProductCategory, ProductPublishLog, ProductSpec,
    ProductTemplate, ProductUpgradeRule, TemplatePricing,
)


# 规格按两类（VPS / 边缘加速）归一与校验
class SpecValidateMixin:
    """根据 category 归一规格字段：
      - VPS    ：CPU / 内存 / 硬盘 / 网卡 / 带宽 / IP，清空加速类型
      - 边缘加速：仅 带宽 / IP（+ 加速类型），CPU/内存/硬盘/网卡 置 0
    """

    def _resolve_category(self, attrs):
        if attrs.get('category'):
            return attrs['category']
        if self.instance is not None:
            return self.instance.category
        return ProductCategory.VPS

    def validate(self, attrs):
        attrs = super().validate(attrs)
        category = self._resolve_category(attrs)
        if category == ProductCategory.EDGE:
            if 'accel_type' in attrs and not attrs.get('accel_type'):
                raise serializers.ValidationError({'accel_type': '边缘加速必须选择加速类型'})
            if self.instance is None and not attrs.get('accel_type'):
                raise serializers.ValidationError({'accel_type': '边缘加速必须选择加速类型'})
            for f in ('cpu_cores', 'ram_mb', 'disk_gb', 'nic_count'):
                attrs[f] = 0
        else:
            attrs['accel_type'] = ''
        return attrs


# ═══════════════════════════════════════════════════════════════
# § 产品规格
# ═══════════════════════════════════════════════════════════════

class ProductSpecSerializer(SpecValidateMixin, serializers.ModelSerializer):
    category_label = serializers.CharField(source='get_category_display', read_only=True)
    accel_type_label = serializers.CharField(source='get_accel_type_display', read_only=True)
    pop_name = serializers.CharField(source='pop_point.name', read_only=True, allow_null=True)
    supplier_name = serializers.CharField(source='supplier.name', read_only=True, allow_null=True)

    class Meta:
        model = ProductSpec
        fields = [
            'id', 'spec_no', 'name', 'category', 'category_label',
            'pop_point', 'pop_name', 'supplier', 'supplier_name',
            'cpu_cores', 'ram_mb', 'disk_gb', 'nic_count', 'bandwidth_mbps', 'ip_count',
            'accel_type', 'accel_type_label',
            'is_active', 'remark', 'created_at', 'updated_at',
        ]
        read_only_fields = ['spec_no', 'created_at', 'updated_at']


# ═══════════════════════════════════════════════════════════════
# § 产品模版 + 定价
# ═══════════════════════════════════════════════════════════════

class TemplatePricingSerializer(serializers.ModelSerializer):
    pop_name = serializers.CharField(source='pop_point.name', read_only=True)
    pop_code = serializers.CharField(source='pop_point.code', read_only=True)

    class Meta:
        model = TemplatePricing
        fields = [
            'id', 'template', 'pop_point', 'pop_name', 'pop_code',
            'monthly_price', 'reputation_price', 'setup_price', 'currency',
            'is_active', 'created_at', 'updated_at',
        ]
        read_only_fields = ['created_at', 'updated_at']


class ProductTemplateSerializer(SpecValidateMixin, serializers.ModelSerializer):
    category_label = serializers.CharField(source='get_category_display', read_only=True)
    accel_type_label = serializers.CharField(source='get_accel_type_display', read_only=True)
    pricings = TemplatePricingSerializer(many=True, read_only=True)

    class Meta:
        model = ProductTemplate
        fields = [
            'id', 'template_no', 'name', 'category', 'category_label', 'spec',
            'cpu_cores', 'ram_mb', 'disk_gb', 'nic_count', 'bandwidth_mbps', 'ip_count',
            'accel_type', 'accel_type_label',
            'is_active', 'description', 'pricings', 'created_at', 'updated_at',
        ]
        read_only_fields = ['template_no', 'created_at', 'updated_at']


# ═══════════════════════════════════════════════════════════════
# § 阶梯升级规则
# ═══════════════════════════════════════════════════════════════

class ProductUpgradeRuleSerializer(serializers.ModelSerializer):
    resource_kind_label = serializers.CharField(source='get_resource_kind_display', read_only=True)

    class Meta:
        model = ProductUpgradeRule
        fields = [
            'id', 'product', 'resource_kind', 'resource_kind_label',
            'min_qty', 'max_qty', 'unit_price', 'unit_reputation',
            'is_active', 'created_at',
        ]
        read_only_fields = ['created_at']


# ═══════════════════════════════════════════════════════════════
# § 产品
# ═══════════════════════════════════════════════════════════════

class ProductListSerializer(serializers.ModelSerializer):
    category_label = serializers.CharField(source='get_category_display', read_only=True)
    status_label = serializers.CharField(source='get_status_display', read_only=True)
    pop_name = serializers.CharField(source='pop_point.name', read_only=True)
    pop_code = serializers.CharField(source='pop_point.code', read_only=True)
    supplier_name = serializers.CharField(source='supplier.name', read_only=True, allow_null=True)
    template_name = serializers.CharField(source='template.name', read_only=True, allow_null=True)
    # ── POP 网络属性（用于前端筛选/展示）────────────────────────
    network_type = serializers.CharField(source='pop_point.network_type', read_only=True)
    network_type_label = serializers.CharField(source='pop_point.get_network_type_display', read_only=True)
    asn_nature = serializers.CharField(source='pop_point.asn_nature', read_only=True)
    asn_nature_label = serializers.CharField(source='pop_point.get_asn_nature_display', read_only=True)
    # ── 区域 / 国家 / 城市 ──────────────────────────────────────
    city_name = serializers.CharField(source='pop_point.city.name', read_only=True, allow_null=True)
    country_name = serializers.CharField(source='pop_point.city.country.name', read_only=True, allow_null=True)
    region_name = serializers.CharField(source='pop_point.city.country.region.name', read_only=True, allow_null=True)
    region_id = serializers.IntegerField(source='pop_point.city.country.region_id', read_only=True, allow_null=True)
    country_id = serializers.IntegerField(source='pop_point.city.country_id', read_only=True, allow_null=True)
    city_id = serializers.IntegerField(source='pop_point.city_id', read_only=True, allow_null=True)
    # ── IP 属性（该 POP 下 IP 段属性集合）──────────────────────
    ip_attributes = serializers.SerializerMethodField()
    billing_mode_label = serializers.CharField(source='get_billing_mode_display', read_only=True)

    class Meta:
        model = Product
        fields = [
            'id', 'product_no', 'name', 'category', 'category_label',
            'status', 'status_label', 'pop_point', 'pop_name', 'pop_code',
            'network_type', 'network_type_label', 'asn_nature', 'asn_nature_label',
            'region_name', 'country_name', 'city_name', 'region_id', 'country_id', 'city_id',
            'ip_attributes',
            'template', 'template_name', 'supplier', 'supplier_name',
            'cpu_cores', 'ram_mb', 'disk_gb', 'nic_count', 'bandwidth_mbps', 'ip_count',
            'accel_type', 'monthly_price', 'reputation_price', 'setup_price', 'currency',
            'billing_mode', 'billing_mode_label', 'transfer_quota_gb', 'overage_unit_price',
            'sort_order', 'is_featured', 'published_at', 'created_at', 'updated_at',
        ]

    def get_ip_attributes(self, obj):
        if not obj.pop_point_id:
            return []
        vals = (obj.pop_point.ip_blocks
                .exclude(ip_attribute='')
                .values_list('ip_attribute', flat=True).distinct())
        return list(vals)


class ProductUpgradeRuleBriefSerializer(serializers.ModelSerializer):
    resource_kind_label = serializers.CharField(source='get_resource_kind_display', read_only=True)

    class Meta:
        model = ProductUpgradeRule
        fields = [
            'id', 'resource_kind', 'resource_kind_label',
            'min_qty', 'max_qty', 'unit_price', 'unit_reputation', 'is_active',
        ]


class ProductDetailSerializer(ProductListSerializer):
    upgrade_rules = ProductUpgradeRuleBriefSerializer(many=True, read_only=True)
    capacity = serializers.SerializerMethodField()
    stock = serializers.SerializerMethodField()
    template_pricing = serializers.SerializerMethodField()
    template_spec = serializers.SerializerMethodField()

    class Meta(ProductListSerializer.Meta):
        fields = ProductListSerializer.Meta.fields + [
            'description', 'remark', 'offline_at', 'created_by',
            'upgrade_rules', 'capacity', 'stock', 'template_pricing', 'template_spec',
        ]

    def _spec(self, obj):
        return {
            'cpu_cores': obj.cpu_cores, 'ram_mb': obj.ram_mb, 'disk_gb': obj.disk_gb,
            'bandwidth_mbps': obj.bandwidth_mbps, 'ip_count': obj.ip_count,
        }

    def get_capacity(self, obj):
        try:
            return services.check_spec_against_pop(obj.pop_point, self._spec(obj))
        except Exception:  # noqa: BLE001
            return None

    def get_stock(self, obj):
        try:
            return services.estimate_stock(obj.pop_point, self._spec(obj))
        except Exception:  # noqa: BLE001
            return None

    def get_template_pricing(self, obj):
        """该产品所选模版在其 POP 点的定价（模版定价）。"""
        if not obj.template_id:
            return None
        tp = TemplatePricing.objects.filter(
            template_id=obj.template_id, pop_point_id=obj.pop_point_id,
        ).first()
        if not tp:
            return None
        return {
            'monthly_price': str(tp.monthly_price),
            'reputation_price': str(tp.reputation_price),
            'setup_price': str(tp.setup_price),
            'currency': tp.currency,
        }

    def get_template_spec(self, obj):
        """模版基准规格（阶梯升级以此为基准）。"""
        if not obj.template_id:
            return None
        t = obj.template
        return {
            'cpu_cores': t.cpu_cores, 'ram_mb': t.ram_mb, 'disk_gb': t.disk_gb,
            'nic_count': t.nic_count, 'bandwidth_mbps': t.bandwidth_mbps, 'ip_count': t.ip_count,
        }


class ProductWriteSerializer(SpecValidateMixin, serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = [
            'id', 'name', 'category', 'status', 'pop_point', 'template', 'supplier',
            'cpu_cores', 'ram_mb', 'disk_gb', 'nic_count', 'bandwidth_mbps', 'ip_count',
            'accel_type', 'monthly_price', 'reputation_price', 'setup_price', 'currency',
            'billing_mode', 'transfer_quota_gb', 'overage_unit_price',
            'sort_order', 'is_featured', 'description', 'remark',
        ]

    def validate(self, attrs):
        attrs = super().validate(attrs)
        from .billing_mode import validate_billing_mode_fields
        errors = validate_billing_mode_fields(attrs, instance=self.instance)
        if errors:
            raise serializers.ValidationError(errors)
        return attrs


class ProductPublishLogSerializer(serializers.ModelSerializer):
    action_label = serializers.CharField(source='get_action_display', read_only=True)
    operator_name = serializers.CharField(source='operator.username', read_only=True, allow_null=True)

    class Meta:
        model = ProductPublishLog
        fields = [
            'id', 'product', 'action', 'action_label',
            'from_status', 'to_status', 'message',
            'operator', 'operator_name', 'created_at',
        ]


# ── Action 序列化器 ───────────────────────────────────────────

class PublishActionSerializer(serializers.Serializer):
    action = serializers.ChoiceField(choices=['publish', 'online', 'offline', 'archive'])
    message = serializers.CharField(required=False, allow_blank=True, max_length=512)


class CustomSpecSerializer(serializers.Serializer):
    cpu_cores = serializers.IntegerField(required=False, min_value=0)
    ram_mb = serializers.IntegerField(required=False, min_value=0)
    disk_gb = serializers.IntegerField(required=False, min_value=0)
    nic_count = serializers.IntegerField(required=False, min_value=0)
    bandwidth_mbps = serializers.IntegerField(required=False, min_value=0)
    ip_count = serializers.IntegerField(required=False, min_value=0)


class TemplateInstantiateSerializer(serializers.Serializer):
    """从模版生成产品。"""
    template_id = serializers.IntegerField()
    pop_point_id = serializers.IntegerField()
    name = serializers.CharField(required=False, allow_blank=True, max_length=128)
    supplier_id = serializers.IntegerField(required=False)
    publish = serializers.BooleanField(default=False)
