"""
PVE 虚机生命周期服务：通过节点 vpopmanager 的 pvemanager API 对 POP 点上的
虚拟机执行电源 / 创建 / 克隆 / 删除等操作，实现 ISPmanager 中心统一运维。

约定：
  - 同步虚机（VPS.is_synced=True）记录 source_ref（节点 VM 主键）与
    source_host_id（节点 PVE 主机），生命周期调用据此定位节点对象。
  - 所有写操作支持 dry_run（默认 True）：仅返回将执行的计划，不实际操作节点。
  - 写操作成功后立即刷新本 POP 的虚机缓存，使中心数据与节点一致。
"""

from django.db import transaction
from django.utils import timezone

from .models import PopPoint, VPS
from .pemanager_client import PemanagerClient, PemanagerError

_POWER_ACTIONS = ('start', 'stop', 'restart', 'shutdown')


def _connect(pop: PopPoint):
    return PemanagerClient.connect_pop(pop)


def _refresh_vms(pop: PopPoint, client: PemanagerClient):
    """操作后刷新本 POP 的同步虚机缓存。"""
    from .sync_service import _sync_vms  # 延迟导入避免循环
    try:
        items = client.vms()
        with transaction.atomic():
            return _sync_vms(pop, items, timezone.now())
    except Exception:  # noqa: BLE001
        return None


def _require_ref(vps: VPS):
    if not vps.source_ref:
        raise PemanagerError(
            f'VPS [{vps.vps_no}] 未关联节点虚机（缺少 source_ref），'
            f'请先执行「从节点同步」后再操作。'
        )


# ═══════════════════════════════════════════════════════════════
# 电源操作
# ═══════════════════════════════════════════════════════════════

def vm_power(vps: VPS, action: str, dry_run: bool = True):
    if action not in _POWER_ACTIONS:
        raise PemanagerError(f'无效电源操作：{action}，可选 {_POWER_ACTIONS}')
    _require_ref(vps)
    if dry_run:
        return {'dry_run': True, 'action': action, 'vm_id': vps.source_ref,
                'vps': vps.name, 'note': f'将对节点虚机执行 {action}'}
    client, user = _connect(vps.pop_point)
    result = client.vm_action(vps.source_ref, action)
    refreshed = _refresh_vms(vps.pop_point, client)
    return {'ok': True, 'action': action, 'node_user': user,
            'result': result, 'refreshed': refreshed}


# ═══════════════════════════════════════════════════════════════
# 创建 / 模板创建 / 克隆 / 删除
# ═══════════════════════════════════════════════════════════════

def create_vm(pop: PopPoint, payload: dict, dry_run: bool = True):
    if dry_run:
        return {'dry_run': True, 'payload': payload,
                'note': '将在节点上创建新虚机'}
    client, user = _connect(pop)
    result = client.create_vm(payload)
    refreshed = _refresh_vms(pop, client)
    return {'ok': True, 'node_user': user, 'result': result, 'refreshed': refreshed}


def create_from_template(pop: PopPoint, payload: dict, dry_run: bool = True):
    if dry_run:
        return {'dry_run': True, 'payload': payload,
                'note': '将从模板创建虚机'}
    client, user = _connect(pop)
    result = client.create_vm_from_template(payload)
    refreshed = _refresh_vms(pop, client)
    return {'ok': True, 'node_user': user, 'result': result, 'refreshed': refreshed}


def clone_vm(vps: VPS, payload: dict, dry_run: bool = True):
    _require_ref(vps)
    if dry_run:
        return {'dry_run': True, 'vm_id': vps.source_ref, 'payload': payload,
                'note': f'将克隆虚机 {vps.name}'}
    client, user = _connect(vps.pop_point)
    result = client.clone_vm(vps.source_ref, payload)
    refreshed = _refresh_vms(vps.pop_point, client)
    return {'ok': True, 'node_user': user, 'result': result, 'refreshed': refreshed}


def delete_vm(vps: VPS, dry_run: bool = True):
    _require_ref(vps)
    if dry_run:
        return {'dry_run': True, 'vm_id': vps.source_ref,
                'note': f'将删除节点虚机 {vps.name}（不可恢复）'}
    client, user = _connect(vps.pop_point)
    result = client.delete_vm(vps.source_ref)
    refreshed = _refresh_vms(vps.pop_point, client)
    return {'ok': True, 'node_user': user, 'result': result, 'refreshed': refreshed}


# ═══════════════════════════════════════════════════════════════
# 节点资源查询（创建虚机时供前端下拉）
# ═══════════════════════════════════════════════════════════════

def _vmid_of(item) -> int | None:
    try:
        return int(item.get('vmid'))
    except (TypeError, ValueError, AttributeError):
        return None


def list_pve_resources(pop: PopPoint):
    """返回节点 PVE 主机 / 节点 / 模板 / 下一个可用 VMID，供创建虚机时选择。

    - 节点名优先取节点实时 PVE 连接（list_nodes）；连不上时回退到
      default_node / 存储节点 / 已有 VM 所在节点，保证前端总能选到节点。
    - next_vmid：节点上已有最大 VMID + 1（至少 100），供前端自动填充，
      避免手工填写导致冲突。
    """
    client, user = _connect(pop)
    hosts = client.list_pve_hosts()

    # 先尽量触发一次节点 VM 同步，使 VMID 反映 PVE 现状（best-effort，连不上则忽略）
    try:
        client.sync_vms()
    except PemanagerError:
        pass
    try:
        all_vms = client.vms()
    except PemanagerError:
        all_vms = []

    def _host_vm_nodes(hid):
        names = set()
        for v in all_vms:
            if isinstance(v, dict) and v.get('host') == hid and v.get('node'):
                names.add(v['node'])
        return names

    result_hosts = []
    for h in hosts or []:
        if not isinstance(h, dict):
            continue
        host_id = h.get('id')
        nodes = []
        node_error = ''
        storages = []
        try:
            nodes = client.list_nodes(host_id) if host_id else []
        except PemanagerError as e:
            node_error = str(e)
            nodes = []
        try:
            # 拉取该主机全部节点的存储，供前端「空白虚机」选择磁盘存储
            storages = client.host_storages(host_id) if host_id else []
        except PemanagerError:
            storages = []
        if not nodes:
            # 兜底：default_node / 存储所在节点 / 已有 VM 所在节点
            names = set()
            if h.get('default_node'):
                names.add(h['default_node'])
            for s in storages:
                if isinstance(s, dict) and s.get('node'):
                    names.add(s['node'])
            names |= _host_vm_nodes(host_id)
            nodes = [{'node': n, 'status': 'unknown'} for n in sorted(filter(None, names))]
        result_hosts.append({
            'id': host_id,
            'name': h.get('name'),
            'host': h.get('host'),
            'default_node': h.get('default_node'),
            'last_status': h.get('last_status'),
            'nodes': nodes,
            'storages': storages,
            'node_error': node_error,
        })
    templates = []
    try:
        templates = client.list_templates()
    except PemanagerError:
        templates = []

    # 下一个可用 VMID：所有已知 VM / 模板 VMID 的最大值 + 1（至少从 100 起）
    max_vmid = 99
    for v in all_vms:
        vid = _vmid_of(v)
        if vid is not None:
            max_vmid = max(max_vmid, vid)
    for t in templates or []:
        if isinstance(t, dict):
            tid = t.get('template_vmid')
            if tid:
                try:
                    max_vmid = max(max_vmid, int(tid))
                except (TypeError, ValueError):
                    pass
    next_vmid = max_vmid + 1

    return {
        'node_user': user,
        'hosts': result_hosts,
        'templates': templates,
        'next_vmid': next_vmid,
    }
