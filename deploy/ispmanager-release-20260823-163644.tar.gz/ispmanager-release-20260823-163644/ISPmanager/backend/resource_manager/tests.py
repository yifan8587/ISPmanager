from types import SimpleNamespace

from django.test import SimpleTestCase, TestCase
from rest_framework.request import Request
from rest_framework.test import APIRequestFactory

from resource_manager.deploy_service import (
    _build_tunnel_spec,
    _disable_orphaned_edge_telemetry_targets,
    _edge_telemetry_target_address,
    _sync_edge_telemetry,
)
from resource_manager.models import (
    BandwidthAllocation,
    City,
    Country,
    EdgeAcceleration,
    IPAddress,
    IPBlock,
    PopPoint,
    Region,
    TunnelIPPool,
    VPS,
)
from resource_manager.serializers import (
    EdgeAccelerationListSerializer,
    IPAddressSerializer,
    IPBlockSerializer,
    TunnelIPPoolSerializer,
    VPSListSerializer,
)
from resource_manager.views import (
    BandwidthAllocationViewSet,
    EdgeAccelerationViewSet,
    IPAddressViewSet,
    IPBlockViewSet,
    PopPointViewSet,
    TunnelIPPoolViewSet,
    VPSViewSet,
)


class EdgeTunnelMtuPayloadTests(SimpleTestCase):
    def test_gre_payload_contains_mtu(self):
        edge = SimpleNamespace(
            protocol=EdgeAcceleration.Protocol.GRE,
            gre_config=SimpleNamespace(
                local_ip='192.0.2.1',
                remote_ip='198.51.100.1',
                tunnel_ip='10.0.0.1/30',
                ttl=64,
                key='',
                mtu=1400,
            ),
        )

        kind, spec = _build_tunnel_spec(edge)

        self.assertEqual(kind, 'gre')
        self.assertEqual(spec['netplan_tunnel']['mtu'], 1400)

    def test_vxlan_payload_contains_mtu(self):
        edge = SimpleNamespace(
            protocol=EdgeAcceleration.Protocol.VXLAN,
            vxlan_config=SimpleNamespace(
                vni=100,
                local_ip='192.0.2.1',
                remote_ip='198.51.100.1',
                tunnel_ip='10.0.0.1/30',
                port=8472,
                ttl=255,
                mtu=1450,
            ),
        )

        kind, spec = _build_tunnel_spec(edge)

        self.assertEqual(kind, 'vxlan')
        self.assertEqual(spec['netplan_tunnel']['mtu'], 1450)

    def test_wireguard_payload_defaults_mtu_to_1400(self):
        edge = SimpleNamespace(
            protocol=EdgeAcceleration.Protocol.WIREGUARD,
            wg_config=SimpleNamespace(
                interface_ip='10.0.0.1/30',
                private_key='private',
                public_key='public',
                listen_port=51820,
                fwmark=None,
                mtu=None,
                dns='',
                peer_public_key='',
                peer_endpoint='',
                peer_allowed_ips='',
                peer_preshared_key='',
                persistent_keepalive=25,
            ),
        )

        kind, spec = _build_tunnel_spec(edge)

        self.assertEqual(kind, 'wireguard')
        self.assertEqual(spec['netplan_tunnel']['mtu'], 1400)


class EdgeTelemetryTargetTests(SimpleTestCase):
    def test_peer_address_uses_protocol_specific_remote_endpoint(self):
        gre = SimpleNamespace(
            protocol=EdgeAcceleration.Protocol.GRE,
            gre_config=SimpleNamespace(remote_ip='198.51.100.10'),
        )
        wireguard = SimpleNamespace(
            protocol=EdgeAcceleration.Protocol.WIREGUARD,
            wg_config=SimpleNamespace(peer_endpoint='[2001:db8::10]:51820'),
        )
        vxlan = SimpleNamespace(
            protocol=EdgeAcceleration.Protocol.VXLAN,
            vxlan_config=SimpleNamespace(remote_ip='203.0.113.10'),
        )

        self.assertEqual(_edge_telemetry_target_address(gre), '198.51.100.10')
        self.assertEqual(_edge_telemetry_target_address(wireguard), '2001:db8::10')
        self.assertEqual(_edge_telemetry_target_address(vxlan), '203.0.113.10')

    def test_sync_creates_target_with_central_edge_identity_and_interface(self):
        class NodeClient:
            def __init__(self):
                self.created_target = None
                self.created_interface = None

            def monitor_targets(self):
                return []

            def monitor_interfaces(self):
                return []

            def create_monitor_target(self, payload):
                self.created_target = payload
                return {'id': 'target-1'}

            def create_monitor_interface(self, payload):
                self.created_interface = payload
                return {'id': 'interface-1'}

        client = NodeClient()
        edge = SimpleNamespace(
            pk=42,
            edge_no='EDGE-42',
            customer=SimpleNamespace(customer_no='C-42'),
            protocol=EdgeAcceleration.Protocol.GRE,
            gre_config=SimpleNamespace(remote_ip='198.51.100.42'),
        )

        result = _sync_edge_telemetry(client, edge, 'gre42')

        self.assertEqual(result['errors'], [])
        self.assertEqual(client.created_target['name'], 'isp-edge-quality-42')
        self.assertEqual(client.created_target['source_interface'], 'gre42')
        self.assertEqual(client.created_target['address'], '198.51.100.42')
        self.assertEqual(client.created_target['customer'], 'C-42')
        self.assertTrue(client.created_target['telemetry_enabled'])
        self.assertEqual(client.created_target['central_edge_id'], 42)
        self.assertEqual(client.created_interface['interface_name'], 'gre42')

    def test_orphan_cleanup_only_disables_isp_managed_targets(self):
        class NodeClient:
            def __init__(self):
                self.patches = []

            def monitor_targets(self):
                return [
                    {'id': 1, 'name': 'isp-edge-quality-42'},
                    {'id': 2, 'name': 'isp-edge-quality-removed'},
                    {'id': 3, 'name': '人工 DNS 探针'},
                ]

            def patch_monitor_target(self, target_id, payload):
                self.patches.append((target_id, payload))

        client = NodeClient()

        result = _disable_orphaned_edge_telemetry_targets(
            client,
            [SimpleNamespace(pk=42)],
        )

        self.assertEqual(result['errors'], [])
        self.assertEqual(result['disabled'], ['isp-edge-quality-removed'])
        self.assertEqual(len(client.patches), 1)
        self.assertEqual(client.patches[0][0], 2)
        self.assertFalse(client.patches[0][1]['enabled'])


class ResourceLocationFilterTests(TestCase):
    """区域筛选要在所有主要资源类型上保持相同语义。"""

    def setUp(self):
        self.apac = Region.objects.create(code='apac', name='亚太')
        self.europe = Region.objects.create(code='europe', name='欧洲')
        apac_city = City.objects.create(
            country=Country.objects.create(region=self.apac, name='日本'),
            name='东京',
        )
        eu_city = City.objects.create(
            country=Country.objects.create(region=self.europe, name='德国'),
            name='法兰克福',
        )
        self.apac_pop = PopPoint.objects.create(name='Tokyo POP', city=apac_city)
        self.eu_pop = PopPoint.objects.create(name='Frankfurt POP', city=eu_city)

        self.apac_block = IPBlock.objects.create(pop_point=self.apac_pop, cidr='203.0.113.0/24')
        eu_block = IPBlock.objects.create(pop_point=self.eu_pop, cidr='198.51.100.0/24')
        self.apac_address = IPAddress.objects.create(ip_block=self.apac_block, address='203.0.113.10')
        IPAddress.objects.create(ip_block=eu_block, address='198.51.100.10')

        self.apac_pool = TunnelIPPool.objects.create(
            pop_point=self.apac_pop, name='tokyo-tunnel', cidr='10.0.0.0/24',
        )
        TunnelIPPool.objects.create(
            pop_point=self.eu_pop, name='frankfurt-tunnel', cidr='10.1.0.0/24',
        )
        self.apac_vps = VPS.objects.create(name='tokyo-vps', pop_point=self.apac_pop)
        VPS.objects.create(name='frankfurt-vps', pop_point=self.eu_pop)
        self.apac_edge = EdgeAcceleration.objects.create(
            name='tokyo-edge',
            protocol=EdgeAcceleration.Protocol.GRE,
            pop_point=self.apac_pop,
        )
        eu_edge = EdgeAcceleration.objects.create(
            name='frankfurt-edge',
            protocol=EdgeAcceleration.Protocol.GRE,
            pop_point=self.eu_pop,
        )
        self.apac_bandwidth = BandwidthAllocation.objects.create(
            pop_point=self.apac_pop,
            target_type=BandwidthAllocation.AllocTarget.VPS,
            vps=self.apac_vps,
            allocated_mbps=100,
        )
        BandwidthAllocation.objects.create(
            pop_point=self.eu_pop,
            target_type=BandwidthAllocation.AllocTarget.EDGE,
            edge=eu_edge,
            allocated_mbps=100,
        )
        self.factory = APIRequestFactory()

    def _filter(self, view_class, queryset, **params):
        view = view_class()
        view.request = Request(self.factory.get('/resource/', params))
        view.args = ()
        view.kwargs = {}
        view.action = 'list'
        return view.filter_queryset(queryset)

    def test_region_filter_limits_every_resource_to_its_pop(self):
        cases = (
            (PopPointViewSet, PopPoint.objects.all(), self.apac_pop.pk),
            (IPBlockViewSet, IPBlock.objects.all(), self.apac_block.pk),
            (IPAddressViewSet, IPAddress.objects.all(), self.apac_address.pk),
            (TunnelIPPoolViewSet, TunnelIPPool.objects.all(), self.apac_pool.pk),
            (VPSViewSet, VPS.objects.all(), self.apac_vps.pk),
            (EdgeAccelerationViewSet, EdgeAcceleration.objects.all(), self.apac_edge.pk),
            (BandwidthAllocationViewSet, BandwidthAllocation.objects.all(), self.apac_bandwidth.pk),
        )
        for view_class, queryset, expected_pk in cases:
            with self.subTest(view=view_class.__name__):
                result = self._filter(view_class, queryset, region=self.apac.pk)
                self.assertEqual(list(result.values_list('pk', flat=True)), [expected_pk])

    def test_pop_filter_and_ip_location_fields_follow_ip_block(self):
        result = self._filter(
            IPAddressViewSet,
            IPAddress.objects.all(),
            pop_point=self.apac_pop.pk,
        )
        self.assertEqual(list(result.values_list('pk', flat=True)), [self.apac_address.pk])

        payload = IPAddressSerializer(
            IPAddress.objects.select_related(
                'ip_block__pop_point__city__country__region',
            ).get(pk=self.apac_address.pk),
        ).data
        self.assertEqual(payload['region_id'], self.apac.pk)
        self.assertEqual(payload['region_name'], '亚太')
        self.assertEqual(payload['country_name'], '日本')
        self.assertEqual(payload['city_name'], '东京')
        self.assertEqual(payload['pop_name'], 'Tokyo POP')

    def test_resource_list_serializers_reuse_prefetched_ip_addresses(self):
        vps_queryset = VPS.objects.select_related(
            'pop_point__city__country__region',
            'customer',
        ).prefetch_related('ip_addresses')
        edge_queryset = EdgeAcceleration.objects.select_related(
            'pop_point__city__country__region',
            'customer',
        ).prefetch_related('ip_addresses')

        with self.assertNumQueries(2):
            list(VPSListSerializer(vps_queryset, many=True).data)
        with self.assertNumQueries(2):
            list(EdgeAccelerationListSerializer(edge_queryset, many=True).data)

    def test_tunnel_pool_list_prefetches_taken_ips_without_per_pool_queries(self):
        queryset = TunnelIPPoolViewSet().get_queryset()
        with self.assertNumQueries(3):
            list(TunnelIPPoolSerializer(queryset, many=True).data)

    def test_ip_block_list_uses_annotated_usage_counts(self):
        queryset = IPBlockViewSet().get_queryset()
        with self.assertNumQueries(1):
            payload = list(IPBlockSerializer(queryset, many=True).data)
        self.assertEqual(payload[0]['ip_stats']['total'], 1)
