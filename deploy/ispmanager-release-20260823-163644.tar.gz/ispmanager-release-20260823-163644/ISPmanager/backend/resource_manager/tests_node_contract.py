"""N1：中心 ↔ 节点契约（鉴权、apply 观测、工单 IP 下发）。"""
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from django.db import transaction
from django.test import SimpleTestCase, TestCase

from customer_manager.models import Customer
from resource_manager.deploy_service import push_pop_to_node
from resource_manager.models import (
    City,
    Country,
    IPAddress,
    IPBlock,
    PopPoint,
    Region,
    VPS,
)
from resource_manager.pemanager_client import (
    PemanagerClient,
    PemanagerError,
    interpret_node_write,
    pop_has_api_config,
)
from service_manager.models import ServiceInstance, ServiceOrder
from service_manager.provisioning import _allocate_order_ips


class _FakeResp:
    def __init__(self, status_code, payload, text=''):
        self.status_code = status_code
        self._payload = payload
        self.text = text or str(payload)

    def json(self):
        return self._payload


class InterpretNodeWriteTests(SimpleTestCase):
    def test_empty_body_is_apply_ok(self):
        interp = interpret_node_write({})
        self.assertTrue(interp['rest_ok'])
        self.assertTrue(interp['apply_ok'])
        self.assertEqual(interp['errors'], [])

    def test_http200_write_disabled_warning_is_not_apply_ok(self):
        interp = interpret_node_write({
            'ok': True,
            'warning': '系统写入未启用（INTERFACEMANAGE_NETPLAN_WRITE_ENABLED=False），本次仅更新数据库配置',
        })
        self.assertTrue(interp['rest_ok'])
        self.assertFalse(interp['apply_ok'])
        self.assertTrue(any('WRITE_ENABLED' in e or '写入' in e for e in interp['errors']))

    def test_ok_false_with_write_enabled_error(self):
        interp = interpret_node_write({
            'ok': False,
            'error': '路由 netplan 写入已关闭（settings.ROUTEMANAGE_NETPLAN_WRITE_ENABLED）',
            'steps': [],
        })
        self.assertFalse(interp['apply_ok'])
        self.assertTrue(interp['errors'])

    def test_failed_step_marks_apply_not_ok(self):
        interp = interpret_node_write({
            'ok': True,
            'steps': [{'ok': False, 'stderr': 'netplan generate failed'}],
        })
        self.assertFalse(interp['apply_ok'])
        self.assertIn('netplan generate failed', interp['errors'])

    def test_qos_not_applied(self):
        interp = interpret_node_write({
            'ok': True,
            'qos': {'applied': False, 'error': 'QOSMANAGE_APPLY_ENABLED=0'},
        })
        self.assertFalse(interp['apply_ok'])
        self.assertTrue(interp['errors'])


class PemanagerClientAuthTests(SimpleTestCase):
    def test_from_pop_uses_mgmt_token_without_password(self):
        pop = SimpleNamespace(
            name='tok-pop',
            api_base_url='http://node.example',
            api_username='',
            api_password='',
            mgmt_username='',
            mgmt_password='',
            mgmt_ip=None,
            mgmt_token='pem_abc.secret',
        )
        self.assertTrue(pop_has_api_config(pop))
        client = PemanagerClient.from_pop(pop)
        user = client.authenticate()
        self.assertEqual(user.get('auth'), 'token')
        self.assertEqual(client.session.headers['Authorization'], 'Bearer pem_abc.secret')
        self.assertEqual(client.token, 'pem_abc.secret')

    def test_from_pop_requires_token_or_password(self):
        pop = SimpleNamespace(
            name='bare',
            api_base_url='http://node.example',
            api_username='admin',
            api_password='',
            mgmt_username='',
            mgmt_password='',
            mgmt_ip=None,
            mgmt_token='',
        )
        self.assertFalse(pop_has_api_config(pop))
        with self.assertRaises(PemanagerError):
            PemanagerClient.from_pop(pop)

    def test_authenticate_login_flow(self):
        client = PemanagerClient('http://node.example', 'admin', 'secret')
        posts = []

        def fake_post(url, json=None, timeout=None, verify=None):
            posts.append((url, json))
            return _FakeResp(200, {'access': 'jwt-access', 'user': {'username': 'admin'}})

        with patch.object(client.session, 'post', side_effect=fake_post):
            user = client.authenticate()
        self.assertEqual(user.get('username'), 'admin')
        self.assertEqual(client.token, 'jwt-access')
        self.assertTrue(posts[0][0].endswith('/api/accountmanage/auth/login/'))

    def test_desired_tunnel_apply_contract(self):
        client = PemanagerClient('http://node.example', 'admin', 'secret')

        def fake_post(url, json=None, timeout=None, verify=None):
            if url.endswith('/auth/login/'):
                return _FakeResp(200, {'access': 'jwt-access', 'user': {'username': 'admin'}})
            if url.endswith('/db/desired-tunnels/'):
                return _FakeResp(201, {'id': 'tun-1', 'ifname': 'gre1'})
            if url.endswith('/desired-tunnels/apply-system/'):
                self.assertEqual(json.get('ids'), ['tun-1'])
                return _FakeResp(200, {
                    'ok': True,
                    'steps': [{'ok': True, 'step': 'netplan'}],
                })
            return _FakeResp(404, {})

        with patch.object(client.session, 'post', side_effect=fake_post):
            client.authenticate()
            obj = client.create_desired_tunnel({
                'ifname': 'gre1',
                'kind': 'gre',
                'spec': {'type': 'gre', 'netplan_tunnel': {'mode': 'gre'}},
            })
            result = client.apply_desired_tunnels(ids=[obj['id']])
        interp = interpret_node_write(result)
        self.assertTrue(interp['rest_ok'])
        self.assertTrue(interp['apply_ok'])


class PushPopApplyObservationTests(TestCase):
    def setUp(self):
        region = Region.objects.create(code='apac', name='亚太')
        country = Country.objects.create(region=region, name='中国')
        city = City.objects.create(country=country, name='上海')
        self.pop = PopPoint.objects.create(
            name='观测 POP',
            city=city,
            api_base_url='http://node.example',
            mgmt_token='pem_test.secret',
            config_dirty=True,
        )

    def test_apply_not_ok_keeps_config_dirty(self):
        def fake_handler(pop, client, dry_run=True):
            return {
                'ok': False,
                'apply_interp': interpret_node_write({
                    'ok': True,
                    'warning': '系统写入未启用（INTERFACEMANAGE_NETPLAN_WRITE_ENABLED=False）',
                }),
            }

        with patch(
            'resource_manager.deploy_service.PemanagerClient.connect_pop',
            return_value=(MagicMock(), {'auth': 'token'}),
        ), patch.dict(
            'resource_manager.deploy_service._SECTION_HANDLERS',
            {'edge_tunnels': fake_handler},
            clear=True,
        ):
            result = push_pop_to_node(self.pop, sections=['edge_tunnels'], dry_run=False)

        self.assertTrue(result['rest_ok'])
        self.assertFalse(result['apply_ok'])
        self.assertFalse(result['ok'])
        self.pop.refresh_from_db()
        self.assertTrue(self.pop.config_dirty)

    def test_apply_ok_clears_config_dirty(self):
        def fake_handler(pop, client, dry_run=True):
            return {
                'ok': True,
                'apply_interp': interpret_node_write({'ok': True, 'steps': []}),
            }

        with patch(
            'resource_manager.deploy_service.PemanagerClient.connect_pop',
            return_value=(MagicMock(), {'auth': 'token'}),
        ), patch.dict(
            'resource_manager.deploy_service._SECTION_HANDLERS',
            {'edge_tunnels': fake_handler},
            clear=True,
        ):
            result = push_pop_to_node(self.pop, sections=['edge_tunnels'], dry_run=False)

        self.assertTrue(result['ok'])
        self.assertTrue(result['apply_ok'])
        self.pop.refresh_from_db()
        self.assertFalse(self.pop.config_dirty)


class OrderIpPushTests(TestCase):
    def setUp(self):
        self.customer = Customer.objects.create(
            name='节点 IP 客户',
            contact_name='联系人',
            status='active',
        )
        region = Region.objects.create(code='europe', name='欧洲')
        country = Country.objects.create(region=region, name='德国')
        city = City.objects.create(country=country, name='法兰克福')
        self.pop = PopPoint.objects.create(
            name='IP POP',
            city=city,
            api_base_url='http://node.example',
            mgmt_token='pem_ip.secret',
        )
        self.block = IPBlock.objects.create(pop_point=self.pop, cidr='203.0.113.0/24')
        self.ip = IPAddress.objects.create(
            ip_block=self.block,
            address='203.0.113.20',
            prefix_len=24,
            status=IPAddress.IPStatus.AVAILABLE,
        )
        from decimal import Decimal

        from product_manager.models import Product
        self.product = Product.objects.create(
            name='IP 产品',
            status=Product.Status.ONLINE,
            pop_point=self.pop,
            monthly_price=Decimal('10.00'),
            currency='USD',
        )
        self.order = ServiceOrder.objects.create(
            customer=self.customer,
            product=self.product,
            preferred_pop=self.pop,
            order_type=ServiceOrder.OrderType.NEW,
            business_type=ServiceOrder.BusinessType.VPS,
            requested_ip_count=1,
            status=ServiceOrder.OrderStatus.APPROVED,
            quoted_price=Decimal('10.00'),
        )
        self.vps = VPS.objects.create(name='契约 VPS', pop_point=self.pop, customer=self.customer)
        self.instance = ServiceInstance.objects.create(
            service_order=self.order,
            service_type=ServiceInstance.ServiceType.VPS,
            status=ServiceInstance.InstanceStatus.PROVISIONING,
            vps=self.vps,
        )

    def _mock_node(self):
        client = MagicMock()
        client.session.headers = {'Authorization': 'Bearer pem_ip.secret'}
        client.customers.return_value = [{'code': self.customer.customer_no, 'id': 1}]
        client.bulk_create_ips.return_value = {
            'created': ['203.0.113.20'], 'skipped': [], 'errors': [],
        }
        client.allocate_ip.return_value = {'address': '203.0.113.20'}
        return client

    def test_allocate_pushes_vps_ip_to_node(self):
        client = self._mock_node()
        with patch(
            'resource_manager.ip_ops.PemanagerClient.connect_pop',
            return_value=(client, {'auth': 'token'}),
        ):
            allocated = _allocate_order_ips(
                self.order, self.pop, self.instance, vps=self.vps,
            )
        self.assertEqual([item.pk for item in allocated], [self.ip.pk])
        client.allocate_ip.assert_called()
        payload = client.allocate_ip.call_args[0][0]
        self.assertEqual(payload['address'], '203.0.113.20')
        self.assertEqual(payload['customer_code'], self.customer.customer_no)

    def test_node_failure_rolls_back_local_assignment(self):
        client = self._mock_node()
        client.allocate_ip.side_effect = PemanagerError('节点分配失败')
        with patch(
            'resource_manager.ip_ops.PemanagerClient.connect_pop',
            return_value=(client, {'auth': 'token'}),
        ):
            with self.assertRaises(RuntimeError):
                with transaction.atomic():
                    _allocate_order_ips(self.order, self.pop, self.instance, vps=self.vps)
        self.ip.refresh_from_db()
        self.assertEqual(self.ip.status, IPAddress.IPStatus.AVAILABLE)

    def test_no_api_config_skips_node_push(self):
        self.pop.api_base_url = ''
        self.pop.mgmt_token = ''
        self.pop.mgmt_ip = None
        self.pop.save(update_fields=['api_base_url', 'mgmt_token', 'mgmt_ip'])
        allocated = _allocate_order_ips(self.order, self.pop, self.instance, vps=self.vps)
        self.assertEqual([item.pk for item in allocated], [self.ip.pk])
        self.ip.refresh_from_db()
        self.assertEqual(self.ip.status, IPAddress.IPStatus.ASSIGNED)
