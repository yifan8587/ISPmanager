"""资源补充后的已付款工单恢复开通。

资源调整完成时，只重试此前因容量不足而暂停的已付款工单。容量仍不足的工单不会
重复触发 IM 告警；真正重新进入自动开通时仍由 ``payment_fulfillment`` 和
``provisioning`` 负责并发保护、状态写回和资源分配。
"""
from __future__ import annotations

import logging

from django.db import transaction
from django.db.models import Q

from customer_manager.models import CustomerBilling

from .models import ServiceOrder
from .payment_fulfillment import fulfill_paid_billing
from .provisioning import _check_resources, build_spec, capacity_allows

logger = logging.getLogger(__name__)


def retry_insufficient_paid_orders_for_pop(pop, *, operator=None, reason: str = '') -> dict:
    """在指定 POP 容量变化后恢复可交付的已付款工单。

    仅处理状态为 ``insufficient`` 的订单，并先重新做容量判断。因此一次资源调整
    不会让仍然缺少 CPU、IP 或带宽的订单重复进入开通流程或重复告警。
    """
    if pop is None or not getattr(pop, 'pk', None):
        return {'pop_id': None, 'checked': 0, 'retried': 0, 'still_insufficient': 0}

    billings = (
        CustomerBilling.objects.filter(
            status=CustomerBilling.BillingStatus.PAID,
            service_order__preferred_pop_id=pop.pk,
            service_order__status__in=(
                ServiceOrder.OrderStatus.APPROVED,
                ServiceOrder.OrderStatus.PROVISIONING,
            ),
            service_order__auto_provision_status=ServiceOrder.AutoProvisionStatus.INSUFFICIENT,
        )
        .filter(
            Q(
                service_order__order_type=ServiceOrder.OrderType.NEW,
                service_order__instances__isnull=True,
            )
            | Q(service_order__order_type__in=(
                ServiceOrder.OrderType.UPGRADE,
                ServiceOrder.OrderType.DOWNGRADE,
                ServiceOrder.OrderType.CHANGE,
            ))
        )
        .select_related('service_order', 'service_order__preferred_pop')
        .distinct()
    )

    checked = retried = still_insufficient = 0
    results = []
    for billing in billings.iterator():
        order = billing.service_order
        checked += 1
        try:
            if order.preferred_pop.config_mode != order.preferred_pop.ConfigMode.AUTO:
                results.append({'order_no': order.order_no, 'result': 'pop_not_auto'})
                continue

            if order.order_type in (
                ServiceOrder.OrderType.UPGRADE,
                ServiceOrder.OrderType.DOWNGRADE,
                ServiceOrder.OrderType.CHANGE,
            ):
                from .change_provisioning import change_capacity_spec
                spec = change_capacity_spec(order)
            else:
                spec = build_spec(order)
            capacity = _check_resources(order.preferred_pop, spec, exclude_order=order)
            if not capacity_allows(order.preferred_pop, capacity):
                still_insufficient += 1
                results.append({
                    'order_no': order.order_no,
                    'result': 'still_insufficient',
                    'shortages': capacity.get('shortages') or [],
                })
                continue

            outcome = fulfill_paid_billing(billing.pk, force=True, operator=operator)
            if outcome.get('triggered'):
                retried += 1
            results.append({
                'order_no': order.order_no,
                'result': 'retried' if outcome.get('triggered') else outcome.get('reason', 'skipped'),
            })
        except Exception:  # noqa: BLE001
            logger.exception(
                'POP %s 资源恢复后重试工单 %s 失败（%s）',
                pop.pk,
                order.order_no,
                reason or '未提供原因',
            )
            results.append({'order_no': order.order_no, 'result': 'error'})

    return {
        'pop_id': pop.pk,
        'checked': checked,
        'retried': retried,
        'still_insufficient': still_insufficient,
        'results': results,
    }


def schedule_capacity_recovery(pop, *, operator=None, reason: str = '') -> None:
    """在当前数据库提交成功后恢复等待交付的已付款工单。"""
    if pop is None or not getattr(pop, 'pk', None):
        return

    def _retry():
        retry_insufficient_paid_orders_for_pop(pop, operator=operator, reason=reason)

    transaction.on_commit(_retry)
