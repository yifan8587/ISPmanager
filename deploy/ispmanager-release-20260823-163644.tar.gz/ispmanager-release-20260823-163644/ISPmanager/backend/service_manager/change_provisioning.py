"""已付款服务变更的开通：增量资源校验、自动交付或转人工。"""
from __future__ import annotations

from django.db import transaction
from django.utils import timezone

from resource_manager.models import IPAddress
from resource_manager.sync_service import _TUNNEL_BLOCK_TAG

from .change_billing import current_resource_spec
from .change_executor import ChangeExecutionError, execute_change
from .models import (
    ServiceChangeRecord,
    ServiceInstance,
    ServiceOperationLog,
    ServiceOrder,
    _log_service,
)
from .provisioning import _check_resources, capacity_allows, notify_managers, oversell_note


class ChangeProvisionError(Exception):
    pass


def target_spec_from_change(change: ServiceChangeRecord) -> dict:
    after = change.after_spec or {}
    return {
        'cpu_cores': int(after.get('cpu_cores') or after.get('vcpu') or 0),
        'ram_mb': int(after.get('ram_mb') or 0),
        'disk_gb': int(after.get('disk_gb') or 0),
        'bandwidth_mbps': int(after.get('bandwidth_mbps') or 0),
        'ip_count': int(after.get('ip_count') or 0),
        'nic_count': int(after.get('nic_count') or 0),
    }


def current_ip_count(instance: ServiceInstance) -> int:
    count = instance.ip_addresses.count()
    if count:
        return count
    if instance.vps_id and instance.vps:
        return instance.vps.ip_addresses.count()
    if instance.edge_id and instance.edge:
        return instance.edge.ip_addresses.count()
    return 0


def change_delta_spec(instance: ServiceInstance, target: dict) -> dict:
    current = current_resource_spec(instance)
    current_ips = max(int(current.get('ip_count') or 0), current_ip_count(instance))
    return {
        'cpu_cores': max(0, int(target.get('cpu_cores') or 0) - int(current.get('cpu_cores') or 0)),
        'ram_mb': max(0, int(target.get('ram_mb') or 0) - int(current.get('ram_mb') or 0)),
        'disk_gb': max(0, int(target.get('disk_gb') or 0) - int(current.get('disk_gb') or 0)),
        'bandwidth_mbps': max(
            0,
            int(target.get('bandwidth_mbps') or 0) - int(current.get('bandwidth_mbps') or 0),
        ),
        'ip_count': max(0, int(target.get('ip_count') or 0) - current_ips),
    }


def change_capacity_spec(order: ServiceOrder) -> dict:
    instance = order.related_instance
    change = (
        ServiceChangeRecord.objects.filter(related_order=order)
        .order_by('-id')
        .first()
    )
    if instance is None or change is None:
        from .provisioning import build_spec
        return build_spec(order)
    return change_delta_spec(instance, target_spec_from_change(change))


def extra_ip_needed(instance: ServiceInstance, target: dict) -> int:
    return change_delta_spec(instance, target)['ip_count']


def resolve_change_pop(order: ServiceOrder, instance: ServiceInstance):
    return order.preferred_pop or getattr(instance.vps or instance.edge, 'pop_point', None)


def _mark_wait(order: ServiceOrder, change: ServiceChangeRecord, *, status: str, subject: str, message: str, operator=None):
    order.status = ServiceOrder.OrderStatus.APPROVED
    order.auto_provision_status = status
    order.auto_provision_message = message[:2000]
    order.save(update_fields=[
        'status', 'auto_provision_status', 'auto_provision_message', 'updated_at',
    ])
    _log_service(
        operator=operator,
        action_type=ServiceOperationLog.ActionType.CHANGE,
        description=f'工单 [{order.order_no}] {subject}：{message}'[:500],
        service_order=order,
        service_instance=order.related_instance,
    )
    notify_managers(order, subject, message)
    from .notify_helpers import notify_change_event
    notify_change_event(change, subject, detail=message)


def _mark_success(order: ServiceOrder, change: ServiceChangeRecord, *, message: str):
    order.status = ServiceOrder.OrderStatus.ACTIVE
    order.auto_provision_status = ServiceOrder.AutoProvisionStatus.SUCCESS
    order.auto_provision_message = message[:2000]
    order.save(update_fields=[
        'status', 'auto_provision_status', 'auto_provision_message', 'updated_at',
    ])
    from .notify_helpers import notify_order_event
    notify_order_event(order, '变更开通成功', detail=message, event='service_provision')


def allocate_extra_ips(order: ServiceOrder, instance: ServiceInstance, count: int):
    if count <= 0:
        return []
    pop = resolve_change_pop(order, instance)
    if pop is None:
        raise ChangeProvisionError('变更工单缺少 POP，无法分配新增 IP')
    available = list(
        IPAddress.objects.select_for_update()
        .filter(
            ip_block__pop_point=pop,
            status=IPAddress.IPStatus.AVAILABLE,
        )
        .exclude(ip_block__description__startswith=_TUNNEL_BLOCK_TAG)
        .order_by('address')[:count]
    )
    if len(available) < count:
        raise ChangeProvisionError(f'可用 IP 不足：需新增 {count}，实际可用 {len(available)}')
    now = timezone.now()
    vps = instance.vps if instance.vps_id else None
    edge = instance.edge if instance.edge_id else None
    for ip in available:
        ip.status = IPAddress.IPStatus.ASSIGNED
        ip.assigned_at = now
        ip.assigned_vps = vps
        ip.assigned_edge = edge
        ip.product = order.product
        ip.description = ((ip.description or '') + f' | 变更工单 {order.order_no}')[:256]
        ip.save(update_fields=[
            'status', 'assigned_at', 'assigned_vps', 'assigned_edge',
            'product', 'description',
        ])
    instance.ip_addresses.add(*available)
    return available


def attach_selected_ips(order: ServiceOrder, instance: ServiceInstance, ip_ids: list[int]):
    if not ip_ids:
        return []
    pop = resolve_change_pop(order, instance)
    ips = list(
        IPAddress.objects.select_for_update()
        .filter(pk__in=ip_ids)
        .select_related('ip_block__pop_point')
        .order_by('address')
    )
    if len(ips) != len(set(ip_ids)):
        raise ChangeProvisionError('包含不存在的 IP 地址')
    now = timezone.now()
    vps = instance.vps if instance.vps_id else None
    edge = instance.edge if instance.edge_id else None
    for ip in ips:
        if ip.status != IPAddress.IPStatus.AVAILABLE:
            raise ChangeProvisionError(f'IP {ip.address} 当前不是可分配状态')
        if pop and ip.ip_block.pop_point_id != pop.id:
            raise ChangeProvisionError(f'IP {ip.address} 不属于工单期望 POP')
        ip.status = IPAddress.IPStatus.ASSIGNED
        ip.assigned_at = now
        ip.assigned_vps = vps
        ip.assigned_edge = edge
        ip.product = order.product
        ip.save(update_fields=[
            'status', 'assigned_at', 'assigned_vps', 'assigned_edge', 'product',
        ])
    instance.ip_addresses.add(*ips)
    return ips


@transaction.atomic
def apply_paid_change(
    order: ServiceOrder,
    change: ServiceChangeRecord,
    *,
    operator=None,
    create_followup_ticket=None,
) -> dict:
    """付款后尝试自动交付变更：资源够则开通，不够则 IM 通知并等待人工交付。"""
    instance = order.related_instance
    if instance is None:
        return {'triggered': False, 'reason': 'no_related_instance'}
    if change.status == ServiceChangeRecord.ChangeStatus.COMPLETED:
        return {'triggered': False, 'reason': 'already_completed'}

    target = target_spec_from_change(change)
    delta = change_delta_spec(instance, target)
    extra_ips = extra_ip_needed(instance, target)
    # 降配只收缩档案规格，不因当前未挂 IP 而误判需要新增地址
    if change.change_type == ServiceChangeRecord.ChangeType.DOWNGRADE:
        extra_ips = 0
        delta = {key: 0 for key in delta}
    pop = resolve_change_pop(order, instance)
    needs_pool = extra_ips > 0 or any(
        delta.get(key, 0) > 0 for key in ('cpu_cores', 'ram_mb', 'disk_gb', 'bandwidth_mbps')
    )

    if needs_pool and pop is None:
        _mark_wait(
            order, change,
            status=ServiceOrder.AutoProvisionStatus.PAID_PENDING,
            subject='变更已付款待人工',
            message='支付已确认，但变更工单缺少 POP，请管理员手动交付新增资源',
            operator=operator,
        )
        return {'triggered': False, 'reason': 'no_pop'}

    check = {'ok': True, 'shortages': []}
    if extra_ips > 0 or needs_pool:
        check = _check_resources(pop, delta, exclude_order=order)
        if not capacity_allows(pop, check):
            shortages = '；'.join(check.get('shortages') or []) or '资源不足'
            _mark_wait(
                order, change,
                status=ServiceOrder.AutoProvisionStatus.INSUFFICIENT,
                subject='变更资源不足待人工',
                message=f'支付已确认，但当前节点无法交付新增规格：{shortages}',
                operator=operator,
            )
            return {
                'triggered': False,
                'reason': 'insufficient',
                'shortages': check.get('shortages') or [],
            }

    if extra_ips > 0:
        try:
            allocate_extra_ips(order, instance, extra_ips)
        except ChangeProvisionError as exc:
            _mark_wait(
                order, change,
                status=ServiceOrder.AutoProvisionStatus.INSUFFICIENT,
                subject='变更资源不足待人工',
                message=f'支付已确认，但新增 IP 不足：{exc}',
                operator=operator,
            )
            return {'triggered': False, 'reason': 'insufficient', 'error': str(exc)}

    try:
        execute_change(change, operator=operator)
    except ChangeExecutionError as exc:
        order.auto_provision_status = ServiceOrder.AutoProvisionStatus.FAILED
        order.auto_provision_message = str(exc)[:2000]
        order.save(update_fields=['auto_provision_status', 'auto_provision_message', 'updated_at'])
        from .capacity_reservation import release_reservation
        release_reservation(order, reason='升配执行失败，回滚预占')
        notify_managers(order, '自动开通失败', str(exc))
        return {'triggered': False, 'reason': 'execute_failed', 'error': str(exc)}

    from .capacity_reservation import consume_reservation
    consume_reservation(order)
    note = f'变更 {change.change_no} 已自动开通并交付完成'
    extra = oversell_note(pop, check)
    if extra:
        note = f'{note}；{extra}'
    _mark_success(order, change, message=note)
    from .change_scheduler import ensure_change_followup_ticket
    ticket = ensure_change_followup_ticket(
        change, operator=operator, enabled=create_followup_ticket,
    )
    return {
        'triggered': True,
        'change_no': change.change_no,
        'auto': True,
        'followup_ticket_no': getattr(ticket, 'ticket_no', None),
    }


@transaction.atomic
def deliver_change_order(order: ServiceOrder, *, ip_ids=None, operator=None, remark: str = '') -> dict:
    """后台手动交付已付款变更：把补齐的 IP 挂到原实例并执行变更。"""
    instance = order.related_instance
    if instance is None:
        raise ChangeProvisionError('变更工单未关联原服务实例')
    change = (
        ServiceChangeRecord.objects.select_for_update()
        .filter(related_order=order)
        .order_by('-id')
        .first()
    )
    if change is None:
        raise ChangeProvisionError('未找到关联变更单')
    if change.status == ServiceChangeRecord.ChangeStatus.COMPLETED:
        raise ChangeProvisionError('该变更已执行完成')
    if change.status == ServiceChangeRecord.ChangeStatus.PENDING:
        change.status = ServiceChangeRecord.ChangeStatus.APPROVED
        change.approved_at = timezone.now()
        change.approved_by = operator
        change.save(update_fields=['status', 'approved_at', 'approved_by', 'updated_at'])

    attached = attach_selected_ips(order, instance, list(ip_ids or []))
    execute_change(change, operator=operator)
    from .capacity_reservation import consume_reservation
    consume_reservation(order)
    note = remark or f'变更 {change.change_no} 已手动交付'
    if attached:
        note = f'{note}，新增 IP {len(attached)} 个'
    _mark_success(order, change, message=note)
    from .change_scheduler import ensure_change_followup_ticket
    ticket = ensure_change_followup_ticket(change, operator=operator)
    return {
        'change_no': change.change_no,
        'instance_no': instance.instance_no,
        'added_ips': [ip.address for ip in attached],
        'followup_ticket_no': getattr(ticket, 'ticket_no', None),
    }
