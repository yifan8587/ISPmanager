from rest_framework.routers import DefaultRouter

from .views import (
    SupplierAPIViewSet,
    SupplierPopBindingViewSet,
    SupplierResourceViewSet,
    SupplierSyncLogViewSet,
    SupplierViewSet,
)

router = DefaultRouter()
router.register(r'suppliers', SupplierViewSet, basename='supplier')
router.register(r'apis', SupplierAPIViewSet, basename='supplierapi')
router.register(r'pop-bindings', SupplierPopBindingViewSet, basename='supplierpopbinding')
router.register(r'resources', SupplierResourceViewSet, basename='supplierresource')
router.register(r'sync-logs', SupplierSyncLogViewSet, basename='suppliersynclog')

urlpatterns = router.urls
