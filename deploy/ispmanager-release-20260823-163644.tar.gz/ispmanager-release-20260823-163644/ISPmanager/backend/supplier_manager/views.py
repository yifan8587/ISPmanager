"""
supplier_manager/views.py
供应商管理模块 DRF ViewSets
"""
from django.utils import timezone
from rest_framework import filters, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from accounts.drf_mixins import SupplierModulePermissionMixin

from . import services
from .models import (
    Supplier, SupplierAPI, SupplierPopBinding, SupplierResource, SupplierStatus,
    SupplierSyncLog,
)
from .serializers import (
    MapResourceSerializer, PullResourcesSerializer,
    SupplierAPISerializer, SupplierBriefSerializer, SupplierPopBindingSerializer,
    SupplierResourceSerializer, SupplierSerializer, SupplierSyncLogSerializer,
)


# ═══════════════════════════════════════════════════════════════
# § 供应商
# ═══════════════════════════════════════════════════════════════

class SupplierViewSet(SupplierModulePermissionMixin, viewsets.ModelViewSet):
    """供应商 CRUD + 关联资源/POP/同步日志查询。"""
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['supplier_type', 'status']
    search_fields = ['name', 'short_name', 'supplier_no', 'company_name', 'contact_name']
    ordering_fields = ['created_at', 'rating', 'name']
    ordering = ['-created_at']

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='brief')
    def brief_list(self, request):
        qs = self.get_queryset().exclude(status=SupplierStatus.DISABLED)
        return Response(SupplierBriefSerializer(qs, many=True).data)

    @action(detail=True, methods=['get'])
    def resources(self, request, pk=None):
        supplier = self.get_object()
        qs = supplier.resources.all()
        rtype = request.query_params.get('resource_type')
        if rtype:
            qs = qs.filter(resource_type=rtype)
        page = self.paginate_queryset(qs)
        ser = SupplierResourceSerializer(page if page is not None else qs, many=True)
        return self.get_paginated_response(ser.data) if page is not None else Response(ser.data)

    @action(detail=True, methods=['get'], url_path='sync-logs')
    def sync_logs(self, request, pk=None):
        supplier = self.get_object()
        qs = supplier.sync_logs.all()[:200]
        return Response(SupplierSyncLogSerializer(qs, many=True).data)

    @action(detail=False, methods=['get'])
    def statistics(self, request):
        qs = self.get_queryset()
        by_status = {}
        for s in SupplierStatus.values:
            by_status[s] = qs.filter(status=s).count()
        return Response({
            'total': qs.count(),
            'by_status': by_status,
            'api_total': SupplierAPI.objects.count(),
            'resource_total': SupplierResource.objects.count(),
        })


# ═══════════════════════════════════════════════════════════════
# § 供应商 API
# ═══════════════════════════════════════════════════════════════

class SupplierAPIViewSet(SupplierModulePermissionMixin, viewsets.ModelViewSet):
    """供应商 API 配置 CRUD + 连接测试 + 拉取资源。"""
    queryset = SupplierAPI.objects.select_related('supplier').all()
    serializer_class = SupplierAPISerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['supplier', 'is_active', 'sync_enabled']
    search_fields = ['name', 'base_url', 'supplier__name']

    @action(detail=True, methods=['post'], url_path='test')
    def test_connection(self, request, pk=None):
        api = self.get_object()
        try:
            result = services.SupplierClient(api).test_connection()
            return Response(result, status=status.HTTP_200_OK if result.get('success') else status.HTTP_400_BAD_REQUEST)
        except services.SupplierAPIError as e:
            return Response({'success': False, 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'], url_path='pull-resources')
    def pull_resources(self, request, pk=None):
        api = self.get_object()
        rtype = request.data.get('resource_type', SupplierResource.ResType.VPS)
        try:
            result = services.pull_resources(api, operator=request.user, resource_type=rtype)
            return Response(result)
        except services.SupplierAPIError as e:
            return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ═══════════════════════════════════════════════════════════════
# § 供应商 POP 关联
# ═══════════════════════════════════════════════════════════════

class SupplierPopBindingViewSet(SupplierModulePermissionMixin, viewsets.ModelViewSet):
    queryset = SupplierPopBinding.objects.select_related('supplier', 'pop_point').all()
    serializer_class = SupplierPopBindingSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['supplier', 'pop_point', 'is_active']
    search_fields = ['external_pop_id', 'external_pop_name', 'supplier__name']


# ═══════════════════════════════════════════════════════════════
# § 供应商资源
# ═══════════════════════════════════════════════════════════════

class SupplierResourceViewSet(SupplierModulePermissionMixin, viewsets.ModelViewSet):
    """供应商资源（多由 API 同步生成）；支持映射 POP / 同步为产品。"""
    queryset = SupplierResource.objects.select_related('supplier', 'pop_point').all()
    serializer_class = SupplierResourceSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['supplier', 'resource_type', 'sync_status', 'pop_point']
    search_fields = ['external_id', 'name', 'region_text']
    ordering_fields = ['updated_at', 'created_at']

    @action(detail=True, methods=['post'])
    def map(self, request, pk=None):
        """映射资源到 POP 点，并可选同步为本地产品。"""
        resource = self.get_object()
        ser = MapResourceSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data

        if data.get('pop_point_id'):
            from resource_manager.models import PopPoint
            try:
                resource.pop_point = PopPoint.objects.get(pk=data['pop_point_id'])
            except PopPoint.DoesNotExist:
                return Response({'detail': 'POP 点不存在'}, status=status.HTTP_404_NOT_FOUND)
            resource.save(update_fields=['pop_point', 'updated_at'])

        if data.get('to_product'):
            try:
                product, created = services.map_resource_to_product(resource, operator=request.user)
            except services.SupplierAPIError as e:
                return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
            return Response({
                'success': True,
                'product_id': product.pk,
                'product_no': product.product_no,
                'created': created,
            })
        return Response(SupplierResourceSerializer(resource).data)


# ═══════════════════════════════════════════════════════════════
# § 同步日志（只读）
# ═══════════════════════════════════════════════════════════════

class SupplierSyncLogViewSet(SupplierModulePermissionMixin, viewsets.ReadOnlyModelViewSet):
    queryset = SupplierSyncLog.objects.select_related('supplier', 'api', 'operator').all()
    serializer_class = SupplierSyncLogSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['supplier', 'api', 'action', 'result']
    ordering = ['-created_at']
