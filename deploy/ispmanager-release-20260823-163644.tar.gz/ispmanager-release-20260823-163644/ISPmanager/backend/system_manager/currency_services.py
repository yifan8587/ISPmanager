"""
system_manager/currency_services.py
币种与信誉额汇率换算。

约定（可在「系统设置 → 账单设置」中调整）：
  - 默认结算币种 default_currency，默认 CNY
  - 1 信誉额(CREDIT)  = credit_rate_cny 元人民币（默认 1.0）
  - 1 美元(USD)       = exchange_rate_usd_cny 元人民币（默认 7.2）
  - 人民币(CNY)        = 基准币种

所有换算以人民币(CNY)为中间基准：先把金额折算到 CNY，再折算到目标币种。
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

from django.utils import timezone

CNY = 'CNY'
USD = 'USD'
EUR = 'EUR'
GBP = 'GBP'
HKD = 'HKD'
JPY = 'JPY'
AUD = 'AUD'
SGD = 'SGD'
CREDIT = 'CREDIT'

CURRENCY_CHOICES = [
    {'value': CNY, 'label': '人民币', 'symbol': '¥'},
    {'value': USD, 'label': '美元', 'symbol': '$'},
    {'value': EUR, 'label': '欧元', 'symbol': '€'},
    {'value': GBP, 'label': '英镑', 'symbol': '£'},
    {'value': HKD, 'label': '港币', 'symbol': 'HK$'},
    {'value': JPY, 'label': '日元', 'symbol': '¥'},
    {'value': AUD, 'label': '澳元', 'symbol': 'A$'},
    {'value': SGD, 'label': '新加坡元', 'symbol': 'S$'},
    {'value': CREDIT, 'label': '信誉额', 'symbol': '积分'},
]

_SYMBOL = {item['value']: item['symbol'] for item in CURRENCY_CHOICES}
_ZERO_DECIMAL_CURRENCIES = frozenset({JPY})


def _dec(v, default='0') -> Decimal:
    try:
        return Decimal(str(v))
    except Exception:  # noqa: BLE001
        return Decimal(default)


def get_rates() -> dict:
    """读取当前汇率配置（以 1 单位币种折算为多少 CNY 表示）。"""
    from .services import get_setting
    usd = _dec(get_setting('exchange_rate_usd_cny', '7.20'), '7.20')
    eur = _dec(get_setting('exchange_rate_eur_cny', '0'), '0')
    gbp = _dec(get_setting('exchange_rate_gbp_cny', '0'), '0')
    hkd = _dec(get_setting('exchange_rate_hkd_cny', '0'), '0')
    jpy = _dec(get_setting('exchange_rate_jpy_cny', '0'), '0')
    aud = _dec(get_setting('exchange_rate_aud_cny', '0'), '0')
    sgd = _dec(get_setting('exchange_rate_sgd_cny', '0'), '0')
    credit = _dec(get_setting('credit_rate_cny', '1.00'), '1.00')
    default_currency = get_setting('default_currency', CNY) or CNY
    return {
        'default_currency': default_currency,
        'to_cny': {
            CNY: Decimal('1'),
            USD: usd,
            EUR: eur,
            GBP: gbp,
            HKD: hkd,
            JPY: jpy,
            AUD: aud,
            SGD: sgd,
            CREDIT: credit,
        },
    }


def currency_symbol(currency: str) -> str:
    return _SYMBOL.get(currency, currency)


def convert(amount, from_currency: str, to_currency: str, rates: dict | None = None) -> Decimal:
    """把 amount 从 from_currency 换算到 to_currency，保留 2 位小数。"""
    amount = _dec(amount)
    if amount == 0:
        return Decimal('0.00')
    from_currency = (from_currency or CNY).upper()
    to_currency = (to_currency or CNY).upper()
    if from_currency == to_currency:
        return amount.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    table = (rates or get_rates())['to_cny']
    rate_from = table.get(from_currency, Decimal('1'))
    rate_to = table.get(to_currency, Decimal('1'))
    cny = amount * rate_from
    result = cny / rate_to if rate_to else cny
    return result.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def conversion_rate(
    from_currency: str,
    to_currency: str,
    rates: dict | None = None,
) -> Decimal:
    """返回 1 单位源币种可兑换的目标币种数量；不允许未知或无效汇率。"""
    from_currency = (from_currency or CNY).upper()
    to_currency = (to_currency or CNY).upper()
    table = (rates or get_rates())['to_cny']
    if from_currency not in table:
        raise ValueError(f'尚未配置 {from_currency} 汇率')
    if to_currency not in table:
        raise ValueError(f'尚未配置 {to_currency} 汇率')
    rate_from = table[from_currency]
    rate_to = table[to_currency]
    if rate_from <= 0 or rate_to <= 0:
        raise ValueError(f'{from_currency}/{to_currency} 汇率必须大于 0')
    return (rate_from / rate_to).quantize(
        Decimal('0.00000001'),
        rounding=ROUND_HALF_UP,
    )


def convert_strict(
    amount,
    from_currency: str,
    to_currency: str,
    rates: dict | None = None,
) -> Decimal:
    rate = conversion_rate(from_currency, to_currency, rates)
    precision = (
        Decimal('1')
        if str(to_currency).upper() in _ZERO_DECIMAL_CURRENCIES
        else Decimal('0.01')
    )
    return (_dec(amount) * rate).quantize(precision, rounding=ROUND_HALF_UP)


def default_currency() -> str:
    from .services import get_setting
    return get_setting('default_currency', CNY) or CNY


def snapshot_rates(*, quote_currency: str = '') -> dict:
    """拍摄当前汇率表，供工单锁定。"""
    rates = get_rates()
    quote = (quote_currency or rates['default_currency'] or CNY).upper()
    return {
        'quote_currency': quote,
        'default_currency': (rates['default_currency'] or CNY).upper(),
        'to_cny': {key: str(value) for key, value in rates['to_cny'].items()},
        'locked_at': timezone.now().isoformat(),
    }


def rates_from_snapshot(snapshot: dict | None) -> dict | None:
    """把工单快照还原成 ``get_rates()`` 同结构；无效则返回 None（回退实时汇率）。"""
    if not snapshot or not isinstance(snapshot, dict):
        return None
    raw = snapshot.get('to_cny') or {}
    if not raw:
        return None
    to_cny = {}
    for key, value in raw.items():
        amount = _dec(value, '0')
        if amount > 0:
            to_cny[str(key).upper()] = amount
    if CNY not in to_cny:
        to_cny[CNY] = Decimal('1')
    if not to_cny:
        return None
    return {
        'default_currency': str(snapshot.get('default_currency') or CNY).upper(),
        'to_cny': to_cny,
    }
