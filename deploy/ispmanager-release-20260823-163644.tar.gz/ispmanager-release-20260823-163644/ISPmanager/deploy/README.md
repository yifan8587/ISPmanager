# ISPmanager / ISPweb 生产部署说明

面向 **Ubuntu 22.04 LTS**（兼容 24.04）+ **nginx** 的一体化方案。  
**不修改业务仓库文件**；配置只写入 `deploy/.env` 与 `/etc/ispmanager.env`。

发布包由 `scripts/package.sh` 生成，目标机**无需 Node**，一键完成安装、迁移、systemd、双站点与 HTTPS。

---

## 一、架构

```
                    ┌──────────────────────── nginx (80/443) ────────────────────────┐
                    │                                                                 │
  admin.example.net │  /            → ISPmanager/frontend/dist  (管理端 SPA)          │
                    │  /admin/      → 反代 gunicorn (Django Admin)                     │
                    │  /api/  /ws/  → 反代 REST / WebSocket                            │
                    │  /static/     → collectstatic                                    │
                    │  /media/      → 上传文件                                         │
                    │                                                                 │
 portal.example.net │  /            → ISPweb/dist  (客户门户 SPA)                      │
                    │  /admin/ /api/ /ws/ /static/ /media/ → 同上                      │
                    └────────────────────────────┬────────────────────────────────────┘
                                                  │ 127.0.0.1:8000
                                   gunicorn + uvicorn worker（systemd: ispmanager.service）
                                                  │
                                               MySQL 8
```

- 后端：Django 6 + DRF + Channels，**需要 Python 3.12**。22.04 上由脚本通过 deadsnakes 安装，不改项目代码。
- 两个 SPA 使用相对路径 `/api`、`/ws`，与页面同域，**无跨域**。
- HTTPS 由 nginx 终止；HTTP 仅保留 ACME 与跳转。证书用 `certbot certonly --webroot` 或自签，**不会**让 certbot 改写站点文件。

---

## 二、标准发布包一键安装

在构建机（本仓库，需 Node）生成压缩包：

```bash
cd ISPmanager/deploy/scripts
bash package.sh
```

产物：`ISPmanager/deploy/ispmanager-release-<时间戳>.tar.gz`  
以及快捷名 `ispmanager-release-latest.tar.gz`。

在 **Ubuntu 22.04** 目标机：

```bash
sudo mkdir -p /opt/app
sudo tar -xzf ispmanager-release-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app

sudo ADMIN_DOMAIN=admin.example.net \
     PORTAL_DOMAIN=portal.example.net \
     CERTBOT_EMAIL=ops@example.net \
     bash install.sh
```

`install.sh` 依次：生成密钥与 `.env` → 装系统依赖（Python 3.12 / nginx / MySQL / certbot）→ 建库 → 装后端依赖 + collectstatic → systemd + nginx → HTTPS → 自检。

| `SSL_MODE` | 行为 |
|------------|------|
| `auto`（默认） | 两域名 A 记录已指向本机则 Let's Encrypt，否则自签 |
| `letsencrypt` | 强制公网证书（80 必须对公网开放） |
| `selfsigned` | 自签，立即 HTTPS（浏览器告警） |
| `skip` | 仅 HTTP |

首次账号与数据库密码写在 `/root/ispmanager-credentials.txt`（600）。

启用 HTTPS 后访问：

- 管理端 `https://管理端域名/`
- 门户 `https://门户域名/`
- Admin `https://管理端域名/admin/`
- API `https://管理端域名/api/`

DNS 后补时：`sudo SSL_MODE=letsencrypt bash /opt/app/ISPmanager/deploy/scripts/setup-ssl.sh`

---

## 三、源码树分步安装（开发机同步到服务器）

目录须同级：

```
/opt/app/ISPmanager
/opt/app/ISPweb
```

```bash
cd /opt/app/ISPmanager/deploy
cp .env.example .env          # 或直接跑 install.sh 自动生成
sudo bash scripts/install.sh
```

等价分步：

```bash
cd scripts
sudo bash 01-init-ubuntu.sh
sudo bash 02-setup-database.sh
bash build.sh
sudo bash deploy.sh
sudo bash setup-ssl.sh
sudo bash verify-install.sh
```

**必改/自动生成**：`ADMIN_DOMAIN`、`PORTAL_DOMAIN`、`DJANGO_SECRET_KEY`、`DJANGO_ALLOWED_HOSTS`、`DB_PASSWORD`。两域名不能相同。  
在线支付另设独立的 `PAYMENT_CONFIG_ENCRYPTION_KEY`，`PAYMENT_FRONTEND_URL` 指向管理端 HTTPS。

`deploy.sh` 会启用：

- `ispmanager-maintenance.timer`（每 15 分钟：履约 / 预占 / 退款 / 降配）
- `ispmanager-daily-jobs.timer`（01:15：流量出账 / 逾期 / SLA / 品质汇总）
- `ispmanager-instance-expiry.timer`（09:00：催缴；默认不停机/回收）

再次执行 `deploy.sh` **不会拆掉已有证书**，有证书则继续渲染 HTTPS 站点。

---

## 四、目录

```
ISPmanager/deploy/
├── README.md
├── .env.example
├── scripts/
│   ├── install.sh              # 一键安装
│   ├── verify-install.sh
│   ├── common.sh
│   ├── 01-init-ubuntu.sh       # 22.04/24.04：Python 3.12 / nginx / mysql / certbot
│   ├── 02-setup-database.sh
│   ├── build.sh
│   ├── deploy.sh
│   ├── setup-ssl.sh            # webroot 签发或自签，再渲染 HTTPS 模板
│   ├── package.sh
│   ├── fix-admin-static-csrf.sh
│   └── manage-service.sh
├── systemd/                    # gunicorn 与定时任务模板
├── nginx/
│   ├── ispmanager.conf.template
│   ├── ispmanager-ssl.conf.template
│   └── snippets/proxy_params.conf
└── gunicorn/gunicorn_conf.py
```

---

## 五、运维

```bash
cd ISPmanager/deploy/scripts
bash manage-service.sh status
sudo bash manage-service.sh restart
bash manage-service.sh logs
sudo bash manage-service.sh update
sudo bash manage-service.sh ssl
bash manage-service.sh verify
```

代码更新：同步新发布包或 git pull 后 `sudo bash manage-service.sh update`。

POP 节点按 IP + 自签证书同步失败（`CERTIFICATE_VERIFY_FAILED`）时，先同步含修复的源码，再执行：

```bash
sudo bash /opt/app/ISPmanager/deploy/patch-pop-selfsigned-ssl.sh
```

该补丁会迁移 `PopPoint.api_verify_ssl`（默认关闭校验）并重启后端。新装请用 `ispmanager-release-latest.tar.gz`。

WebSSH/VNC 多 worker 建议 Redis：

```bash
# deploy/.env
CHANNEL_LAYER_BACKEND=redis
CHANNEL_REDIS_URL=redis://127.0.0.1:6379/0
```

`01-init-ubuntu.sh` 在该配置下会安装 `redis-server`。

---

## 六、设计要点

1. **Django Admin**：`STATIC_URL=/static/`，nginx alias 到 `STATIC_ROOT`。无样式或 CSRF 403 时跑 `fix-admin-static-csrf.sh`。
2. **HTTPS 识别**：`DJANGO_SECURE_PROXY_SSL_HEADER=True`，nginx 传 `X-Forwarded-Proto`。
3. **CSRF/CORS**：按域名生成 `https://域名`（及 http 备用）。
4. **生产启动校验**：`DJANGO_DEBUG=False` 时拒绝默认 SECRET、`ALLOWED_HOSTS=*`、CORS 全放行。
5. **权限**：nginx 需能遍历到 `dist` / `staticfiles`；脚本会补齐路径执行位。

---

## 七、排查

| 现象 | 处理 |
|------|------|
| 后端起不来 | `journalctl -u ispmanager -n 50`（密钥 / 库密码 / ALLOWED_HOSTS） |
| Python 版本不对 | 22.04 须有 `python3.12`；删掉旧 `venv` 后重跑 `build.sh` |
| admin 无样式 | `sudo bash fix-admin-static-csrf.sh` |
| 前端刷新 404 | nginx `try_files ... /index.html` |
| noVNC 失败 | `/ws/` 是否带 Upgrade；gunicorn 是否 uvicorn worker |
| certbot 失败 | DNS A 记录、80 端口、或先 `SSL_MODE=selfsigned` |
| 重跑 deploy 丢 HTTPS | 当前脚本会检测已有证书并重新渲染 SSL 模板 |

---

## 八、端口

| 组件 | 监听 | 说明 |
|------|------|------|
| nginx | 80 / 443 | 对外入口；80 仅 ACME 与跳转 |
| gunicorn | 127.0.0.1:8000 | 仅本机 |
| MySQL | 127.0.0.1:3306 | 仅本机 |

运行时环境：`/etc/ispmanager.env`  
nginx 站点：`/etc/nginx/sites-available/ispmanager.conf`
