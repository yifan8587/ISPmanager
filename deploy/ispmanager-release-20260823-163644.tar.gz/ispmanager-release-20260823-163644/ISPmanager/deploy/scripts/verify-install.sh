#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# verify-install.sh — 部署后自检（nginx / 后端 / 前后端入口 / 静态）
# 用法：sudo bash verify-install.sh
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env

fail=0
check() {
    local title="$1"
    shift
    if "$@"; then
        ok "$title"
    else
        err "$title"
        fail=1
    fi
}

http_code() {
    curl -fsS -o /dev/null -w '%{http_code}' --max-time 15 "$@"
}

step "服务进程"
if has_systemd; then
    check "ispmanager.service 运行中" systemctl is-active --quiet ispmanager.service
    check "nginx 运行中" systemctl is-active --quiet nginx
else
    check "nginx 可执行" command -v nginx
fi

step "本机后端"
code="$(http_code "http://${APP_BIND}/api/" || echo 000)"
if [[ "$code" =~ ^(200|301|302|401|403)$ ]]; then
    ok "gunicorn 本机探测 HTTP $code （$APP_BIND/api/）"
else
    err "gunicorn 本机探测失败 HTTP $code"
    fail=1
fi

SCHEME=http
CURL_EXTRA=()
if ssl_material_ready; then
    SCHEME=https
    CURL_EXTRA=(-k)
fi

probe() {
    local host="$1" path="$2" expect="$3" title="$4"
    local args=(-sS -o /dev/null -w '%{http_code}' --max-time 15 -H "Host: ${host}")
    if [[ "$SCHEME" == "https" ]]; then
        args+=(-k --resolve "${host}:443:127.0.0.1" "https://${host}${path}")
    else
        args+=(--resolve "${host}:80:127.0.0.1" "http://${host}${path}")
    fi
    local got
    got="$(curl "${args[@]}" || echo 000)"
    if [[ ",${expect}," == *",${got},"* ]]; then
        ok "$title  HTTP $got"
    else
        err "$title  HTTP $got（期望 ${expect}）"
        fail=1
    fi
}

step "HTTPS/HTTP 入口"
probe "$ADMIN_DOMAIN" "/" "200" "管理端 SPA"
probe "$ADMIN_DOMAIN" "/admin/login/" "200,302" "Django Admin"
probe "$ADMIN_DOMAIN" "/static/admin/css/base.css" "200" "Admin 静态 CSS"
probe "$ADMIN_DOMAIN" "/api/" "200,401,403" "管理端 API"
probe "$PORTAL_DOMAIN" "/" "200" "客户门户 SPA"
probe "$PORTAL_DOMAIN" "/api/" "200,401,403" "门户 API"

if [[ -f "$DJANGO_STATIC_ROOT/admin/css/base.css" ]]; then
    ok "collectstatic 文件存在"
else
    err "缺少 $DJANGO_STATIC_ROOT/admin/css/base.css"
    fail=1
fi
if [[ -f "$ADMIN_FRONTEND_DIR/dist/index.html" && -f "$PORTAL_FRONTEND_DIR/dist/index.html" ]]; then
    ok "两个前端 dist 存在"
else
    err "前端 dist 缺失"
    fail=1
fi

echo
if [[ "$fail" -eq 0 ]]; then
    ok "自检通过：${SCHEME}://$ADMIN_DOMAIN/  与  ${SCHEME}://$PORTAL_DOMAIN/"
    exit 0
fi
err "自检存在失败项，请查看上方输出与 journalctl -u ispmanager -n 50"
exit 1
