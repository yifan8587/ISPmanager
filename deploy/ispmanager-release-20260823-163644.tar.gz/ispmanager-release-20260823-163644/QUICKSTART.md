# ISPmanager / ISPweb 快速部署（发布包）

目标系统：**Ubuntu 22.04 LTS**（亦支持 24.04），nginx 终止 HTTPS。
本包已含后端源码、管理端/门户 `dist`、部署脚本。**目标机无需安装 Node。**

不修改业务代码。配置只写在 `ISPmanager/deploy/.env` 与 `/etc/ispmanager.env`。

## 一键安装（推荐）

```bash
sudo mkdir -p /opt/app
sudo tar -xzf ispmanager-release-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app

sudo ADMIN_DOMAIN=admin.example.net \
     PORTAL_DOMAIN=portal.example.net \
     CERTBOT_EMAIL=ops@example.net \
     bash install.sh
```

- 两个域名的 **A 记录已指向服务器** 时，自动申请 Let's Encrypt，全站 HTTPS（管理端、门户、`/api/`、`/ws/`、`/admin/`）。
- DNS 未就绪时自动使用自签证书，仍走 HTTPS（浏览器会提示不受信任）。之后执行：

```bash
sudo SSL_MODE=letsencrypt bash /opt/app/ISPmanager/deploy/scripts/setup-ssl.sh
```

- 仅内网、只要 HTTP：`sudo SSL_MODE=skip bash install.sh`

首次超级管理员与数据库密码写入：`/root/ispmanager-credentials.txt`（权限 600）。

## 访问

- 管理端：`https://管理端域名/`
- 客户门户：`https://门户域名/`
- Django Admin：`https://管理端域名/admin/`
- API：`https://管理端域名/api/`

前端请求同源 `/api` 与 `/ws`，由 nginx 反代到本机 gunicorn，无跨域。

## 分步安装

```bash
cd /opt/app/ISPmanager/deploy
cp .env.example .env
# 编辑域名与密码，或交给 install.sh 自动生成
cd scripts
sudo bash 01-init-ubuntu.sh
sudo bash 02-setup-database.sh
bash build.sh
sudo bash deploy.sh
sudo bash setup-ssl.sh
sudo bash verify-install.sh
```

详见 `ISPmanager/deploy/README.md`。
