#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# install.sh — Ubuntu 22.04 / 24.04 + nginx 一键安装部署
#   不修改业务仓库源码，只使用本目录部署脚本。
#
# 用法（发布包解压后）：
#   sudo SITE_DOMAIN=www.example.net \
#        CERTBOT_EMAIL=ops@example.net \
#        bash install.sh
#
#   sudo SSL_MODE=selfsigned SITE_DOMAIN=www.example.net bash install.sh
#   sudo SSL_MODE=skip bash install.sh          # 仅 HTTP
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
require_root

CRED_FILE="/root/ispmanager-credentials.txt"
ENV_FILE="$DEPLOY_DIR/.env"
EXAMPLE_FILE="$DEPLOY_DIR/.env.example"

prompt_value() {
    local prompt="$1" default="$2" result=""
    if [[ -t 0 && "${NONINTERACTIVE:-0}" != "1" ]]; then
        read -r -p "$prompt [${default}]: " result
        echo "${result:-$default}"
    else
        echo "$default"
    fi
}

prepare_env() {
    local cli_site="${SITE_DOMAIN:-}"
    local cli_admin="${ADMIN_DOMAIN:-}"
    local cli_portal="${PORTAL_DOMAIN:-}"
    local cli_email="${CERTBOT_EMAIL:-}"
    local cli_ssl="${SSL_MODE:-}"
    local cli_db_pass="${DB_PASSWORD:-}"
    local cli_secret="${DJANGO_SECRET_KEY:-}"
    local cli_base="${ADMIN_BASE_PATH:-}"

    if [[ ! -f "$ENV_FILE" ]]; then
        [[ -f "$EXAMPLE_FILE" ]] || die "缺少 $EXAMPLE_FILE"
        cp "$EXAMPLE_FILE" "$ENV_FILE"
        ok "已从 .env.example 生成 $ENV_FILE"
    fi

    set -a
    # shellcheck disable=SC1090
    source "$ENV_FILE"
    set +a

    [[ -n "$cli_site" ]] && SITE_DOMAIN="$cli_site"
    [[ -n "$cli_admin" ]] && ADMIN_DOMAIN="$cli_admin"
    [[ -n "$cli_portal" ]] && PORTAL_DOMAIN="$cli_portal"
    [[ -n "$cli_email" ]] && CERTBOT_EMAIL="$cli_email"
    [[ -n "$cli_ssl" ]] && SSL_MODE="$cli_ssl"
    [[ -n "$cli_db_pass" ]] && DB_PASSWORD="$cli_db_pass"
    [[ -n "$cli_secret" ]] && DJANGO_SECRET_KEY="$cli_secret"
    [[ -n "$cli_base" ]] && ADMIN_BASE_PATH="$cli_base"

    CERTBOT_EMAIL="${CERTBOT_EMAIL:-}"
    SSL_MODE="${SSL_MODE:-auto}"
    ADMIN_BASE_PATH="${ADMIN_BASE_PATH:-/manager}"
    normalize_site_settings

    if [[ "$SITE_DOMAIN" == *example.com ]]; then
        SITE_DOMAIN="$(prompt_value "站点域名（门户 /、管理端 /manager、后台 /admin/）" "$SITE_DOMAIN")"
        CERTBOT_EMAIL="$(prompt_value "Let's Encrypt 通知邮箱（可空）" "${CERTBOT_EMAIL:-}")"
        export SITE_DOMAIN
        normalize_site_settings
    fi

    if is_placeholder "${DJANGO_SECRET_KEY:-}"; then
        DJANGO_SECRET_KEY="$(gen_secret)"
    fi
    if is_placeholder "${PAYMENT_CONFIG_ENCRYPTION_KEY:-}"; then
        PAYMENT_CONFIG_ENCRYPTION_KEY="$(gen_secret)"
    fi
    if is_placeholder "${DB_PASSWORD:-}"; then
        DB_PASSWORD="$(gen_password)"
    fi
    if is_placeholder "${MYSQL_ROOT_PASSWORD:-}"; then
        MYSQL_ROOT_PASSWORD=""
    fi
    if is_placeholder "${DJANGO_SUPERUSER_PASSWORD:-}"; then
        DJANGO_SUPERUSER_PASSWORD="$(gen_password)"
    fi
    DJANGO_SUPERUSER_USERNAME="${DJANGO_SUPERUSER_USERNAME:-admin}"
    DJANGO_SUPERUSER_EMAIL="${DJANGO_SUPERUSER_EMAIL:-admin@${SITE_DOMAIN}}"

    local hosts extras ip
    hosts="${SITE_DOMAIN},127.0.0.1,localhost"
    extras="$(hostname -I 2>/dev/null || true)"
    for ip in $extras; do
        [[ "$ip" == *:* ]] && continue
        hosts="$(merge_csv_unique "${hosts},${ip}")"
    done
    if ip="$(detect_public_ip || true)"; then
        hosts="$(merge_csv_unique "${hosts},${ip}")"
    fi
    if [[ -n "${SITE_ALIASES:-}" ]]; then
        local alias
        for alias in $SITE_ALIASES; do
            hosts="$(merge_csv_unique "${hosts},${alias}")"
        done
    fi
    if [[ -z "${DJANGO_ALLOWED_HOSTS:-}" || "$DJANGO_ALLOWED_HOSTS" == "*" || "$DJANGO_ALLOWED_HOSTS" == *example.com* ]]; then
        DJANGO_ALLOWED_HOSTS="$hosts"
    else
        DJANGO_ALLOWED_HOSTS="$(merge_csv_unique "${DJANGO_ALLOWED_HOSTS},${hosts}")"
    fi

    DJANGO_DEBUG=False
    DJANGO_PRODUCTION=True
    if [[ "$SSL_MODE" == "skip" ]]; then
        PUBLIC_PORT="${PUBLIC_PORT:-80}"
        ADMIN_PUBLIC_PORT="$PUBLIC_PORT"
        PORTAL_PUBLIC_PORT="$PUBLIC_PORT"
        DJANGO_SECURE_PROXY_SSL_HEADER=False
        ensure_payment_frontend_url http
    else
        PUBLIC_PORT="${PUBLIC_PORT:-443}"
        ADMIN_PUBLIC_PORT="$PUBLIC_PORT"
        PORTAL_PUBLIC_PORT="$PUBLIC_PORT"
        DJANGO_SECURE_PROXY_SSL_HEADER=True
        ensure_payment_frontend_url https
    fi

    export SITE_DOMAIN ADMIN_DOMAIN PORTAL_DOMAIN ADMIN_BASE_PATH
    export CERTBOT_EMAIL SSL_MODE
    export DJANGO_SECRET_KEY PAYMENT_CONFIG_ENCRYPTION_KEY
    export DB_PASSWORD MYSQL_ROOT_PASSWORD
    export DJANGO_SUPERUSER_USERNAME DJANGO_SUPERUSER_PASSWORD DJANGO_SUPERUSER_EMAIL
    export DJANGO_ALLOWED_HOSTS DJANGO_DEBUG DJANGO_PRODUCTION
    export PUBLIC_PORT ADMIN_PUBLIC_PORT PORTAL_PUBLIC_PORT
    export DJANGO_SECURE_PROXY_SSL_HEADER PAYMENT_FRONTEND_URL
    apply_public_origins

    upsert_env_file "$ENV_FILE" SITE_DOMAIN "$SITE_DOMAIN"
    upsert_env_file "$ENV_FILE" ADMIN_BASE_PATH "$ADMIN_BASE_PATH"
    upsert_env_file "$ENV_FILE" ADMIN_DOMAIN "$SITE_DOMAIN"
    upsert_env_file "$ENV_FILE" PORTAL_DOMAIN "$SITE_DOMAIN"
    upsert_env_file "$ENV_FILE" CERTBOT_EMAIL "${CERTBOT_EMAIL:-}"
    upsert_env_file "$ENV_FILE" SSL_MODE "$SSL_MODE"
    upsert_env_file "$ENV_FILE" DJANGO_SECRET_KEY "$DJANGO_SECRET_KEY"
    upsert_env_file "$ENV_FILE" PAYMENT_CONFIG_ENCRYPTION_KEY "$PAYMENT_CONFIG_ENCRYPTION_KEY"
    upsert_env_file "$ENV_FILE" PAYMENT_FRONTEND_URL "$PAYMENT_FRONTEND_URL"
    upsert_env_file "$ENV_FILE" DJANGO_DEBUG False
    upsert_env_file "$ENV_FILE" DJANGO_PRODUCTION True
    upsert_env_file "$ENV_FILE" DJANGO_ALLOWED_HOSTS "$DJANGO_ALLOWED_HOSTS"
    upsert_env_file "$ENV_FILE" PUBLIC_PORT "$PUBLIC_PORT"
    upsert_env_file "$ENV_FILE" ADMIN_PUBLIC_PORT "$ADMIN_PUBLIC_PORT"
    upsert_env_file "$ENV_FILE" PORTAL_PUBLIC_PORT "$PORTAL_PUBLIC_PORT"
    upsert_env_file "$ENV_FILE" DJANGO_CSRF_TRUSTED_ORIGINS "$DJANGO_CSRF_TRUSTED_ORIGINS"
    upsert_env_file "$ENV_FILE" DJANGO_CORS_ALLOWED_ORIGINS "$DJANGO_CORS_ALLOWED_ORIGINS"
    upsert_env_file "$ENV_FILE" DJANGO_SECURE_PROXY_SSL_HEADER "$DJANGO_SECURE_PROXY_SSL_HEADER"
    upsert_env_file "$ENV_FILE" DB_PASSWORD "$DB_PASSWORD"
    upsert_env_file "$ENV_FILE" DJANGO_SUPERUSER_USERNAME "$DJANGO_SUPERUSER_USERNAME"
    upsert_env_file "$ENV_FILE" DJANGO_SUPERUSER_PASSWORD "$DJANGO_SUPERUSER_PASSWORD"
    upsert_env_file "$ENV_FILE" DJANGO_SUPERUSER_EMAIL "$DJANGO_SUPERUSER_EMAIL"

    ok "部署配置已写入 $ENV_FILE"
}

write_credentials() {
    local scheme="http"
    ssl_material_ready && scheme="https"
    umask 077
    cat > "$CRED_FILE" <<EOF
# ISPmanager 首次安装凭据（权限 600）。请立即备份后限制查阅。
installed_at=$(date -Iseconds)
site_domain=${SITE_DOMAIN}
portal_url=${scheme}://${SITE_DOMAIN}/
admin_url=${scheme}://${SITE_DOMAIN}${ADMIN_BASE_PATH}
django_admin=${scheme}://${SITE_DOMAIN}/admin/
api_docs=${scheme}://${SITE_DOMAIN}/api/docs/
ssl_mode=${SSL_MODE}
django_superuser=${DJANGO_SUPERUSER_USERNAME}
django_superuser_password=${DJANGO_SUPERUSER_PASSWORD}
db_name=${DB_NAME}
db_user=${DB_USER}
db_password=${DB_PASSWORD}
env_file=${ENV_FILE}
runtime_env=${RUNTIME_ENV_FILE}
EOF
    chmod 600 "$CRED_FILE"
}

step "0/6 准备配置"
prepare_env
load_env

if both_frontends_prebuilt; then
    export SKIP_NODE=1
    log "发布包已含前端 dist，系统初始化将跳过 Node.js"
fi

step "1/6 初始化系统"
bash "$SCRIPT_DIR/01-init-ubuntu.sh"

step "2/6 初始化数据库"
bash "$SCRIPT_DIR/02-setup-database.sh"

step "3/6 构建依赖与静态资源"
# 发布包跳过 npm；源码树则现场构建
if both_frontends_prebuilt; then
    SKIP_FRONTEND_BUILD=1 bash "$SCRIPT_DIR/build.sh"
else
    bash "$SCRIPT_DIR/build.sh"
fi

step "4/6 部署 systemd + nginx"
bash "$SCRIPT_DIR/deploy.sh"

step "5/6 启用 HTTPS"
if [[ "$SSL_MODE" == "skip" ]]; then
    log "SSL_MODE=skip，保持 HTTP"
else
    bash "$SCRIPT_DIR/setup-ssl.sh"
fi

step "6/6 自检"
write_credentials
set +e
bash "$SCRIPT_DIR/verify-install.sh"
verify_rc=$?
set -e

echo
ok "════════════════════════════════════════════════════"
ok " 一键安装完成"
ok "════════════════════════════════════════════════════"
if ssl_material_ready; then
    print_site_urls https
else
    print_site_urls http
fi
echo -e "  凭据文件： $CRED_FILE"
echo -e "  服务状态： bash $SCRIPT_DIR/manage-service.sh status"
if [[ "$verify_rc" -ne 0 ]]; then
    warn "自检未完全通过，请根据上方输出排查（服务可能已可用）"
    exit "$verify_rc"
fi
