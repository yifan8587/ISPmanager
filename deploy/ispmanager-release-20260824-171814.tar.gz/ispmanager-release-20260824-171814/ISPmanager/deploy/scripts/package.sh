#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# package.sh — 生成标准部署压缩包
#   构建两个前端 → 收集后端源码 + 预构建 dist + 部署脚本 → tar.gz
#   解压后 ISPmanager/ 与 ISPweb/ 同级，目标机 Ubuntu 22.04 无需 Node。
#
# 用法：
#   bash package.sh
#   SKIP_BUILD=1 bash package.sh
#   OUTPUT_DIR=/tmp bash package.sh
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env

SKIP_BUILD="${SKIP_BUILD:-0}"
OUTPUT_DIR="${OUTPUT_DIR:-$DEPLOY_DIR}"
TS="$(date +%Y%m%d-%H%M%S)"
RELEASE_NAME="ispmanager-release-$TS"
STAGE="$(mktemp -d)"
RELEASE_ROOT="$STAGE/$RELEASE_NAME"
ARCHIVE="$OUTPUT_DIR/$RELEASE_NAME.tar.gz"

cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

step "1/4 构建前端产物"
if [[ "$SKIP_BUILD" == "1" ]]; then
    log "SKIP_BUILD=1：跳过构建，复用现有 dist"
else
    command -v npm >/dev/null 2>&1 || die "未找到 npm，无法构建前端（或设 SKIP_BUILD=1 复用现有 dist）"
    for spec in "管理端:$ADMIN_FRONTEND_DIR" "客户门户:$PORTAL_FRONTEND_DIR"; do
        name="${spec%%:*}"
        d="${spec#*:}"
        [[ -d "$d" ]] || { warn "目录不存在，跳过：$d"; continue; }
        [[ -f "$d/package.json" ]] || die "$name 缺少 package.json：$d/package.json"
        [[ -f "$d/index.html" ]] || die "$name 缺少 index.html：$d/index.html"
        log "构建：$d"
        pushd "$d" >/dev/null
        if [[ "$name" == "管理端" ]]; then
            export VITE_BASE_PATH="${VITE_BASE_PATH:-${ADMIN_BASE_PATH:-/manager}/}"
            log "管理端生产 base：${VITE_BASE_PATH}"
        fi
        if [[ -f package-lock.json ]]; then npm ci || npm install; else npm install; fi
        npm run build
        popd >/dev/null
    done
fi

require_frontend_dist "管理端" "$ADMIN_FRONTEND_DIR"
require_admin_dist_base
require_frontend_dist "客户门户" "$PORTAL_FRONTEND_DIR"
ok "前端产物就绪"

step "2/4 收集部署文件"
mkdir -p "$RELEASE_ROOT/ISPmanager/frontend" "$RELEASE_ROOT/ISPweb"

log "打包后端源码与 deploy 配置..."
tar -cf - -C "$PROJECT_ROOT/ISPmanager" \
    --exclude='venv' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='*.pyo' \
    --exclude='.git' \
    --exclude='backend/staticfiles' \
    --exclude='backend/media' \
    --exclude='backend/*.sqlite3' \
    --exclude='backend/db.sqlite3' \
    --exclude='deploy/.env' \
    --exclude='deploy/*.tar.gz' \
    --exclude='deploy/*.tar.gz.sha256' \
    --exclude='deploy/build' \
    backend deploy \
    | tar -xf - -C "$RELEASE_ROOT/ISPmanager"

log "复制管理端 dist..."
mkdir -p "$RELEASE_ROOT/ISPmanager/frontend/dist"
cp -r "$ADMIN_FRONTEND_DIR/dist/." "$RELEASE_ROOT/ISPmanager/frontend/dist/"
cat > "$RELEASE_ROOT/ISPmanager/frontend/.prebuilt-dist" <<EOF
# 预构建管理端，目标机无需 Node / npm
packaged_at=$(date -Iseconds)
admin_dist_files=$(find "$RELEASE_ROOT/ISPmanager/frontend/dist" -type f | wc -l)
EOF

log "复制门户 dist..."
mkdir -p "$RELEASE_ROOT/ISPweb/dist"
cp -r "$PORTAL_FRONTEND_DIR/dist/." "$RELEASE_ROOT/ISPweb/dist/"
cat > "$RELEASE_ROOT/ISPweb/.prebuilt-dist" <<EOF
# 预构建客户门户
packaged_at=$(date -Iseconds)
portal_dist_files=$(find "$RELEASE_ROOT/ISPweb/dist" -type f | wc -l)
EOF

cat > "$RELEASE_ROOT/ISPmanager/deploy/VERSION" <<EOF
name=ispmanager-ispweb
release=$RELEASE_NAME
packaged_at=$(date -Iseconds)
target_os=Ubuntu 22.04 / 24.04
https=nginx 443
python=3.12
EOF

step "3/4 生成解压后入口脚本与说明"
cat > "$RELEASE_ROOT/install.sh" <<'WRAP'
#!/usr/bin/env bash
# 发布包入口：转到部署脚本执行一键安装
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$ROOT/ISPmanager/deploy/scripts/install.sh" "$@"
WRAP
chmod +x "$RELEASE_ROOT/install.sh"

cat > "$RELEASE_ROOT/QUICKSTART.md" <<'QS'
# ISPmanager / ISPweb 快速部署（发布包）

目标系统：**Ubuntu 22.04 LTS**（亦支持 24.04），nginx 终止 HTTPS。
本包已含后端源码、管理端/门户 `dist`、部署脚本。**目标机无需安装 Node。**

不修改业务代码。配置只写在 `ISPmanager/deploy/.env` 与 `/etc/ispmanager.env`。

## 一键安装（推荐）

```bash
sudo mkdir -p /opt/app
sudo tar -xzf ispmanager-release-*.tar.gz -C /opt/app --strip-components=1
cd /opt/app

sudo SITE_DOMAIN=www.example.net \
     CERTBOT_EMAIL=ops@example.net \
     bash install.sh
```

- 站点域名的 **A 记录已指向服务器** 时，自动申请 Let's Encrypt，全站 HTTPS（门户 `/`、管理端 `/manager`、`/api/`、`/ws/`、`/admin/`）。
- DNS 未就绪时自动使用自签证书，仍走 HTTPS（浏览器会提示不受信任）。之后执行：

```bash
sudo SSL_MODE=letsencrypt bash /opt/app/ISPmanager/deploy/scripts/setup-ssl.sh
```

- 仅内网、只要 HTTP：`sudo SSL_MODE=skip bash install.sh`

首次超级管理员与数据库密码写入：`/root/ispmanager-credentials.txt`（权限 600）。

## 访问

- 客户门户：`https://站点域名/`
- 管理端：`https://站点域名/manager`
- Django Admin：`https://站点域名/admin/`
- API：`https://站点域名/api/`

前端请求同源 `/api` 与 `/ws`，由 nginx 反代到本机 gunicorn，无跨域。

## 分步安装

```bash
cd /opt/app/ISPmanager/deploy
cp .env.example .env
# 编辑域名与密码，或交给 install.sh 自动生成
cd scripts
sudo bash 01-init-ubuntu.sh
sudo bash 02-setup-database.sh
bash build.sh
sudo bash deploy.sh
sudo bash setup-ssl.sh
sudo bash verify-install.sh
```

详见 `ISPmanager/deploy/README.md`。
QS

ok "入口与 QUICKSTART 已生成"

step "4/4 生成压缩包"
mkdir -p "$OUTPUT_DIR"
tar -czf "$ARCHIVE" -C "$STAGE" "$RELEASE_NAME"

if command -v sha256sum >/dev/null 2>&1; then
    ( cd "$OUTPUT_DIR" && sha256sum "$(basename "$ARCHIVE")" > "$ARCHIVE.sha256" )
fi

# 稳定文件名（实体副本，便于 scp，避免断链）
STABLE="$OUTPUT_DIR/ispmanager-release-latest.tar.gz"
rm -f "$STABLE" "$STABLE.sha256"
cp -f "$ARCHIVE" "$STABLE"
( cd "$OUTPUT_DIR" && sha256sum "$(basename "$STABLE")" > "$(basename "$STABLE").sha256" )

SIZE="$(du -h "$ARCHIVE" | cut -f1)"
echo
ok "════════════════════════════════════════════════════"
ok " 标准部署包已生成"
ok "════════════════════════════════════════════════════"
echo -e "  发布包： $ARCHIVE  ($SIZE)"
[[ -f "$ARCHIVE.sha256" ]] && echo -e "  校验和： $ARCHIVE.sha256"
echo -e "  快捷名： $STABLE"
echo -e "  内容：   ISPmanager(backend+frontend/dist+deploy) + ISPweb/dist + install.sh"
echo
echo -e "  目标机： sudo tar -xzf $(basename "$ARCHIVE") -C /opt/app --strip-components=1"
echo -e "           cd /opt/app && sudo SITE_DOMAIN=www.example.net bash install.sh"
