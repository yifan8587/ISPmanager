#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# setup-ssl.sh — 为站点启用 HTTPS（不改写业务代码）
#   用 certbot certonly --webroot 或自签证书，再渲染我们自己的 nginx 模板。
#   不会调用 certbot --nginx，避免覆盖站点配置。
#
# 用法：
#   sudo bash setup-ssl.sh                 # 按 .env 的 SSL_MODE（默认 auto）
#   sudo SSL_MODE=letsencrypt bash setup-ssl.sh
#   sudo SSL_MODE=selfsigned  bash setup-ssl.sh
#   sudo bash setup-ssl.sh www.example.net
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env
require_root

command -v openssl >/dev/null 2>&1 || die "未找到 openssl"
command -v nginx >/dev/null 2>&1 || die "未找到 nginx，请先执行 01-init-ubuntu.sh"

if [[ $# -ge 1 ]]; then
    if [[ $# -ge 2 && "$1" != "$2" ]]; then
        warn "已改为单域名路径分流，忽略第二个参数 $2，使用 SITE_DOMAIN=$1"
    fi
    SITE_DOMAIN="$1"
    export SITE_DOMAIN
    normalize_site_settings
    apply_public_origins
fi

MODE="${SSL_MODE:-auto}"
EMAIL="${CERTBOT_EMAIL:-}"

[[ -n "$SITE_DOMAIN" ]] || die "未配置 SITE_DOMAIN"

is_example_domain() {
    [[ "$1" == *example.com ]]
}

issue_letsencrypt() {
    command -v certbot >/dev/null 2>&1 || die "未找到 certbot，请先执行 01-init-ubuntu.sh"
    mkdir -p "$CERTBOT_WEBROOT"
    chmod a+rX "$CERTBOT_WEBROOT"

    local mail_args=()
    if [[ -n "$EMAIL" ]] && ! is_placeholder "$EMAIL" email; then
        mail_args=(--email "$EMAIL" --no-eff-email)
    else
        warn "CERTBOT_EMAIL 未配置，使用 --register-unsafely-without-email"
        mail_args=(--register-unsafely-without-email)
    fi

    local domain_args=(-d "$SITE_DOMAIN")
    local alias
    for alias in ${SITE_ALIASES:-}; do
        [[ -n "$alias" ]] || continue
        domain_args+=(-d "$alias")
    done

    log "申请 Let's Encrypt：${SITE_DOMAIN} ${SITE_ALIASES:-}"
    certbot certonly --webroot -w "$CERTBOT_WEBROOT" \
        "${domain_args[@]}" \
        "${mail_args[@]}" \
        --agree-tos \
        --non-interactive \
        --keep-until-expiring \
        --cert-name "$SITE_DOMAIN"
}

issue_selfsigned() {
    mkdir -p "$SELF_SIGNED_DIR"
    local key="$SELF_SIGNED_DIR/privkey.pem"
    local crt="$SELF_SIGNED_DIR/fullchain.pem"
    local conf="$SELF_SIGNED_DIR/san.cnf"
    local dns_lines="DNS.1 = ${SITE_DOMAIN}"
    local idx=2 alias
    for alias in ${SITE_ALIASES:-}; do
        [[ -n "$alias" ]] || continue
        dns_lines="${dns_lines}"$'\n'"DNS.${idx} = ${alias}"
        idx=$((idx + 1))
    done
    cat > "$conf" <<EOF
[req]
default_bits = 2048
prompt = no
default_md = sha256
distinguished_name = dn
x509_extensions = v3_req

[dn]
CN = ${SITE_DOMAIN}

[v3_req]
subjectAltName = @alt_names
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

[alt_names]
${dns_lines}
IP.1 = 127.0.0.1
EOF
    openssl req -x509 -nodes -newkey rsa:2048 -days 825 \
        -keyout "$key" -out "$crt" -config "$conf"
    chmod 640 "$key"
    chmod 644 "$crt"
    chown root:"$APP_GROUP" "$key" "$crt" 2>/dev/null || true
    ok "已生成自签证书（浏览器会提示不受信任，可用 /etc/hosts 解析域名后访问）"
}

enable_https_runtime() {
    export DJANGO_SECURE_PROXY_SSL_HEADER=True
    export PUBLIC_PORT=443
    export ADMIN_PUBLIC_PORT=443
    export PORTAL_PUBLIC_PORT=443
    ensure_payment_frontend_url https
    apply_public_origins
    write_runtime_env "$RUNTIME_ENV_FILE"

    local env_file="$DEPLOY_DIR/.env"
    if [[ -f "$env_file" ]]; then
        upsert_env_file "$env_file" SITE_DOMAIN "$SITE_DOMAIN"
        upsert_env_file "$env_file" ADMIN_DOMAIN "$SITE_DOMAIN"
        upsert_env_file "$env_file" PORTAL_DOMAIN "$SITE_DOMAIN"
        upsert_env_file "$env_file" ADMIN_BASE_PATH "$ADMIN_BASE_PATH"
        upsert_env_file "$env_file" DJANGO_SECURE_PROXY_SSL_HEADER True
        upsert_env_file "$env_file" PUBLIC_PORT 443
        upsert_env_file "$env_file" ADMIN_PUBLIC_PORT 443
        upsert_env_file "$env_file" PORTAL_PUBLIC_PORT 443
        upsert_env_file "$env_file" PAYMENT_FRONTEND_URL "$PAYMENT_FRONTEND_URL"
        upsert_env_file "$env_file" DJANGO_CSRF_TRUSTED_ORIGINS "$DJANGO_CSRF_TRUSTED_ORIGINS"
        upsert_env_file "$env_file" DJANGO_CORS_ALLOWED_ORIGINS "$DJANGO_CORS_ALLOWED_ORIGINS"
    fi

    if has_systemd && systemctl is-enabled ispmanager.service >/dev/null 2>&1; then
        systemctl restart ispmanager.service
        sleep 1
        systemctl is-active --quiet ispmanager.service || {
            journalctl -u ispmanager -n 20 --no-pager || true
            die "启用 HTTPS 后后端重启失败"
        }
    fi
}

decide_auto_mode() {
    if is_example_domain "$SITE_DOMAIN"; then
        warn "域名为 example.com，自动改用自签证书"
        echo selfsigned
        return
    fi
    local public_ip
    public_ip="$(detect_public_ip || true)"
    if [[ -z "$public_ip" ]]; then
        warn "无法探测公网 IP，自动改用自签证书"
        echo selfsigned
        return
    fi
    log "本机公网 IP：$public_ip"
    if domain_points_here "$SITE_DOMAIN" "$public_ip"; then
        echo letsencrypt
        return
    fi
    warn "DNS 尚未指向本机，自动改用自签证书（解析到位后可再跑：SSL_MODE=letsencrypt sudo bash setup-ssl.sh）"
    echo selfsigned
}

step "选择证书模式（当前 SSL_MODE=$MODE）"
case "$MODE" in
    skip)
        log "SSL_MODE=skip，保持 HTTP"
        exit 0
        ;;
    auto)
        MODE="$(decide_auto_mode)"
        log "auto 决策结果：$MODE"
        ;;
    letsencrypt|selfsigned)
        ;;
    *)
        die "未知 SSL_MODE=$MODE（可用 auto|letsencrypt|selfsigned|skip）"
        ;;
esac

if [[ "$MODE" == "letsencrypt" ]]; then
    if is_example_domain "$SITE_DOMAIN"; then
        die "Let's Encrypt 不能使用 example.com，请改真实域名或 SSL_MODE=selfsigned"
    fi
    # ACME 依赖已生效的 HTTP 站点
    if [[ ! -f "$NGINX_AVAIL" ]]; then
        die "尚未部署 nginx 站点，请先 sudo bash deploy.sh"
    fi
    mkdir -p "$CERTBOT_WEBROOT"
    if ! ssl_material_ready; then
        # 确保当前是 HTTP 模板（含 ACME），以便校验
        render_nginx_conf "$NGINX_AVAIL"
        enable_nginx_site
        reload_nginx || true
    fi
    if ! issue_letsencrypt; then
        if [[ "${SSL_MODE:-auto}" == "auto" ]]; then
            warn "Let's Encrypt 失败，回退自签证书"
            MODE=selfsigned
        else
            die "Let's Encrypt 申请失败。确认 80 端口对公网开放，且 ${SITE_DOMAIN} 的 A 记录指向本机"
        fi
    fi
fi

if [[ "$MODE" == "selfsigned" ]]; then
    issue_selfsigned
fi

ssl_material_ready || die "证书文件未就绪，无法启用 HTTPS"

step "渲染 HTTPS nginx 并更新 Django 反代头"
enable_https_runtime
render_nginx_conf "$NGINX_AVAIL"
enable_nginx_site
reload_nginx
ok "nginx 已应用 HTTPS（HTTP 自动跳转）"

if has_systemd; then
    systemctl enable --now certbot.timer 2>/dev/null || true
fi

echo
ok "════════════════════════════════════════════════════"
ok " HTTPS 已启用"
ok "════════════════════════════════════════════════════"
print_site_urls https
if ssl_is_letsencrypt; then
    echo -e "  证书：     Let's Encrypt（certbot.timer 自动续期）"
else
    echo -e "  证书：     自签（浏览器告警属预期）。DNS 就绪后执行："
    echo -e "             sudo SSL_MODE=letsencrypt bash setup-ssl.sh"
fi
