"""生产环境 CSRF / CORS 可信来源展开。

nginx 终止 HTTPS 后，浏览器 Origin 是 https://主机，Django 必须同时认到
反代协议头和完整主机列表，否则 /admin/ 登录 POST 会 403。
"""
from __future__ import annotations


def _clean_host(raw: str) -> str:
    host = (raw or '').strip().rstrip('/')
    if not host or host == '*':
        return ''
    if '://' in host:
        host = host.split('://', 1)[1]
    host = host.split('/', 1)[0].strip()
    if host.startswith('[') and ']' in host:
        return host
    return host


def iter_hosts(*groups) -> list[str]:
    seen: list[str] = []
    for group in groups:
        if group is None:
            continue
        if isinstance(group, str):
            parts = group.replace(';', ',').replace(' ', ',').split(',')
        else:
            parts = list(group)
        for item in parts:
            host = _clean_host(str(item))
            if not host or host.startswith('.'):
                continue
            if host not in seen:
                seen.append(host)
    return seen


def origin_for(scheme: str, host: str, port: str | int | None = None) -> str:
    port_s = '' if port is None else str(port).strip()
    if not port_s or (scheme == 'https' and port_s == '443') or (scheme == 'http' and port_s == '80'):
        return f'{scheme}://{host}'
    if ':' in host and not host.startswith('['):
        return f'{scheme}://{host}'
    return f'{scheme}://{host}:{port_s}'


def expand_trusted_origins(
    *,
    explicit: list[str] | None = None,
    hosts: list[str] | None = None,
    public_port: str | int | None = None,
) -> list[str]:
    origins: list[str] = []
    for item in explicit or []:
        value = (item or '').strip().rstrip('/')
        if value and value not in origins:
            origins.append(value)

    port = str(public_port).strip() if public_port not in (None, '') else ''
    pairs = [('https', '443'), ('http', '80')]
    if port and port not in ('80', '443'):
        pairs.extend([('https', port), ('http', port)])
    for host in hosts or []:
        for scheme, candidate_port in pairs:
            origin = origin_for(scheme, host, candidate_port)
            if origin not in origins:
                origins.append(origin)
    return origins
