#!/usr/bin/env bash
# 在线升级入口：覆盖已由维护模块完成，这里只跑依赖/库/静态同步
set -euo pipefail
DEST="${1:-${ISPMANAGER_ROOT:-}}"
if [[ -z "$DEST" || ! -d "$DEST" ]]; then
    echo "缺少 ISPmanager 根目录" >&2
    exit 1
fi
SCRIPT="$DEST/deploy/scripts/apply-upgrade.sh"
if [[ ! -f "$SCRIPT" ]]; then
    echo "缺少 $SCRIPT，请确认更新包已覆盖 deploy/scripts" >&2
    exit 1
fi
exec bash "$SCRIPT"
