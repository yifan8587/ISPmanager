"""IP 管理：排除隧道段、同 POP 同 CIDR 合并统计、隧道用量带接口/客户。"""
from django.test import TestCase

from customer_manager.models import Customer
from resource_manager.ip_scope import TUNNEL_BLOCK_TAG, group_ip_blocks
from resource_manager.models import (
    City,
    Country,
    EdgeAcceleration,
    IPAddress,
    IPBlock,
    PopPoint,
    Region,
    TunnelIPPool,
)
from resource_manager.serializers import IPBlockSerializer
from resource_manager.tunnel_ip import usage
from resource_manager.views import IPAddressViewSet, IPBlockViewSet


class BusinessIPScopeTests(TestCase):
    def setUp(self):
        region = Region.objects.create(code='ip-scope', name='IP范围区')
        country = Country.objects.create(region=region, name='IP范围国')
        city = City.objects.create(country=country, name='IP范围市')
        self.pop = PopPoint.objects.create(name='业务IP POP', city=city)
        self.biz = IPBlock.objects.create(pop_point=self.pop, cidr='203.0.113.0/24')
        self.tunnel = IPBlock.objects.create(
            pop_point=self.pop, cidr='10.21.0.0/24',
            description=f'{TUNNEL_BLOCK_TAG} 隧道/边缘 IP 段',
        )
        self.biz_ip = IPAddress.objects.create(ip_block=self.biz, address='203.0.113.10')
        self.tun_ip = IPAddress.objects.create(
            ip_block=self.tunnel, address='10.21.0.1',
            interface_code='gre-cust1',
        )

    def test_ip_block_queryset_excludes_tunnel_segments(self):
        ids = list(IPBlockViewSet().get_queryset().values_list('id', flat=True))
        self.assertIn(self.biz.id, ids)
        self.assertNotIn(self.tunnel.id, ids)

    def test_ip_address_queryset_excludes_tunnel_addresses(self):
        from rest_framework.request import Request
        from rest_framework.test import APIRequestFactory

        view = IPAddressViewSet()
        view.request = Request(APIRequestFactory().get('/resource/ip-addresses/'))
        view.request.user = None
        ids = list(view.get_queryset().values_list('id', flat=True))
        self.assertIn(self.biz_ip.id, ids)
        self.assertNotIn(self.tun_ip.id, ids)


class CidrMergeTests(TestCase):
    def setUp(self):
        region = Region.objects.create(code='cidr-merge', name='CIDR合并区')
        country = Country.objects.create(region=region, name='CIDR合并国')
        city = City.objects.create(country=country, name='CIDR合并市')
        self.pop = PopPoint.objects.create(name='CIDR POP', city=city)
        self.block_a = IPBlock.objects.create(
            pop_point=self.pop, cidr='198.51.100.0/24', description='手工录入',
        )
        self.block_b = IPBlock.objects.create(
            pop_point=self.pop, cidr='198.51.100.0/24', description='节点同步导入',
        )
        IPAddress.objects.create(
            ip_block=self.block_a, address='198.51.100.10',
            status=IPAddress.IPStatus.AVAILABLE,
        )
        IPAddress.objects.create(
            ip_block=self.block_b, address='198.51.100.20',
            status=IPAddress.IPStatus.ASSIGNED,
        )

    def test_same_pop_same_cidr_stats_are_merged(self):
        grouped = group_ip_blocks(list(IPBlockViewSet().get_queryset()))
        self.assertEqual(len(grouped), 1)
        row = grouped[0]
        self.assertEqual(row.cidr, '198.51.100.0/24')
        self.assertEqual(row.merged_count, 2)
        self.assertEqual(set(row.member_ids), {self.block_a.id, self.block_b.id})
        data = IPBlockSerializer(row).data
        self.assertEqual(data['ip_stats']['total'], 2)
        self.assertEqual(data['ip_stats']['available'], 1)
        self.assertEqual(data['ip_stats']['assigned'], 1)
        self.assertEqual(data['merged_count'], 2)

    def test_create_rejects_duplicate_business_cidr(self):
        ser = IPBlockSerializer(data={
            'pop_point': self.pop.id,
            'cidr': '198.51.100.0/24',
            'ip_version': 'v4',
        })
        self.assertFalse(ser.is_valid())
        self.assertIn('cidr', ser.errors)


class TunnelUsageCustomerTests(TestCase):
    def setUp(self):
        region = Region.objects.create(code='tun-usage', name='隧道用量区')
        country = Country.objects.create(region=region, name='隧道用量国')
        city = City.objects.create(country=country, name='隧道用量市')
        self.pop = PopPoint.objects.create(name='隧道用量 POP', city=city)
        self.customer = Customer.objects.create(name='隧道客户', contact_name='联系人')
        self.pool = TunnelIPPool.objects.create(
            pop_point=self.pop, name='tokyo-gre', cidr='10.21.0.0/24',
            point_prefixlen=30, customer=self.customer,
        )
        self.edge = EdgeAcceleration.objects.create(
            name='客户隧道',
            protocol=EdgeAcceleration.Protocol.GRE,
            pop_point=self.pop,
            customer=self.customer,
            node_ifname='gre-cust1',
        )
        block = IPBlock.objects.create(
            pop_point=self.pop, cidr='10.21.0.0/24',
            description=f'{TUNNEL_BLOCK_TAG} 隧道/边缘 IP 段',
        )
        IPAddress.objects.create(
            ip_block=block, address='10.21.0.1',
            status=IPAddress.IPStatus.ASSIGNED,
            interface_code='gre-cust1',
            assigned_edge=self.edge,
        )
        IPAddress.objects.create(
            ip_block=block, address='10.21.0.2',
            status=IPAddress.IPStatus.RESERVED,
            interface_code='gre-cust1',
            assigned_edge=self.edge,
        )

    def test_usage_entries_include_interface_and_customer(self):
        data = usage(self.pool)
        self.assertGreaterEqual(data['used_blocks'], 1)
        entry = data['used'][0]['entries'][0]
        self.assertEqual(entry['interface_code'], 'gre-cust1')
        self.assertEqual(entry['customer_name'], '隧道客户')
        self.assertEqual(entry['customer_id'], self.customer.id)
        self.assertEqual(data['used'][0]['interface_code'], 'gre-cust1')
        self.assertEqual(data['used'][0]['customer_name'], '隧道客户')
