#!/usr/bin/env bash
# 全量更新包入口：覆盖程序，保留业务数据
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PACKAGE_PAYLOAD="$ROOT"
exec bash "$ROOT/ISPmanager/deploy/scripts/update-from-package.sh" "$@"
