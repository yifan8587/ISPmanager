# 变更记录 — .env source 语法错误与全新系统安装顺序

**日期**：2026-10-04  
**版本**：`2.0.2`

---

## 问题

全新机执行：

```bash
sudo SITE_DOMAIN=www.10g.hk CERTBOT_EMAIL=ops@10g.hk bash install.sh
```

在「1/7 准备配置」失败：

```
/opt/app/ISPmanager/deploy/.env: line 120: syntax error near unexpected token `newline'
```

`.env.example` 中：

```
DJANGO_DEFAULT_FROM_EMAIL=ISP Manager <noreply@example.com>
```

被 `source` 时，bash 把 `<noreply@example.com>` 当成输入重定向，文件名缺失就报 `newline`。此时系统环境（MySQL / nginx / Python 3.12）还没开始装。

---

## 修复

1. 模板改为  
   `DJANGO_DEFAULT_FROM_EMAIL="ISP Manager <noreply@example.com>"`
2. 所有部署脚本改用 `source_env_file`：按行拆 `KEY=VALUE`，不再 `source` 整文件
3. `upsert_env_file` / `/etc/ispmanager.env` 写入时用 `shlex.quote`
4. 安装顺序改为：**先写模板 → 完整安装系统包 → 再生成密钥与域名**
5. `01-init-ubuntu.sh` 补齐 `python3`、编译依赖、`mysql-client`

已写出半截的 `/opt/app/ISPmanager/deploy/.env` 请删掉再装：

```bash
sudo rm -f /opt/app/ISPmanager/deploy/.env
cd /opt/app
sudo SITE_DOMAIN=www.10g.hk CERTBOT_EMAIL=ops@10g.hk bash install.sh
```

或覆盖解压 **2.0.2 安装包** 后同样删除 `.env` 再执行。
