#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
# setup-ssl.sh — 为站点启用 HTTPS（不改写业务代码）
#   certbot certonly --webroot 或自签，再渲染 nginx 模板。
#   不调用 certbot --nginx，避免覆盖站点。
#   支持内网 NAT：公网 DNS 判断、不覆盖映射端口、80 未转发时不把 HTTP 跳死。
#
# 用法：
#   sudo bash setup-ssl.sh
#   sudo SSL_MODE=letsencrypt bash setup-ssl.sh
#   sudo SSL_MODE=selfsigned  bash setup-ssl.sh
#   sudo BEHIND_NAT=1 PUBLIC_IP=1.2.3.4 bash setup-ssl.sh
# ════════════════════════════════════════════════════════════════
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
load_env
require_root

command -v openssl >/dev/null 2>&1 || die "未找到 openssl"
command -v nginx >/dev/null 2>&1 || die "未找到 nginx，请先执行 01-init-ubuntu.sh"

if [[ $# -ge 1 ]]; then
    if [[ $# -ge 2 && "$1" != "$2" ]]; then
        warn "已改为单域名路径分流，忽略第二个参数 $2，使用 SITE_DOMAIN=$1"
    fi
    SITE_DOMAIN="$1"
    export SITE_DOMAIN
    normalize_site_settings
    apply_public_origins
fi

MODE="${SSL_MODE:-auto}"
EMAIL="${CERTBOT_EMAIL:-}"

[[ -n "$SITE_DOMAIN" ]] || die "未配置 SITE_DOMAIN"
normalize_publish_settings

is_example_domain() {
    [[ "$1" == *example.com || "$1" == *example.net || "$1" == *example.org ]]
}

print_nat_hints() {
    local lan public_ip dns_ips
    lan="$(list_lan_ipv4 | head -n1 || true)"
    public_ip="$(detect_public_ip || true)"
    dns_ips="$(dns_a_records_public "$SITE_DOMAIN" 2>/dev/null | tr '\n' ' ' || true)"
    echo
    echo "  内网 NAT / 域名检查："
    echo "    本机内网： ${lan:-无}"
    echo "    出口公网： ${public_ip:-无法探测（可设 PUBLIC_IP=）}"
    echo "    域名公网A：${dns_ips:-无法解析（请用 8.8.8.8 查 A 记录）}"
    echo "    路由器转发：TCP ${PUBLIC_HTTP_PORT:-80} → ${lan:-内网IP}:${LISTEN_HTTP_PORT:-80}"
    echo "                 TCP ${PUBLIC_HTTPS_PORT:-443} → ${lan:-内网IP}:${LISTEN_HTTPS_PORT:-443}"
    echo "    本机访问公网 IP 失败属正常（多数路由无 NAT 回环），以路由器转发为准。"
    echo "    诊断： sudo bash $SCRIPT_DIR/check-nat-publish.sh"
}

acme_local_ready() {
    local token="_isp-preflight-$$"
    local dir="$CERTBOT_WEBROOT/.well-known/acme-challenge"
    local url="http://127.0.0.1:${LISTEN_HTTP_PORT:-80}/.well-known/acme-challenge/${token}"
    mkdir -p "$dir"
    chmod a+rX "$CERTBOT_WEBROOT" "$CERTBOT_WEBROOT/.well-known" "$dir" 2>/dev/null || true
    echo "ok" > "$dir/$token"
    local body
    body="$(curl -fsS --max-time 5 -H "Host: ${SITE_DOMAIN}" "$url" 2>/dev/null || true)"
    rm -f "$dir/$token"
    [[ "$body" == "ok" ]]
}

issue_letsencrypt() {
    command -v certbot >/dev/null 2>&1 || die "未找到 certbot，请先执行 01-init-ubuntu.sh"
    mkdir -p "$CERTBOT_WEBROOT"
    chmod a+rX "$CERTBOT_WEBROOT"

    if ! acme_local_ready; then
        warn "本机 HTTP :${LISTEN_HTTP_PORT:-80} 尚未能提供 ACME 路径，先渲染 HTTP 站点再试"
        if [[ -f "$NGINX_AVAIL" ]]; then
            # 临时用 HTTP 模板，避免旧 HTTPS 跳转挡住校验
            local saved_ssl_redirect="${SSL_HTTP_REDIRECT:-}"
            SSL_HTTP_REDIRECT=0
            # 若已有证书，ssl_material_ready 仍为真会渲染 SSL 模板；强制走 HTTP 模板
            if ssl_material_ready; then
                warn "已有证书，保留 HTTPS，仅确认 ACME location 在 HTTP 端口上"
            fi
            render_nginx_conf "$NGINX_AVAIL"
            enable_nginx_site
            reload_nginx || true
            SSL_HTTP_REDIRECT="$saved_ssl_redirect"
        fi
        if ! acme_local_ready; then
            err "本机无法访问 http://127.0.0.1:${LISTEN_HTTP_PORT:-80}/.well-known/acme-challenge/"
            print_nat_hints
            return 1
        fi
    fi

    local mail_args=()
    if [[ -n "$EMAIL" ]] && ! is_placeholder "$EMAIL" email; then
        mail_args=(--email "$EMAIL" --no-eff-email)
    else
        warn "CERTBOT_EMAIL 未配置，使用 --register-unsafely-without-email"
        mail_args=(--register-unsafely-without-email)
    fi

    local domain_args=(-d "$SITE_DOMAIN")
    local alias
    for alias in ${SITE_ALIASES:-}; do
        [[ -n "$alias" ]] || continue
        is_ipv4 "$alias" && continue
        domain_args+=(-d "$alias")
    done

    log "申请 Let's Encrypt：${SITE_DOMAIN} ${SITE_ALIASES:-}"
    certbot certonly --webroot -w "$CERTBOT_WEBROOT" \
        "${domain_args[@]}" \
        "${mail_args[@]}" \
        --agree-tos \
        --non-interactive \
        --keep-until-expiring \
        --cert-name "$SITE_DOMAIN"
}

issue_selfsigned() {
    mkdir -p "$SELF_SIGNED_DIR"
    local key="$SELF_SIGNED_DIR/privkey.pem"
    local crt="$SELF_SIGNED_DIR/fullchain.pem"
    local conf="$SELF_SIGNED_DIR/san.cnf"
    local dns_lines="" ip_lines=""
    local dns_idx=1 ip_idx=1
    local item

    add_dns() {
        local name="$1"
        [[ -n "$name" ]] || return 0
        is_ipv4 "$name" && return 0
        dns_lines="${dns_lines}"$'\n'"DNS.${dns_idx} = ${name}"
        dns_idx=$((dns_idx + 1))
    }
    add_ip() {
        local ip="$1"
        [[ -n "$ip" ]] && is_ipv4 "$ip" || return 0
        ip_lines="${ip_lines}"$'\n'"IP.${ip_idx} = ${ip}"
        ip_idx=$((ip_idx + 1))
    }

    add_dns "$SITE_DOMAIN"
    add_ip "$SITE_DOMAIN"
    for item in ${SITE_ALIASES:-}; do
        add_dns "$item"
        add_ip "$item"
    done
    for item in $(list_lan_ipv4); do
        add_ip "$item"
    done
    add_ip "${PUBLIC_IP:-}"
    add_ip 127.0.0.1
    if item="$(detect_public_ip || true)"; then
        add_ip "$item"
    fi
    [[ -n "$dns_lines" ]] || dns_lines=$'\n'"DNS.1 = localhost"

    cat > "$conf" <<EOF
[req]
default_bits = 2048
prompt = no
default_md = sha256
distinguished_name = dn
x509_extensions = v3_req

[dn]
CN = ${SITE_DOMAIN}

[v3_req]
subjectAltName = @alt_names
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

[alt_names]${dns_lines}${ip_lines}
EOF
    openssl req -x509 -nodes -newkey rsa:2048 -days 825 \
        -keyout "$key" -out "$crt" -config "$conf"
    chmod 640 "$key"
    chmod 644 "$crt"
    chown root:"$APP_GROUP" "$key" "$crt" 2>/dev/null || true
    ok "已生成自签证书（含内网 IP / 公网 IP SAN）。浏览器告警属预期。"
}

persist_publish_env() {
    local env_file="$DEPLOY_DIR/.env"
    [[ -f "$env_file" ]] || return 0
    upsert_env_file "$env_file" SITE_DOMAIN "$SITE_DOMAIN"
    upsert_env_file "$env_file" ADMIN_DOMAIN "$SITE_DOMAIN"
    upsert_env_file "$env_file" PORTAL_DOMAIN "$SITE_DOMAIN"
    upsert_env_file "$env_file" ADMIN_BASE_PATH "$ADMIN_BASE_PATH"
    upsert_env_file "$env_file" DJANGO_SECURE_PROXY_SSL_HEADER True
    upsert_env_file "$env_file" PUBLIC_PORT "$PUBLIC_PORT"
    upsert_env_file "$env_file" PUBLIC_HTTP_PORT "$PUBLIC_HTTP_PORT"
    upsert_env_file "$env_file" PUBLIC_HTTPS_PORT "$PUBLIC_HTTPS_PORT"
    upsert_env_file "$env_file" ADMIN_PUBLIC_PORT "$ADMIN_PUBLIC_PORT"
    upsert_env_file "$env_file" PORTAL_PUBLIC_PORT "$PORTAL_PUBLIC_PORT"
    upsert_env_file "$env_file" LISTEN_HTTP_PORT "$LISTEN_HTTP_PORT"
    upsert_env_file "$env_file" LISTEN_HTTPS_PORT "$LISTEN_HTTPS_PORT"
    upsert_env_file "$env_file" BEHIND_NAT "$BEHIND_NAT"
    upsert_env_file "$env_file" PUBLIC_IP "${PUBLIC_IP:-}"
    upsert_env_file "$env_file" SSL_HTTP_REDIRECT "$SSL_HTTP_REDIRECT"
    upsert_env_file "$env_file" PAYMENT_FRONTEND_URL "$PAYMENT_FRONTEND_URL"
    upsert_env_file "$env_file" DJANGO_CSRF_TRUSTED_ORIGINS "$DJANGO_CSRF_TRUSTED_ORIGINS"
    upsert_env_file "$env_file" DJANGO_CORS_ALLOWED_ORIGINS "$DJANGO_CORS_ALLOWED_ORIGINS"
}

enable_https_runtime() {
    export DJANGO_SECURE_PROXY_SSL_HEADER=True
    # 不把映射端口强行改成 443：NAT / 面板映射必须保留 PUBLIC_HTTPS_PORT
    if [[ -z "${PUBLIC_HTTPS_PORT:-}" || "${PUBLIC_HTTPS_PORT}" == "80" ]]; then
        if [[ -n "${PUBLIC_PORT:-}" && "${PUBLIC_PORT}" != "80" ]]; then
            PUBLIC_HTTPS_PORT="$PUBLIC_PORT"
        else
            PUBLIC_HTTPS_PORT=443
        fi
    fi
    export PUBLIC_HTTPS_PORT
    export PUBLIC_HTTP_PORT="${PUBLIC_HTTP_PORT:-80}"
    export PUBLIC_PORT="$PUBLIC_HTTPS_PORT"
    export ADMIN_PUBLIC_PORT="$PUBLIC_PORT"
    export PORTAL_PUBLIC_PORT="$PUBLIC_PORT"
    SSL_HTTP_REDIRECT="$(resolve_ssl_http_redirect)"
    export SSL_HTTP_REDIRECT
    ensure_payment_frontend_url https
    apply_public_origins
    write_runtime_env "$RUNTIME_ENV_FILE"
    persist_publish_env

    if has_systemd && systemctl is-enabled ispmanager.service >/dev/null 2>&1; then
        systemctl restart ispmanager.service
        sleep 1
        systemctl is-active --quiet ispmanager.service || {
            journalctl -u ispmanager -n 20 --no-pager || true
            die "启用 HTTPS 后后端重启失败"
        }
    fi
}

decide_auto_mode() {
    if is_example_domain "$SITE_DOMAIN"; then
        warn "域名为 example.*，自动改用自签证书"
        echo selfsigned
        return
    fi
    if is_ipv4 "$SITE_DOMAIN"; then
        warn "SITE_DOMAIN 是 IP，Let's Encrypt 不能签发，改用自签"
        echo selfsigned
        return
    fi
    if [[ "$SITE_DOMAIN" == *.local || "$SITE_DOMAIN" == *.lan ]]; then
        warn "内网专用域名，改用自签证书"
        echo selfsigned
        return
    fi

    local public_ip dns_ips
    public_ip="$(detect_public_ip || true)"
    dns_ips="$(dns_a_records_public "$SITE_DOMAIN" 2>/dev/null || true)"
    [[ -n "$public_ip" ]] && log "出口公网 IP：$public_ip"
    [[ -n "$dns_ips" ]] && log "域名公网 A：$(echo "$dns_ips" | tr '\n' ' ')"

    if [[ -n "$dns_ips" && -n "$public_ip" ]] && domain_points_here "$SITE_DOMAIN" "$public_ip"; then
        log "公网 DNS 已指向本机出口 IP，尝试 Let's Encrypt"
        echo letsencrypt
        return
    fi

    if [[ "${BEHIND_NAT:-0}" == "1" && -n "$dns_ips" ]]; then
        local first
        first="$(echo "$dns_ips" | awk 'NR==1{print}')"
        if [[ -n "$first" ]] && ! is_private_ipv4 "$first"; then
            warn "内网 NAT：域名 A 为公网地址但与出口 IP 不完全一致（多线/hosts），仍尝试 Let's Encrypt"
            echo letsencrypt
            return
        fi
    fi

    warn "DNS 尚未确认指向本机，改用自签。解析并转发 80/443 后执行：SSL_MODE=letsencrypt sudo bash setup-ssl.sh"
    print_nat_hints
    echo selfsigned
}

step "选择证书模式（当前 SSL_MODE=$MODE，BEHIND_NAT=${BEHIND_NAT:-0}）"
case "$MODE" in
    skip)
        log "SSL_MODE=skip，保持 HTTP"
        persist_publish_env
        exit 0
        ;;
    auto)
        MODE="$(decide_auto_mode)"
        log "auto 决策结果：$MODE"
        ;;
    letsencrypt|selfsigned)
        ;;
    *)
        die "未知 SSL_MODE=$MODE（可用 auto|letsencrypt|selfsigned|skip）"
        ;;
esac

ensure_listen_firewall

if [[ "${SKIP_CERT_ISSUE:-0}" == "1" ]] && ssl_material_ready; then
    log "证书已存在，跳过签发，仅重渲染 HTTPS 配置"
    enable_https_runtime
    render_nginx_conf "$NGINX_AVAIL"
    enable_nginx_site
    reload_nginx
    ok "已沿用现有证书并刷新 nginx"
    print_site_urls https
    exit 0
fi

if [[ "$MODE" == "letsencrypt" ]]; then
    if is_example_domain "$SITE_DOMAIN" || is_ipv4 "$SITE_DOMAIN"; then
        die "Let's Encrypt 不能使用 example.* 或纯 IP，请改真实域名或 SSL_MODE=selfsigned"
    fi
    if [[ ! -f "$NGINX_AVAIL" ]]; then
        die "尚未部署 nginx 站点，请先 sudo bash deploy.sh"
    fi
    mkdir -p "$CERTBOT_WEBROOT"
    if ! ssl_material_ready; then
        render_nginx_conf "$NGINX_AVAIL"
        enable_nginx_site
        reload_nginx || true
    fi
    if ! issue_letsencrypt; then
        if [[ "${SSL_MODE:-auto}" == "auto" ]]; then
            warn "Let's Encrypt 失败，回退自签。常见原因：路由器未转发 80，或域名 A 未指向公网 IP。"
            print_nat_hints
            MODE=selfsigned
        else
            print_nat_hints
            die "Let's Encrypt 申请失败。路由器需转发 80→本机 ${LISTEN_HTTP_PORT:-80}，且 ${SITE_DOMAIN} 的公网 A 指向出口 IP。"
        fi
    fi
fi

if [[ "$MODE" == "selfsigned" ]]; then
    issue_selfsigned
fi

ssl_material_ready || die "证书文件未就绪，无法启用 HTTPS"

step "渲染 HTTPS nginx 并更新 Django 反代头"
enable_https_runtime
render_nginx_conf "$NGINX_AVAIL"
enable_nginx_site
reload_nginx
ok "nginx 已应用 HTTPS"

if has_systemd; then
    systemctl enable --now certbot.timer 2>/dev/null || true
fi

echo
ok "════════════════════════════════════════════════════"
ok " HTTPS 已启用"
ok "════════════════════════════════════════════════════"
print_site_urls https
if ssl_is_letsencrypt; then
    echo -e "  证书：     Let's Encrypt（certbot.timer 自动续期）"
else
    echo -e "  证书：     自签（浏览器告警属预期）"
    if [[ "$(resolve_ssl_http_redirect)" != "1" ]]; then
        echo -e "  HTTP：     内网 NAT 未跳转 HTTPS，公网仍可用 http://${SITE_DOMAIN}/"
    fi
    echo -e "  换公网证书：sudo SSL_MODE=letsencrypt bash setup-ssl.sh"
fi
