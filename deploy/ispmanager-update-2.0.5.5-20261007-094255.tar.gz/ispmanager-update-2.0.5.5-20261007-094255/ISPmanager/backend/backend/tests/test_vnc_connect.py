from django.test import SimpleTestCase

from resource_manager.vnc_consumer import close_reason, node_ws_connect_kwargs


class VncConnectTests(SimpleTestCase):
    def test_node_socket_does_not_use_env_proxy_or_compression(self):
        kwargs = node_ws_connect_kwargs(None)
        self.assertIsNone(kwargs['proxy'])
        self.assertIsNone(kwargs['compression'])
        self.assertIsNone(kwargs['ping_interval'])
        self.assertEqual(kwargs['subprotocols'], ['binary'])
        self.assertNotIn('ssl', kwargs)

    def test_ssl_context_is_forwarded(self):
        sentinel = object()
        self.assertIs(node_ws_connect_kwargs(sentinel)['ssl'], sentinel)

    def test_close_reason_is_one_short_line(self):
        text = close_reason(RuntimeError('连不上\n节点  ' + 'x' * 200))
        self.assertNotIn('\n', text)
        self.assertLessEqual(len(text), 120)
        self.assertTrue(text.startswith('RuntimeError:'))
