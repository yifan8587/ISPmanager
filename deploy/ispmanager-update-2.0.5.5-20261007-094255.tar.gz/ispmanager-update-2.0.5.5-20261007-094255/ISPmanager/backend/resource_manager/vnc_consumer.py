"""
noVNC 远程控制台中继消费者。

ISPmanager 不直接连接 PVE，而是经由 POP/PE 节点的 vpopmanager 暴露的 noVNC
WebSocket（节点再代理到 Proxmox vncwebsocket）。本消费者把浏览器的 noVNC 流量
中继到节点 WebSocket，实现「浏览器 ↔ ISPmanager ↔ 节点 ↔ PVE」的链路：

  浏览器 RFB ──ws/resource/vnc/<vps_id>/?token=<ISP JWT>&vncticket=&port=──▶ 本消费者
  本消费者 ──wss://<节点host>/ws/pvemanager/vnc/<source_ref>/?token=<节点 JWT>&...──▶ 节点
  节点 ──wss://<pve>/api2/json/.../vncwebsocket──▶ Proxmox

票据流程（与 vpopmanager 一致，避免重复调用 vncproxy 使票据失效）：
  前端先调 REST /vps/{id}/vnc_ticket/ 取得 ticket/port/password（仅调用一次 vncproxy），
  随后立即用 ticket/port 建立本 WebSocket；本消费者把 ticket/port 原样透传给节点，
  节点不会再次调用 vncproxy。
"""

import asyncio
import logging
import ssl
from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer

logger = logging.getLogger(__name__)

try:
    import websockets
except ImportError:  # pragma: no cover
    websockets = None


def node_ws_connect_kwargs(ssl_context):
    """直连节点。websockets 15 默认会走环境变量里的 HTTP 代理并开启压缩，节点侧接不住。"""
    kwargs = {
        'subprotocols': ['binary'],
        'max_size': None,
        'compression': None,
        'proxy': None,
        'open_timeout': 20,
        'ping_interval': None,
    }
    if ssl_context is not None:
        kwargs['ssl'] = ssl_context
    return kwargs


def close_reason(exc) -> str:
    text = ' '.join(f'{type(exc).__name__}: {exc}'.split())
    return text[:120]


class VPSVNCConsumer(AsyncWebsocketConsumer):
    """路径: ws/resource/vnc/<vps_id>/?token=<JWT>&vncticket=<t>&port=<p>"""

    node_ws = None

    async def connect(self):
        self._upstream = asyncio.Lock()
        self._node_ready = False
        await self._upstream.acquire()
        try:
            await self._open()
        finally:
            self._node_ready = self.node_ws is not None
            self._upstream.release()

    async def _open(self):
        if websockets is None:
            await self.close(code=4401, reason='服务端缺少 websockets')
            return

        user = self.scope.get('user')
        if not user or not getattr(user, 'is_authenticated', False):
            await self.close(code=4401, reason='登录已失效')
            return

        self.vps_id = self.scope['url_route']['kwargs']['vps_id']
        decision, vps = await self._authorize_vps(user, self.vps_id)
        if decision == 'forbidden':
            await self.close(code=4403, reason='没有控制台权限')
            return
        if vps is None:
            await self.close(code=4404, reason='找不到这台 VPS')
            return
        if not vps['source_ref']:
            await self.close(code=4400, reason='这台 VPS 还没有同步到节点')
            return

        qs = parse_qs(self.scope.get('query_string', b'').decode())
        vncticket = (qs.get('vncticket') or [None])[0]
        port = (qs.get('port') or [None])[0]

        # 先接受浏览器，关闭时才能把原因送回去。浏览器发出的 RFB 数据先堵住，
        # 等节点连上再放行，避免开头的协议字节被丢掉。
        chosen = 'binary' if 'binary' in self._client_subprotocols() else None
        await self.accept(subprotocol=chosen)

        try:
            node_url = await asyncio.to_thread(self._build_node_ws_url, vps, vncticket, port)
        except Exception as e:  # noqa: BLE001
            logger.error('build node vnc ws url failed: %s', e)
            await self.close(code=4500, reason=close_reason(e))
            return

        ssl_ctx = None
        if node_url.startswith('wss://'):
            from .pemanager_client import resolve_pemanager_ssl_verify
            ssl_ctx = ssl.create_default_context()
            base = vps['api_base_url'] or (
                f'https://{vps["mgmt_ip"]}' if vps.get('mgmt_ip') else node_url
            )
            if not resolve_pemanager_ssl_verify(base, explicit=vps.get('api_verify_ssl')):
                ssl_ctx.check_hostname = False
                ssl_ctx.verify_mode = ssl.CERT_NONE

        try:
            self.node_ws = await websockets.connect(node_url, **node_ws_connect_kwargs(ssl_ctx))
        except TypeError:
            # 旧版 websockets 没有 proxy 参数
            kwargs = node_ws_connect_kwargs(ssl_ctx)
            kwargs.pop('proxy', None)
            try:
                self.node_ws = await websockets.connect(node_url, **kwargs)
            except Exception as e:  # noqa: BLE001
                logger.error('connect node vnc ws failed: %s url=%s', e, node_url)
                await self.close(code=4502, reason=close_reason(e))
                return
        except Exception as e:  # noqa: BLE001
            logger.error('connect node vnc ws failed: %s url=%s', e, node_url)
            await self.close(code=4502, reason=close_reason(e))
            return

        self._relay_task = asyncio.create_task(self._relay_from_node())

    def _client_subprotocols(self):
        headers = dict(self.scope.get('headers') or [])
        raw = headers.get(b'sec-websocket-protocol', b'').decode()
        return [p.strip() for p in raw.split(',') if p.strip()]

    @staticmethod
    def _build_node_ws_url(vps, vncticket, port):
        from .pemanager_client import PemanagerClient
        base = vps['api_base_url'] or (f'http://{vps["mgmt_ip"]}' if vps['mgmt_ip'] else '')
        # 控制台 WebSocket 优先 JWT：有账号密码则 login；仅 Token 时用 pem_*（节点 WS 可能不认）。
        client = PemanagerClient(
            base, vps['api_username'], vps['api_password'],
            verify=vps.get('api_verify_ssl'),
            api_token=vps.get('mgmt_token') or None,
        )
        client.authenticate_for_websocket()
        return client.node_vnc_ws_url(vps['source_ref'], vncticket=vncticket, port=port)

    @staticmethod
    @database_sync_to_async
    def _authorize_vps(user, vps_id):
        from accounts.ws_access import authorize_vps_console
        return authorize_vps_console(user, vps_id)

    async def _relay_from_node(self):
        try:
            async for message in self.node_ws:
                if isinstance(message, bytes):
                    await self.send(bytes_data=message)
                else:
                    await self.send(text_data=message)
        except Exception as e:  # noqa: BLE001
            logger.debug('node vnc relay end: %s', e)
        finally:
            await self.close()

    async def receive(self, text_data=None, bytes_data=None):
        if not getattr(self, '_node_ready', False):
            upstream = getattr(self, '_upstream', None)
            if upstream is not None:
                await upstream.acquire()
                upstream.release()
        if not self.node_ws:
            return
        try:
            if bytes_data is not None:
                await self.node_ws.send(bytes_data)
            elif text_data is not None:
                await self.node_ws.send(text_data)
        except Exception as e:  # noqa: BLE001
            logger.warning('send to node vnc: %s', e)
            await self.close()

    async def disconnect(self, code):
        if getattr(self, '_relay_task', None):
            self._relay_task.cancel()
        if self.node_ws:
            try:
                await self.node_ws.close()
            except Exception:  # noqa: BLE001
                pass
