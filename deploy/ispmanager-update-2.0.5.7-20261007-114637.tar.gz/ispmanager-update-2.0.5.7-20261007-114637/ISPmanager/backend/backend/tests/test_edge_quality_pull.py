from types import SimpleNamespace

from django.test import SimpleTestCase
from django.utils import timezone

from portal.monitoring import _quality_from_node_points


class NodeQualityMappingTests(SimpleTestCase):
    def test_maps_vpopmanager_points_into_portal_payload(self):
        edge = SimpleNamespace(pk=42)
        payload = _quality_from_node_points(edge, 24, {
            'status': 'ok',
            'points': [{
                'time': timezone.now().isoformat(),
                'latency_ms': 12.5,
                'packet_loss_pct': 0,
                'jitter_ms': 0.4,
                'ok': True,
            }],
        })
        self.assertEqual(payload['data_source'], 'vpop_node')
        self.assertEqual(payload['status'], 'ok')
        self.assertEqual(payload['summary']['sample_count'], 1)
        self.assertEqual(payload['current']['latency_ms'], 12.5)
        self.assertEqual(payload['series'][0]['packet_loss_pct'], 0)

    def test_missing_node_target_is_not_configured(self):
        payload = _quality_from_node_points(SimpleNamespace(pk=1), 24, {
            'status': 'not_configured',
            'points': [],
        })
        self.assertEqual(payload['status'], 'not_configured')
        self.assertEqual(payload['summary']['sample_count'], 0)
